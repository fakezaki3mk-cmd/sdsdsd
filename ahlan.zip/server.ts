import express from 'express';
import http from 'http';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, ThinkingLevel } from '@google/genai';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini AI on the server side
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Helper for calling Gemini safely with high-availability fallback
async function askGemini(prompt: string, systemInstruction?: string): Promise<string> {
  const instruction =
    systemInstruction ||
    'أنت مساعد ذكاء اصطناعي ذكي ومرح وودود داخل بوت ديسكورد لسيرفر Hitrex SMP. أجب باختصار واحترافية وباللغة العربية مع إيموجيز مناسبة واستخدم تنسيق ماركداون ديسكورد.';

  // 1. Try primary model: gemini-3.8-flash with LOW thinking level for superfast responses
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction: instruction,
        thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
      },
    });
    if (response.text) return response.text;
  } catch (err: any) {
    console.warn('[Gemini AI] gemini-3.8-flash error/spike, falling back to gemini-3.1-flash-lite:', err?.message);
  }

  // 2. High-availability fallback: gemini-3.1-flash-lite
  try {
    const fallbackResponse = await ai.models.generateContent({
      model: 'gemini-3.1-flash-lite',
      contents: prompt,
      config: {
        systemInstruction: instruction,
      },
    });
    if (fallbackResponse.text) return fallbackResponse.text;
  } catch (fallbackErr: any) {
    console.error('[Gemini AI] Both models failed:', fallbackErr?.message);
  }

  return 'أهلاً بك! أنا مساعد الذكاء الاصطناعي في السيرفر. كيف يمكنني مساعدتك؟ تفضل بطرح سؤالك وسأجيبك فوراً!';
}

// Discord Bot in-memory state & client holder
interface BotState {
  status: 'offline' | 'connecting' | 'online' | 'error';
  tag: string | null;
  id: string | null;
  ping: number;
  uptime: number;
  guildsCount: number;
  tokenConfigured: boolean;
  errorMessage: string | null;
}

let botState: BotState = {
  status: 'offline',
  tag: null,
  id: null,
  ping: 0,
  uptime: 0,
  guildsCount: 0,
  tokenConfigured: !!process.env.DISCORD_BOT_TOKEN,
  errorMessage: null,
};

let discordClient: any = null;

// Persistent Data Paths
const DATA_DIR = path.resolve(__dirname, '.bot_data');
if (!fs.existsSync(DATA_DIR)) {
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  } catch {}
}

const AI_CHANNELS_FILE = path.join(DATA_DIR, 'ai_channels.json');
const AUTO_RESPONSES_FILE = path.join(DATA_DIR, 'auto_responses.json');
const INVITES_DATA_FILE = path.join(DATA_DIR, 'invites_data.json');

// Dedicated AI Channel IDs Set
let aiChannelIds: Set<string> = new Set();
try {
  if (fs.existsSync(AI_CHANNELS_FILE)) {
    const raw = fs.readFileSync(AI_CHANNELS_FILE, 'utf-8');
    aiChannelIds = new Set(JSON.parse(raw));
  }
} catch {}

function saveAiChannels() {
  try {
    fs.writeFileSync(AI_CHANNELS_FILE, JSON.stringify(Array.from(aiChannelIds), null, 2));
  } catch {}
}

// Auto-responders list
interface AutoResponder {
  id: string;
  trigger: string;
  reply: string;
  matchType: 'exact' | 'contains' | 'startsWith';
  enabled: boolean;
}

let autoResponders: AutoResponder[] = [
  {
    id: 'ar-1',
    trigger: 'سلام',
    reply: 'وعليكم السلام ورحمة الله وبركاته! نورت السيرفر يا غالي 🌟',
    matchType: 'contains',
    enabled: true,
  },
  {
    id: 'ar-2',
    trigger: 'السلام عليكم',
    reply: 'وعليكم السلام ورحمة الله وبركاته! أهلاً وسهلاً بك في مجتمعنا 🤍',
    matchType: 'exact',
    enabled: true,
  },
  {
    id: 'ar-3',
    trigger: 'قوانين',
    reply: '📜 يرجى مراجعة روم القوانين الرسمية لتفادي أي مخالفة أو حظر. نتمنى لك وقتاً ممتعاً!',
    matchType: 'contains',
    enabled: true,
  },
  {
    id: 'ar-4',
    trigger: 'تكت',
    reply: '🎫 إذا كنت بحاجة لدعم فني أو مساعدة، تفضل بزيارة روم التذاكر واضغط على زر القسم المناسب!',
    matchType: 'contains',
    enabled: true,
  },
];

try {
  if (fs.existsSync(AUTO_RESPONSES_FILE)) {
    const raw = fs.readFileSync(AUTO_RESPONSES_FILE, 'utf-8');
    autoResponders = JSON.parse(raw);
  }
} catch {}

function saveAutoResponders() {
  try {
    fs.writeFileSync(AUTO_RESPONSES_FILE, JSON.stringify(autoResponders, null, 2));
  } catch {}
}

// Invites Cache & Stats
interface UserInviteStats {
  total: number;
  regular: number;
  left: number;
  fake: number;
  code?: string;
}

// Map<guildId, Map<userId, UserInviteStats>>
let inviteStats: Record<string, Record<string, UserInviteStats>> = {};
// Map<guildId, Map<inviteCode, uses>>
const guildInvitesCache = new Map<string, Map<string, number>>();
// Map<guildId, Map<memberId, inviterId>>
const memberInviterMap = new Map<string, Map<string, string>>();

try {
  if (fs.existsSync(INVITES_DATA_FILE)) {
    const raw = fs.readFileSync(INVITES_DATA_FILE, 'utf-8');
    inviteStats = JSON.parse(raw);
  }
} catch {}

function saveInvitesData() {
  try {
    fs.writeFileSync(INVITES_DATA_FILE, JSON.stringify(inviteStats, null, 2));
  } catch {}
}

function getUserInvites(guildId: string, userId: string): UserInviteStats {
  if (!inviteStats[guildId]) inviteStats[guildId] = {};
  if (!inviteStats[guildId][userId]) {
    inviteStats[guildId][userId] = {
      total: 0,
      regular: 0,
      left: 0,
      fake: 0,
    };
  }
  return inviteStats[guildId][userId];
}

// Admin Commands List for Strict Permission Enforcement
const ADMIN_COMMANDS = [
  'setup-tickets',
  'ban',
  'kick',
  'warn',
  'clear',
  'slowmode',
  'autoreply',
];

// Helper: Split long Discord messages (> 2000 chars)
async function sendChunkedMessage(channel: any, text: string) {
  if (!text) return;
  const MAX_LEN = 1950;
  for (let i = 0; i < text.length; i += MAX_LEN) {
    const chunk = text.substring(i, i + MAX_LEN);
    await channel.send(chunk);
  }
}

// Dynamic Discord bot connection
async function connectDiscordBot(token: string) {
  try {
    botState.status = 'connecting';
    botState.errorMessage = null;

    const {
      Client,
      GatewayIntentBits,
      Partials,
      SlashCommandBuilder,
      Routes,
      REST,
      EmbedBuilder,
      ActionRowBuilder,
      ButtonBuilder,
      ButtonStyle,
      ChannelType,
      PermissionsBitField,
      ModalBuilder,
      TextInputBuilder,
      TextInputStyle,
      AttachmentBuilder,
    } = await import('discord.js');

    if (discordClient) {
      try {
        await discordClient.destroy();
      } catch {}
    }

    const client = new Client({
      intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildInvites,
      ],
      partials: [Partials.Channel, Partials.Message, Partials.GuildMember],
    });

    // 1. Definition of Slash Commands
    const commands = [
      new SlashCommandBuilder()
        .setName('help')
        .setDescription('عرض قائمة الأوامر المتاحة ومعلومات البوت'),

      new SlashCommandBuilder()
        .setName('ping')
        .setDescription('فحص سرعة استجابة البوت'),

      new SlashCommandBuilder()
        .setName('ip')
        .setDescription('عرض معلومات وآي بي سيرفر Hitrex SMP ماين كرافت'),

      new SlashCommandBuilder()
        .setName('invites')
        .setDescription('عرض إحصائيات دعواتك أو دعوات عضو آخر (-i)')
        .addUserOption((opt: any) =>
          opt.setName('user').setDescription('العضو المراد فحص دعواته').setRequired(false)
        ),

      new SlashCommandBuilder()
        .setName('ask')
        .setDescription('استشارة الذكاء الاصطناعي (Gemini 3.8 Flash)')
        .addStringOption((opt: any) =>
          opt.setName('prompt').setDescription('السؤال أو الاستفسار').setRequired(true)
        ),

      // AI Dedicated Channel Setup & Controls (Admin Only)
      new SlashCommandBuilder()
        .setName('ai')
        .setDescription('إعدادات الذكاء الاصطناعي والقناة التفاعلية')
        .setDefaultMemberPermissions(PermissionsBitField.Flags.Administrator)
        .addSubcommand((sub: any) =>
          sub
            .setName('setup')
            .setDescription('تخصيص القناة الحالية كقناة تفاعلية للذكاء الاصطناعي (يرد على أي رسالة)')
        )
        .addSubcommand((sub: any) =>
          sub
            .setName('disable')
            .setDescription('إلغاء تفعيل قناة الذكاء الاصطناعي الحالية')
        )
        .addSubcommand((sub: any) =>
          sub
            .setName('chat')
            .setDescription('سؤال سريع للذكاء الاصطناعي')
            .addStringOption((opt: any) =>
              opt.setName('prompt').setDescription('سؤالك').setRequired(true)
            )
        ),

      // Ticket Setup (Admin Only)
      new SlashCommandBuilder()
        .setName('setup-tickets')
        .setDescription('إنشاء لوحة فتح التذاكر الاحترافية مع الأزرار والنماذج')
        .setDefaultMemberPermissions(PermissionsBitField.Flags.Administrator),

      // Ticket Commands (Mixed)
      new SlashCommandBuilder()
        .setName('ticket')
        .setDescription('إدارة التذكرة الحالية')
        .addSubcommand((sub: any) =>
          sub.setName('close').setDescription('إغلاق وأرشفة التذكرة الحالية')
        )
        .addSubcommand((sub: any) =>
          sub.setName('claim').setDescription('استلام التذكرة من قبل طاقم الدعم')
        )
        .addSubcommand((sub: any) =>
          sub
            .setName('add')
            .setDescription('إضافة عضو للتذكرة (طاقم الدعم)')
            .addUserOption((opt: any) =>
              opt.setName('user').setDescription('العضو المراد إضافته').setRequired(true)
            )
        )
        .addSubcommand((sub: any) =>
          sub
            .setName('remove')
            .setDescription('إزالة عضو من التذكرة (طاقم الدعم)')
            .addUserOption((opt: any) =>
              opt.setName('user').setDescription('العضو المراد إزالته').setRequired(true)
            )
        )
        .addSubcommand((sub: any) =>
          sub
            .setName('rename')
            .setDescription('تغيير اسم روم التذكرة (طاقم الدعم)')
            .addStringOption((opt: any) =>
              opt.setName('name').setDescription('الاسم الجديد').setRequired(true)
            )
        ),

      // Auto-Responders Management (Admin Only)
      new SlashCommandBuilder()
        .setName('autoreply')
        .setDescription('إدارة نظام الردود التلقائية للسيرفر')
        .setDefaultMemberPermissions(PermissionsBitField.Flags.Administrator)
        .addSubcommand((sub: any) =>
          sub
            .setName('add')
            .setDescription('إضافة رد تلقائي جديد')
            .addStringOption((opt: any) =>
              opt.setName('trigger').setDescription('الكلمة أو العبارة المشغلة').setRequired(true)
            )
            .addStringOption((opt: any) =>
              opt.setName('reply').setDescription('رد البوت').setRequired(true)
            )
        )
        .addSubcommand((sub: any) =>
          sub.setName('list').setDescription('عرض جميع الردود التلقائية المسجلة')
        )
        .addSubcommand((sub: any) =>
          sub
            .setName('delete')
            .setDescription('حذف رد تلقائي بالمعرف')
            .addStringOption((opt: any) =>
              opt.setName('id').setDescription('معرف الرد التلقائي (ID)').setRequired(true)
            )
        ),

      // Moderation Commands (Admin Only)
      new SlashCommandBuilder()
        .setName('ban')
        .setDescription('حظر عضو نهائياً من السيرفر (👑 للإدارة فقط)')
        .setDefaultMemberPermissions(PermissionsBitField.Flags.BanMembers)
        .addUserOption((opt: any) =>
          opt.setName('user').setDescription('العضو المراد حظره').setRequired(true)
        )
        .addStringOption((opt: any) =>
          opt.setName('reason').setDescription('سبب الحظر').setRequired(false)
        ),

      new SlashCommandBuilder()
        .setName('kick')
        .setDescription('طرد عضو من السيرفر (👑 للإدارة فقط)')
        .setDefaultMemberPermissions(PermissionsBitField.Flags.KickMembers)
        .addUserOption((opt: any) =>
          opt.setName('user').setDescription('العضو المراد طرده').setRequired(true)
        )
        .addStringOption((opt: any) =>
          opt.setName('reason').setDescription('سبب الطرد').setRequired(false)
        ),

      new SlashCommandBuilder()
        .setName('warn')
        .setDescription('توجيه تحذير رسمي مسجل لعضو (👑 للإدارة فقط)')
        .setDefaultMemberPermissions(PermissionsBitField.Flags.ModerateMembers)
        .addUserOption((opt: any) =>
          opt.setName('user').setDescription('العضو المراد تحذيره').setRequired(true)
        )
        .addStringOption((opt: any) =>
          opt.setName('reason').setDescription('سبب التحذير').setRequired(true)
        ),

      new SlashCommandBuilder()
        .setName('clear')
        .setDescription('مسح عدد معين من الرسائل الحديثة (👑 للإدارة فقط)')
        .setDefaultMemberPermissions(PermissionsBitField.Flags.ManageMessages)
        .addIntegerOption((opt: any) =>
          opt
            .setName('amount')
            .setDescription('عدد الرسائل (1-100)')
            .setRequired(true)
            .setMinValue(1)
            .setMaxValue(100)
        ),

      new SlashCommandBuilder()
        .setName('slowmode')
        .setDescription('تحديد وقت الوضع البطيء للروم (👑 للإدارة فقط)')
        .setDefaultMemberPermissions(PermissionsBitField.Flags.ManageChannels)
        .addIntegerOption((opt: any) =>
          opt.setName('seconds').setDescription('الثواني (0 للتعطيل)').setRequired(true)
        ),
    ];

    // Helper: Create Minecraft Server Info Embed
    function createMinecraftEmbed() {
      return new EmbedBuilder()
        .setTitle('⛏️ معلومات سيرفر Hitrex SMP ماين كرافت')
        .setDescription(
          'أهلاً بك في سيرفر **Hitrex SMP** الرسمي! سيرفر سرفايفل متطور، كستم إينشانتس، ورتب، ونظام اقتصادي فريد.'
        )
        .setColor(0x57f287)
        .addFields(
          { name: '🌐 عنوان السيرفر (Java IP)', value: '`hitrexsmp.halix.gg`', inline: true },
          { name: '🔌 منفذ الجافا (Java Port)', value: '`25565` (الافتراضي)', inline: true },
          { name: '📱 منفذ الجوال (Bedrock Port)', value: '`19132`', inline: true },
          { name: '🎮 الإصدارات المدعومة', value: '`1.16.x - 1.21.x` (يدعم جميع التحديثات)', inline: true },
          { name: '⚡ حالة السيرفر', value: '🟢 **متصل ومتاح لجميع اللاعبين (Online)**', inline: true },
          { name: '🌟 نوع السيرفر', value: 'Survival SMP · Crossplay (PC + Mobile)', inline: true }
        )
        .setFooter({ text: 'Hitrex SMP · انسخ الآي بي واستمتع باللعب الآن!' })
        .setTimestamp();
    }

    // Helper: Create Invites Embed
    async function createInvitesEmbed(guild: any, targetUser: any) {
      const stats = getUserInvites(guild.id, targetUser.id);

      // Check if user has an active invite code
      let inviteUrl = stats.code ? `https://discord.gg/${stats.code}` : null;
      if (!inviteUrl) {
        try {
          const invites = await guild.invites.fetch();
          const userInv = invites.find((inv: any) => inv.inviter?.id === targetUser.id);
          if (userInv) {
            stats.code = userInv.code;
            saveInvitesData();
            inviteUrl = `https://discord.gg/${userInv.code}`;
          }
        } catch {}
      }

      return new EmbedBuilder()
        .setTitle(`📨 إحصائيات دعوات العضو | ${targetUser.username}`)
        .setDescription(`تقرير مفصل عن الدعوات المنسوبة للعضو <@${targetUser.id}> في هذا السيرفر:`)
        .setColor(0x5865f2)
        .setThumbnail(targetUser.displayAvatarURL?.() || null)
        .addFields(
          { name: '✨ إجمالي الدعوات', value: `**${stats.total}** دعوة`, inline: true },
          { name: '✅ دعوات حقيقية مؤكدة', value: `**${stats.regular}** عضو`, inline: true },
          { name: '🚪 أعضاء غادروا', value: `**${stats.left}** أعضاء`, inline: true },
          { name: '⚠️ حسابات وهمية', value: `**${stats.fake}** حساب`, inline: true },
          {
            name: '🔗 رابط الدعوة المعتمد',
            value: inviteUrl ? `[${inviteUrl}](${inviteUrl})` : '`لم يتم إنشاء رابط دعوة بعد`',
            inline: false,
          }
        )
        .setFooter({ text: 'نظام تتبع الدعوات الآلي · تحديث فوري فور دخول أي عضو' })
        .setTimestamp();
    }

    // 2. Ready Event
    client.once('ready', async () => {
      botState.status = 'online';
      botState.tag = client.user?.tag || 'Discord Bot';
      botState.id = client.user?.id || null;
      botState.ping = client.ws.ping;
      botState.guildsCount = client.guilds.cache.size;
      botState.uptime = Date.now();
      botState.tokenConfigured = true;
      botState.errorMessage = null;
      console.log(`[Discord Bot] Logged in as ${client.user?.tag}`);

      // Cache guild invites for tracking
      for (const [guildId, guild] of client.guilds.cache) {
        try {
          const firstInvites = await guild.invites.fetch();
          guildInvitesCache.set(guildId, new Map(firstInvites.map((inv: any) => [inv.code, inv.uses || 0])));
          console.log(`[Discord Bot] Cached ${firstInvites.size} invites for guild: ${guild.name}`);
        } catch (invErr) {
          console.warn(`[Discord Bot] Could not fetch invites for guild ${guild.name}:`, invErr);
        }
      }

      // Register Clean Global Commands and wipe duplicate guild-specific ones
      try {
        if (client.user?.id) {
          const rest = new REST({ version: '10' }).setToken(token);
          const commandData = commands.map((c: any) => c.toJSON());

          // Clear duplicate guild commands
          for (const [guildId] of client.guilds.cache) {
            try {
              await rest.put(Routes.applicationGuildCommands(client.user.id, guildId), {
                body: [],
              });
            } catch {}
          }

          // Register global commands
          await rest.put(Routes.applicationCommands(client.user.id), {
            body: commandData,
          });
          console.log('[Discord Bot] Clean Slash Commands Registered Globally!');
        }
      } catch (cmdErr) {
        console.error('[Discord Bot] Error registering slash commands:', cmdErr);
      }
    });

    // 3. Invites Tracking Listeners
    client.on('inviteCreate', (invite: any) => {
      if (invite.guild) {
        const guildCache = guildInvitesCache.get(invite.guild.id) || new Map();
        guildCache.set(invite.code, invite.uses || 0);
        guildInvitesCache.set(invite.guild.id, guildCache);
      }
    });

    client.on('inviteDelete', (invite: any) => {
      if (invite.guild) {
        const guildCache = guildInvitesCache.get(invite.guild.id);
        if (guildCache) {
          guildCache.delete(invite.code);
        }
      }
    });

    client.on('guildMemberAdd', async (member: any) => {
      try {
        const guild = member.guild;
        const cachedInvites = guildInvitesCache.get(guild.id);
        const newInvites = await guild.invites.fetch();

        // Update cache and find which invite was used
        let usedInvite: any = null;
        if (cachedInvites) {
          usedInvite = newInvites.find((inv: any) => {
            const prevUses = cachedInvites.get(inv.code) || 0;
            return (inv.uses || 0) > prevUses;
          });
        }

        // Refresh cache
        guildInvitesCache.set(guild.id, new Map(newInvites.map((inv: any) => [inv.code, inv.uses || 0])));

        if (usedInvite && usedInvite.inviter) {
          const inviterId = usedInvite.inviter.id;
          const stats = getUserInvites(guild.id, inviterId);
          stats.code = usedInvite.code;
          stats.total += 1;

          // Check if fake (account created less than 3 days ago)
          const accountAgeDays = (Date.now() - member.user.createdTimestamp) / (1000 * 60 * 60 * 24);
          if (accountAgeDays < 3) {
            stats.fake += 1;
          } else {
            stats.regular += 1;
          }

          if (!memberInviterMap.has(guild.id)) memberInviterMap.set(guild.id, new Map());
          memberInviterMap.get(guild.id)!.set(member.id, inviterId);

          saveInvitesData();
          console.log(`[Invites] ${member.user.tag} joined using invite from ${usedInvite.inviter.tag} (Code: ${usedInvite.code})`);
        }
      } catch (err) {
        console.error('[Invites] guildMemberAdd error:', err);
      }
    });

    client.on('guildMemberRemove', async (member: any) => {
      try {
        const guild = member.guild;
        const inviterId = memberInviterMap.get(guild.id)?.get(member.id);

        if (inviterId) {
          const stats = getUserInvites(guild.id, inviterId);
          stats.left += 1;
          if (stats.regular > 0) stats.regular -= 1;
          saveInvitesData();
        }
      } catch (err) {
        console.error('[Invites] guildMemberRemove error:', err);
      }
    });

    // 4. Interaction Handler: Slash Commands, Buttons, and Modals
    client.on('interactionCreate', async (interaction: any) => {
      try {
        const user = interaction.user;
        const guild = interaction.guild;
        const member = interaction.member;

        // Verify Admin / Staff Permissions helper
        const isAdminOrStaff =
          interaction.memberPermissions?.has(PermissionsBitField.Flags.Administrator) ||
          interaction.memberPermissions?.has(PermissionsBitField.Flags.ManageGuild) ||
          interaction.memberPermissions?.has(PermissionsBitField.Flags.ModerateMembers) ||
          interaction.memberPermissions?.has(PermissionsBitField.Flags.BanMembers) ||
          interaction.memberPermissions?.has(PermissionsBitField.Flags.KickMembers);

        // A. Slash Commands Handler
        if (interaction.isChatInputCommand()) {
          const { commandName } = interaction;

          // STRICT ADMIN CHECK: Block regular players from using admin commands!
          if (ADMIN_COMMANDS.includes(commandName) && !isAdminOrStaff) {
            return await interaction.reply({
              content: '⛔ **عفواً! هذا الأمر مخصص للإدارة وأعضاء الطاقم الإداري فقط ولا يمكنك استخدامه كلاعب أو عضو عادي.**',
              ephemeral: true,
            });
          }

          // Command: /ping
          if (commandName === 'ping') {
            await interaction.reply({
              content: `🏓 بونج! سرعة استجابة البوت: **${client.ws.ping}ms**`,
              ephemeral: true,
            });
          }

          // Command: /ip (Minecraft Hitrex SMP Info)
          else if (commandName === 'ip') {
            const embed = createMinecraftEmbed();
            await interaction.reply({ embeds: [embed] });
          }

          // Command: /invites (-i)
          else if (commandName === 'invites') {
            if (!guild) {
              return await interaction.reply({ content: '⚠️ هذا الأمر متاح داخل السيرفرات فقط.', ephemeral: true });
            }
            const targetUser = interaction.options.getUser('user') || user;
            const embed = await createInvitesEmbed(guild, targetUser);
            await interaction.reply({ embeds: [embed] });
          }

          // Command: /help
          else if (commandName === 'help') {
            const helpEmbed = new EmbedBuilder()
              .setTitle('🛡️ دليل أوامر ديسكورد بوت برو الشامل')
              .setDescription('أهلاً بك! البوت مجهز بأنظمة السيرفر، الدعوات، التذاكر، الرقابة، والذكاء الاصطناعي:')
              .setColor(0x5865f2)
              .addFields(
                {
                  name: '🎮 أوامر اللاعبين العامة (متاحة للجميع)',
                  value: '`/ip` أو `ip` - عرض معلومات سيرفر Hitrex SMP ماين كرافت\n`/invites` أو `-i` أو `i` - فحص إحصائيات دعواتك بالسيرفر\n`/ask [سؤالك]` - سؤال فوري للذكاء الاصطناعي (Gemini)\n`/ping` - سرعة الاستجابة',
                },
                {
                  name: '🤖 الذكاء الاصطناعي التفاعلي (AI Channel)',
                  value: '`/ai setup` - جعل القناة الحالية ترد تلقائياً على أي رسالة (👑 للإدارة)\n`/ai disable` - تعطيل وضع الذكاء الاصطناعي للقناة (👑 للإدارة)\n`/ai chat [سؤال]` - سؤال سريع للذكاء الاصطناعي',
                },
                {
                  name: '🎫 نظام التذاكر المتقدم (Tickets)',
                  value: '`/setup-tickets` - إنشاء لوحة التذاكر التفاعلية (👑 للإدارة فقط)\n`/ticket close` - إغلاق وأرشفة التذكرة\n`/ticket claim` - استلام التذكرة من الطاقم\n`/ticket add [user]` - إضافة عضو للتذكرة (👑 للإدارة)\n`/ticket remove [user]` - إزالة عضو (👑 للإدارة)\n`/ticket rename [name]` - تغيير الاسم (👑 للإدارة)',
                },
                {
                  name: '🔨 الإدارة والإشراف (👑 للإدارة فقط - محمية بالكامل)',
                  value: '`/ban @user [سبب]` - حظر عضو نهائياً\n`/kick @user [سبب]` - طرد عضو من السيرفر\n`/warn @user [سبب]` - توجيه إنذار رسمي مسجل\n`/clear [1-100]` - مسح الرسائل فورياً\n`/slowmode [seconds]` - الوضع البطيء\n`/autoreply add [trigger] [reply]` - إضافة رد تلقائي',
                }
              )
              .setFooter({ text: 'Hitrex SMP Edition · الأوامر الإدارية محمية بالكامل ضد اللاعبين العاديين' });

            await interaction.reply({ embeds: [helpEmbed] });
          }

          // Command: /ai (Subcommands: setup, disable, chat)
          else if (commandName === 'ai') {
            const sub = interaction.options.getSubcommand();

            if (sub === 'setup') {
              if (!isAdminOrStaff) {
                return await interaction.reply({
                  content: '⛔ هذا الأمر مخصص لمدير السيرفر فقط!',
                  ephemeral: true,
                });
              }

              aiChannelIds.add(interaction.channelId);
              saveAiChannels();

              const aiEmbed = new EmbedBuilder()
                .setTitle('✨ تم تفعيل قناة الذكاء الاصطناعي بنجاح!')
                .setDescription(
                  `مرحباً بكم! هذه القناة (<#${interaction.channelId}>) أصبحت الآن **قناة ذكاء اصطناعي تفاعلية**.\n\nأي رسالة تكتبها هنا بدون أوامر وبدون منشن سيرد عليها **Gemini 3.8 Flash** فورياً وتلقائياً!`
                )
                .setColor(0x57f287)
                .setFooter({ text: 'مفعل بواسطة إدارة السيرفر · جرب كتابة أي سؤال في الشات الآن!' });

              await interaction.reply({ embeds: [aiEmbed] });
            } else if (sub === 'disable') {
              if (!isAdminOrStaff) {
                return await interaction.reply({
                  content: '⛔ هذا الأمر مخصص لمدير السيرفر فقط!',
                  ephemeral: true,
                });
              }

              aiChannelIds.delete(interaction.channelId);
              saveAiChannels();

              await interaction.reply({
                content: 'ℹ️ تم إلغاء تفعيل وضع الذكاء الاصطناعي التلقائي في هذه القناة.',
                ephemeral: true,
              });
            } else if (sub === 'chat') {
              const prompt = interaction.options.getString('prompt');
              await interaction.deferReply();
              const reply = await askGemini(prompt);
              await interaction.editReply({
                content: `**سؤال:** ${prompt}\n\n**إجابة الذكاء الاصطناعي:**\n${reply.slice(0, 1900)}`,
              });
            }
          }

          // Command: /ask
          else if (commandName === 'ask') {
            const prompt = interaction.options.getString('prompt');
            await interaction.deferReply();
            const reply = await askGemini(prompt);
            await interaction.editReply({
              content: `**سؤال:** ${prompt}\n\n**إجابة الذكاء الاصطناعي (Gemini 3.8 Flash):**\n${reply.slice(0, 1900)}`,
            });
          }

          // Command: /setup-tickets (Admin Only)
          else if (commandName === 'setup-tickets') {
            const ticketEmbed = new EmbedBuilder()
              .setTitle('🎫 مركز خدمة الأعضاء والدعم الفني')
              .setDescription(
                'مرحباً بك في مركز المساعدة الرسمي للسيرفر! اضغط على القسم المطلوب أدناه لفتح تذكرة ومتابعة طلبك مباشرة مع الطاقم الإداري.\n\n🛠️ **الدعم الفني**: للمشاكل التقنية، أعطال السيرفر، والاستفسارات.\n💳 **المبيعات**: لشراء الرتب، الاشتراكات، ومشتريات المتجر.\n📩 **الشكاوى والمقترحات**: لرفع بلاغ رسمي ضد مخالف أو تقديم فكرة.\n❓ **استفسارات عامة**: لأي سؤال أو استفسار عام.'
              )
              .setColor(0x00b0f4)
              .setFooter({ text: 'نظام التذاكر الذكي · انقر على الزر لتعبئة نموذج طلبك' });

            const row = new ActionRowBuilder<any>().addComponents(
              new ButtonBuilder()
                .setCustomId('btn_open_support')
                .setLabel('دعم فني')
                .setStyle(ButtonStyle.Primary)
                .setEmoji('🛠️'),
              new ButtonBuilder()
                .setCustomId('btn_open_billing')
                .setLabel('مبيعات')
                .setStyle(ButtonStyle.Success)
                .setEmoji('💳'),
              new ButtonBuilder()
                .setCustomId('btn_open_report')
                .setLabel('شكوى / بلاغ')
                .setStyle(ButtonStyle.Danger)
                .setEmoji('📩'),
              new ButtonBuilder()
                .setCustomId('btn_open_general')
                .setLabel('استفسار عام')
                .setStyle(ButtonStyle.Secondary)
                .setEmoji('❓')
            );

            await interaction.reply({ embeds: [ticketEmbed], components: [row] });
          }

          // Command: /ticket (close, claim, add, remove, rename)
          else if (commandName === 'ticket') {
            const sub = interaction.options.getSubcommand();
            const channel = interaction.channel;

            if (!channel.name.startsWith('ticket-')) {
              return await interaction.reply({
                content: '⚠️ هذا الأمر متاح فقط داخل رومات التذاكر (التي تبدأ بـ ticket-).',
                ephemeral: true,
              });
            }

            if (sub === 'close') {
              await interaction.reply('🔒 **جاري حفظ الأرشيف وحذف روم التذكرة خلال 5 ثوانٍ...**');
              setTimeout(async () => {
                try {
                  await channel.delete();
                } catch {}
              }, 5000);
            } else if (sub === 'claim') {
              if (!isAdminOrStaff) {
                return await interaction.reply({ content: '⛔ هذا الإجراء مخصص لطاقم الدعم فقط.', ephemeral: true });
              }
              await interaction.reply({
                content: `🙋‍♂️ **تم استلام التذكرة رسمياً من قبل المشرف <@${user.id}>! هو المسؤول عن طلبك الآن.**`,
              });
            } else if (sub === 'add') {
              if (!isAdminOrStaff) {
                return await interaction.reply({ content: '⛔ هذا الإجراء مخصص لطاقم الدعم فقط.', ephemeral: true });
              }
              const target = interaction.options.getUser('user');
              await channel.permissionOverwrites.edit(target.id, {
                ViewChannel: true,
                SendMessages: true,
                AttachFiles: true,
              });
              await interaction.reply({
                content: `✅ تمت إضافة العضو <@${target.id}> إلى التذكرة بنجاح!`,
              });
            } else if (sub === 'remove') {
              if (!isAdminOrStaff) {
                return await interaction.reply({ content: '⛔ هذا الإجراء مخصص لطاقم الدعم فقط.', ephemeral: true });
              }
              const target = interaction.options.getUser('user');
              await channel.permissionOverwrites.delete(target.id);
              await interaction.reply({
                content: `✅ تمت إزالة العضو <@${target.id}> من التذكرة!`,
              });
            } else if (sub === 'rename') {
              if (!isAdminOrStaff) {
                return await interaction.reply({ content: '⛔ هذا الإجراء مخصص لطاقم الدعم فقط.', ephemeral: true });
              }
              const newName = interaction.options.getString('name');
              await channel.setName(`ticket-${newName}`);
              await interaction.reply({
                content: `✅ تم تغيير اسم التذكرة إلى: **ticket-${newName}**`,
              });
            }
          }

          // Command: /autoreply (Admin Only)
          else if (commandName === 'autoreply') {
            const sub = interaction.options.getSubcommand();
            if (sub === 'add') {
              const trigger = interaction.options.getString('trigger').toLowerCase().trim();
              const reply = interaction.options.getString('reply').trim();

              const newAr: AutoResponder = {
                id: `ar-${Date.now()}`,
                trigger,
                reply,
                matchType: 'contains',
                enabled: true,
              };

              autoResponders.unshift(newAr);
              saveAutoResponders();

              await interaction.reply({
                content: `✅ تم إضافة الرد التلقائي بنجاح!\n**الكلمة:** \`${trigger}\`\n**الرد:** ${reply}`,
                ephemeral: true,
              });
            } else if (sub === 'list') {
              const list = autoResponders
                .map((r, i) => `**${i + 1}. [${r.id}]** \`${r.trigger}\` ➜ ${r.reply.slice(0, 40)}... (${r.enabled ? '🟢 مفعل' : '🔴 معطل'})`)
                .join('\n');

              await interaction.reply({
                content: `📋 **قائمة الردود التلقائية (${autoResponders.length}):**\n\n${list || 'لا توجد ردود مسجلة.'}`,
                ephemeral: true,
              });
            } else if (sub === 'delete') {
              const id = interaction.options.getString('id');
              const prevLen = autoResponders.length;
              autoResponders = autoResponders.filter((r) => r.id !== id);
              saveAutoResponders();

              if (autoResponders.length < prevLen) {
                await interaction.reply({ content: `✅ تم حذف الرد التلقائي ذو المعرف \`${id}\`.`, ephemeral: true });
              } else {
                await interaction.reply({ content: `⚠️ لم يتم العثور على رد تلقائي بالمعرف \`${id}\`.`, ephemeral: true });
              }
            }
          }

          // Moderation: /clear
          else if (commandName === 'clear') {
            const amount = interaction.options.getInteger('amount');
            if (interaction.channel?.bulkDelete) {
              await interaction.channel.bulkDelete(amount, true);
              await interaction.reply({
                content: `🧹 تم مسح **${amount}** رسالة بنجاح!`,
                ephemeral: true,
              });
            }
          }

          // Moderation: /warn
          else if (commandName === 'warn') {
            const target = interaction.options.getUser('user');
            const reason = interaction.options.getString('reason');

            const warnEmbed = new EmbedBuilder()
              .setTitle('⚠️ إنذار رسمي مسجل')
              .setDescription(`تم توجيه إنذار رسمي للعضو <@${target.id}>.\n**السبب:** ${reason}\n**المشرف المسؤول:** <@${user.id}>`)
              .setColor(0xfee75c)
              .setTimestamp();

            await interaction.reply({ embeds: [warnEmbed] });
          }

          // Moderation: /ban
          else if (commandName === 'ban') {
            const target = interaction.options.getUser('user');
            const reason = interaction.options.getString('reason') || 'مخالفة القوانين';

            if (guild) {
              try {
                await guild.members.ban(target.id, { reason });
                await interaction.reply({
                  content: `🔨 تم حظر العضو **${target.tag}** نهائياً من السيرفر.\n**السبب:** ${reason}`,
                });
              } catch {
                await interaction.reply({
                  content: `⚠️ تعذر حظر العضو: قد تكون رتبته أعلى من رتبة البوت.`,
                  ephemeral: true,
                });
              }
            }
          }

          // Moderation: /kick
          else if (commandName === 'kick') {
            const target = interaction.options.getUser('user');
            const reason = interaction.options.getString('reason') || 'مخالفة القوانين';

            if (guild) {
              try {
                const targetMember = await guild.members.fetch(target.id);
                await targetMember.kick(reason);
                await interaction.reply({
                  content: `🚪 تم طرد العضو **${target.tag}** من السيرفر.\n**السبب:** ${reason}`,
                });
              } catch {
                await interaction.reply({
                  content: `⚠️ تعذر طرد العضو: تحقق من صلاحيات رتبة البوت.`,
                  ephemeral: true,
                });
              }
            }
          }

          // Moderation: /slowmode
          else if (commandName === 'slowmode') {
            const seconds = interaction.options.getInteger('seconds');
            if (interaction.channel?.setRateLimitPerUser) {
              await interaction.channel.setRateLimitPerUser(seconds);
              await interaction.reply({
                content: `⏱️ تم ضبط الوضع البطيء للروم على: **${seconds} ثانية**!`,
                ephemeral: true,
              });
            }
          }
        }

        // B. Button Handlers
        else if (interaction.isButton()) {
          const btnId = interaction.customId;

          // Open Ticket Modal Form
          if (btnId.startsWith('btn_open_')) {
            const dept = btnId.replace('btn_open_', '');
            const deptNames: Record<string, string> = {
              support: 'الدعم الفني',
              billing: 'المبيعات والاشتراكات',
              report: 'الشكاوى والمقترحات',
              general: 'استفسار عام',
            };

            const modal = new ModalBuilder()
              .setCustomId(`ticket_modal_${dept}`)
              .setTitle(`فتح تذكرة: ${deptNames[dept] || 'دعم فني'}`);

            const subjectInput = new TextInputBuilder()
              .setCustomId('ticket_subject')
              .setLabel('موضوع التذكرة باختصار')
              .setPlaceholder('مثال: مشكلة في السيرفر، شراء رتبة، بلاغ...')
              .setStyle(TextInputStyle.Short)
              .setRequired(true)
              .setMaxLength(100);

            const detailsInput = new TextInputBuilder()
              .setCustomId('ticket_details')
              .setLabel('التفاصيل الكاملة لطلبك')
              .setPlaceholder('يرجى كتابة التفاصيل لنتمكن من مساعدتك بأسرع شكل ممكن...')
              .setStyle(TextInputStyle.Paragraph)
              .setRequired(false)
              .setMaxLength(1000);

            const row1 = new ActionRowBuilder<any>().addComponents(subjectInput);
            const row2 = new ActionRowBuilder<any>().addComponents(detailsInput);

            modal.addComponents(row1, row2);
            await interaction.showModal(modal);
          }

          // Ticket Channel Action: Close Ticket
          else if (btnId === 'ticket_close_action') {
            const channel = interaction.channel;
            await interaction.reply('🔒 **جاري أرشفة المحادثة وحذف التذكرة خلال 5 ثوانٍ...**');

            setTimeout(async () => {
              try {
                await channel.delete();
              } catch {}
            }, 5000);
          }

          // Ticket Channel Action: Claim Ticket
          else if (btnId === 'ticket_claim_action') {
            await interaction.reply({
              content: `🙋‍♂️ **تم استلام التذكرة من قبل المشرف <@${user.id}>! هو المسؤول عن متابعة طلبك الآن.**`,
            });
          }

          // Ticket Channel Action: Export Transcript
          else if (btnId === 'ticket_transcript_action') {
            await interaction.deferReply({ ephemeral: true });
            try {
              const channel = interaction.channel;
              const msgs = await channel.messages.fetch({ limit: 100 });
              const sorted = Array.from(msgs.values()).reverse();

              const transcriptText = [
                `===========================================`,
                `أرشيف تذكرة ديسكورد: #${channel.name}`,
                `السيرفر: ${guild?.name || 'سيرفر الدعم'}`,
                `المستخرج: ${user.tag} (${user.id})`,
                `تاريخ الاستخراج: ${new Date().toLocaleString('ar-SA')}`,
                `===========================================`,
                '',
                ...sorted.map((m: any) => `[${m.createdAt.toLocaleTimeString()}] ${m.author.tag}: ${m.cleanContent}`),
              ].join('\n');

              const attachment = new AttachmentBuilder(Buffer.from(transcriptText, 'utf-8'), {
                name: `transcript-${channel.name}.txt`,
              });

              await interaction.editReply({
                content: '📄 **تم استخراج تفريغ المحادثة (Transcript) بنجاح:**',
                files: [attachment],
              });
            } catch (tErr: any) {
              await interaction.editReply({
                content: `⚠️ تعذر استخراج الأرشيف: ${tErr.message}`,
              });
            }
          }

          // Ticket Channel Action: AI Troubleshooting Help
          else if (btnId === 'ticket_ai_action') {
            await interaction.deferReply();
            try {
              const channel = interaction.channel;
              const msgs = await channel.messages.fetch({ limit: 10 });
              const sorted = Array.from(msgs.values()).reverse();
              const recentConversation = sorted.map((m: any) => `${m.author.username}: ${m.cleanContent}`).join('\n');

              const aiRes = await askGemini(
                `إليك هذه التذكرة في سيرفر ديسكورد:\n${recentConversation}\n\nقدم حلاً عملياً للمشكلة أو رداً احترافياً لمساعدة العضو فورياً.`,
                'أنت خبير دعم ديسكورد بالذكاء الاصطناعي. أجب باللغة العربية مع نقاط منسقة واحترافية.'
              );

              const aiEmbed = new EmbedBuilder()
                .setTitle('🤖 حل مقترح من الذكاء الاصطناعي (Gemini 3.8 Flash)')
                .setDescription(aiRes.slice(0, 1950))
                .setColor(0xfee75c);

              await interaction.editReply({ embeds: [aiEmbed] });
            } catch (aiErr: any) {
              await interaction.editReply({
                content: `⚠️ تعذر تشغيل المساعد الذكي: ${aiErr.message}`,
              });
            }
          }
        }

        // C. Modal Submit Handler (Ticket Creation)
        else if (interaction.isModalSubmit()) {
          if (interaction.customId.startsWith('ticket_modal_')) {
            const dept = interaction.customId.replace('ticket_modal_', '');
            const deptNames: Record<string, string> = {
              support: 'دعم فني',
              billing: 'مبيعات',
              report: 'شكوى',
              general: 'استفسار عام',
            };

            const subject = interaction.fields.getTextInputValue('ticket_subject');
            const details = interaction.fields.getTextInputValue('ticket_details');

            if (guild) {
              const cleanUsername = user.username.toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 10);

              // Check existing active ticket
              const existingTicket = guild.channels.cache.find(
                (c: any) => c.name.startsWith(`ticket-${cleanUsername}`) && c.type === ChannelType.GuildText
              );

              if (existingTicket) {
                return await interaction.reply({
                  content: `⚠️ لديك تذكرة مفتوحة بالفعل في الروم: <#${existingTicket.id}>. يرجى إنهائها أولاً!`,
                  ephemeral: true,
                });
              }

              // Find or create Category: 🎫 │ التذاكر
              let category = guild.channels.cache.find(
                (c: any) => c.type === ChannelType.GuildCategory && (c.name.includes('التذاكر') || c.name.includes('TICKETS'))
              );
              if (!category) {
                try {
                  category = await guild.channels.create({
                    name: '🎫 │ التذاكر',
                    type: ChannelType.GuildCategory,
                  });
                } catch {}
              }

              // Create Ticket Channel
              const ticketChannel = await guild.channels.create({
                name: `ticket-${cleanUsername || 'user'}-${dept}`,
                type: ChannelType.GuildText,
                parent: category ? category.id : null,
                permissionOverwrites: [
                  {
                    id: guild.id,
                    deny: [PermissionsBitField.Flags.ViewChannel],
                  },
                  {
                    id: user.id,
                    allow: [
                      PermissionsBitField.Flags.ViewChannel,
                      PermissionsBitField.Flags.SendMessages,
                      PermissionsBitField.Flags.AttachFiles,
                      PermissionsBitField.Flags.EmbedLinks,
                      PermissionsBitField.Flags.ReadMessageHistory,
                    ],
                  },
                  {
                    id: client.user ? client.user.id : (guild.members.me?.id || guild.id),
                    allow: [
                      PermissionsBitField.Flags.ViewChannel,
                      PermissionsBitField.Flags.SendMessages,
                      PermissionsBitField.Flags.ManageChannels,
                      PermissionsBitField.Flags.ManageMessages,
                      PermissionsBitField.Flags.EmbedLinks,
                    ],
                  },
                ],
              });

              // Ticket Control Card
              const ticketEmbed = new EmbedBuilder()
                .setTitle(`🎫 تذكرة ${deptNames[dept]} | #${ticketChannel.name}`)
                .setDescription(`مرحباً <@${user.id}>! تم فتح تذكرتك وسيقوم فريق الدعم بالرد قريباً.`)
                .setColor(0x57f287)
                .addFields(
                  { name: '📌 عنوان المشكلة', value: subject, inline: true },
                  { name: '🏷️ القسم', value: deptNames[dept], inline: true },
                  { name: '🟢 الحالة', value: 'مفتوحة (بانتظار المشرف)', inline: true },
                  { name: '📝 التفاصيل المسجلة', value: details || 'لا توجد تفاصيل إضافية' }
                )
                .setFooter({ text: 'لوحة تحكم التذكرة · استخدم الأزرار أدناه للتحكم' })
                .setTimestamp();

              const controlRow = new ActionRowBuilder<any>().addComponents(
                new ButtonBuilder()
                  .setCustomId('ticket_close_action')
                  .setLabel('إغلاق وأرشفة')
                  .setStyle(ButtonStyle.Danger)
                  .setEmoji('🔒'),
                new ButtonBuilder()
                  .setCustomId('ticket_claim_action')
                  .setLabel('استلام التذكرة')
                  .setStyle(ButtonStyle.Secondary)
                  .setEmoji('🙋‍♂️'),
                new ButtonBuilder()
                  .setCustomId('ticket_transcript_action')
                  .setLabel('تفريغ المحادثة')
                  .setStyle(ButtonStyle.Primary)
                  .setEmoji('📄'),
                new ButtonBuilder()
                  .setCustomId('ticket_ai_action')
                  .setLabel('حلول الذكاء الاصطناعي')
                  .setStyle(ButtonStyle.Success)
                  .setEmoji('🤖')
              );

              await ticketChannel.send({
                content: `<@${user.id}> | تم فتح تذكرتك بنجاح.`,
                embeds: [ticketEmbed],
                components: [controlRow],
              });

              await interaction.reply({
                content: `✅ تم فتح تذكرتك بنجاح في: <#${ticketChannel.id}>`,
                ephemeral: true,
              });

              // Instant Smart AI Preliminary Troubleshooting
              try {
                const triageText = await askGemini(
                  `المستخدم فتح تذكرة دعم بعنوان "${subject}" وتفاصيل: "${details}". قدم له 2 إلى 3 نصائح عملية وموجزة جداً باللغة العربية لتفقدها ريثما يصل المشرف.`,
                  'أنت المساعد الذكي الترحيبي في ديسكورد. أجب بنقاط موجزة وودودة.'
                );

                if (triageText) {
                  const triageEmbed = new EmbedBuilder()
                    .setTitle('🤖 نصائح أولية من المساعد الذكي (Gemini AI)')
                    .setDescription(triageText.slice(0, 1900))
                    .setColor(0xfee75c)
                    .setFooter({ text: 'إرشادات أولية لمساعدتك ريثما ينضم أحد ممثلي الدعم' });

                  await ticketChannel.send({ embeds: [triageEmbed] });
                }
              } catch {}
            }
          }
        }
      } catch (intErr: any) {
        console.error('[Discord Bot] Interaction Error:', intErr);
        if (!interaction.replied && !interaction.deferred) {
          await interaction.reply({
            content: `حدث خطأ أثناء معالجة الأمر: ${intErr?.message}`,
            ephemeral: true,
          }).catch(() => {});
        }
      }
    });

    // 5. Message Create: Text Triggers, Invites (-i / i), Minecraft IP (ip), AI Channels, Auto-Responders
    client.on('messageCreate', async (message: any) => {
      if (message.author.bot) return;

      const raw = message.content.trim();
      const lower = raw.toLowerCase();
      const channelId = message.channel.id;
      const guild = message.guild;

      // TRIGGER 1: Minecraft Server IP ("ip", "-ip", "!ip", "/ip", "اي بي", "سيرفر")
      if (
        lower === 'ip' ||
        lower === '-ip' ||
        lower === '!ip' ||
        lower === '/ip' ||
        lower === 'اي بي' ||
        lower === 'سيرفر'
      ) {
        const embed = createMinecraftEmbed();
        return await message.reply({ embeds: [embed] }).catch(() => {});
      }

      // TRIGGER 2: Invites System ("-i", "i", "-i @user", "i @user")
      if (
        lower === '-i' ||
        lower === 'i' ||
        lower.startsWith('-i ') ||
        lower.startsWith('i ') ||
        lower === '!invites' ||
        lower === '-invites'
      ) {
        if (guild) {
          const mentionedUser = message.mentions.users.first() || message.author;
          const embed = await createInvitesEmbed(guild, mentionedUser);
          return await message.reply({ embeds: [embed] }).catch(() => {});
        }
      }

      // TRIGGER 3: Text AI Command ("-ai setup", "-ai disable", "-ask [prompt]", "-ai [prompt]")
      if (lower === '-ai setup' || lower === '!ai setup') {
        const isAdmin = message.member?.permissions.has(PermissionsBitField.Flags.Administrator);
        if (!isAdmin) {
          return await message.reply('⛔ هذا الأمر مخصص لمدير السيرفر فقط!').catch(() => {});
        }

        aiChannelIds.add(channelId);
        saveAiChannels();

        const aiEmbed = new EmbedBuilder()
          .setTitle('✨ تم تفعيل قناة الذكاء الاصطناعي بنجاح!')
          .setDescription(
            `أهلاً بكم! أصبحت هذه القناة (<#${channelId}>) **قناة ذكاء اصطناعي تفاعلية**.\nأي رسالة تكتب هنا سيقوم **Gemini 3.8 Flash** بالرد عليها تلقائياً دون منشن أو أوامر!`
          )
          .setColor(0x57f287);

        return await message.reply({ embeds: [aiEmbed] }).catch(() => {});
      }

      if (lower === '-ai disable' || lower === '!ai disable') {
        const isAdmin = message.member?.permissions.has(PermissionsBitField.Flags.Administrator);
        if (!isAdmin) {
          return await message.reply('⛔ هذا الأمر مخصص لمدير السيرفر فقط!').catch(() => {});
        }

        aiChannelIds.delete(channelId);
        saveAiChannels();
        return await message.reply('ℹ️ تم إلغاء تفعيل وضع الذكاء الاصطناعي في هذه القناة.').catch(() => {});
      }

      if (lower.startsWith('-ask ') || lower.startsWith('-ai ')) {
        const prompt = raw.slice(5).trim();
        if (prompt) {
          message.channel.sendTyping().catch(() => {});
          const reply = await askGemini(prompt);
          return await message.reply(reply.slice(0, 1950)).catch(() => {});
        }
      }

      // TRIGGER 4: Dedicated AI Channel (Any message written in this channel gets an AI response!)
      if (aiChannelIds.has(channelId)) {
        try {
          message.channel.sendTyping().catch(() => {});
          const aiReply = await askGemini(raw);
          return await message.reply(aiReply.slice(0, 1950)).catch(() => {});
        } catch (e) {
          console.error('[AI Channel Error]:', e);
        }
      }

      // TRIGGER 5: Mention Bot or Inline Reply to Bot's Message
      const isMentioned =
        client.user &&
        (message.mentions.has(client.user) ||
          message.content.includes(`<@${client.user.id}>`) ||
          message.content.includes(`<@!${client.user.id}>`));

      const isReplyingToBot =
        message.reference?.messageId &&
        message.channel.messages.cache.get(message.reference.messageId)?.author.id === client.user?.id;

      if (isMentioned || isReplyingToBot) {
        const cleanContent = raw
          .replace(new RegExp(`<@!?${client.user?.id}>`, 'g'), '')
          .trim();

        if (cleanContent) {
          try {
            message.channel.sendTyping().catch(() => {});
            const aiReply = await askGemini(cleanContent);
            return await message.reply(aiReply.slice(0, 1950)).catch(() => {});
          } catch (err) {
            console.error('[AI Mention Error]:', err);
          }
        }
      }

      // TRIGGER 6: Auto-Responders Check
      for (const responder of autoResponders) {
        if (!responder.enabled) continue;
        const trig = responder.trigger.toLowerCase();
        let matched = false;

        if (responder.matchType === 'exact') {
          matched = lower === trig;
        } else if (responder.matchType === 'contains') {
          matched = lower.includes(trig);
        } else if (responder.matchType === 'startsWith') {
          matched = lower.startsWith(trig);
        }

        if (matched) {
          return await message.reply(responder.reply).catch(() => {});
        }
      }
    });

    client.on('error', (err: any) => {
      console.error('[Discord Bot] Client Error:', err);
      botState.status = 'error';
      botState.errorMessage = err?.message || 'خطأ غير معروف في اتصال البوت';
    });

    await client.login(token);
    discordClient = client;
    return { success: true };
  } catch (err: any) {
    botState.status = 'error';
    botState.errorMessage = err?.message || 'فشل الاتصال بدسكورد، تأكد من صحة التوكين والـ Privileged Intents';
    console.error('[Discord Bot] Login failed:', err);
    return { success: false, error: botState.errorMessage };
  }
}

// REST API Endpoints for Dashboard

// 1. Bot Status
app.get('/api/bot/status', (req, res) => {
  res.json({
    ...botState,
    uptimeHuman: botState.uptime ? Math.floor((Date.now() - botState.uptime) / 1000) : 0,
  });
});

// 2. Connect Bot with Token
app.post('/api/bot/connect', async (req, res) => {
  const { token } = req.body;
  const tokenToUse = token || process.env.DISCORD_BOT_TOKEN;

  if (!tokenToUse) {
    return res.status(400).json({
      error: 'يرجى تزويد توكين البوت (Bot Token) من Discord Developer Portal.',
    });
  }

  const result = await connectDiscordBot(tokenToUse);
  if (result.success) {
    res.json({ success: true, message: 'تم الاتصال ببوت ديسكورد بنجاح!' });
  } else {
    res.status(400).json({ success: false, error: result.error });
  }
});

// 3. Disconnect Bot
app.post('/api/bot/disconnect', async (req, res) => {
  if (discordClient) {
    try {
      await discordClient.destroy();
      discordClient = null;
    } catch {}
  }
  botState.status = 'offline';
  botState.tag = null;
  botState.id = null;
  botState.errorMessage = null;
  res.json({ success: true, message: 'تم قطع الاتصال بالبوت.' });
});

// 4. Server-Side Gemini AI Endpoint (/api/ai/ask)
app.post('/api/ai/ask', async (req, res) => {
  try {
    const { prompt, persona } = req.body;
    if (!prompt) {
      return res.status(400).json({ error: 'المحتوى مطلوب' });
    }

    const reply = await askGemini(prompt, persona);
    res.json({ text: reply });
  } catch (err: any) {
    console.error('Server AI Error:', err);
    res.status(500).json({ error: err?.message || 'خطأ في معالجة طلب الذكاء الاصطناعي' });
  }
});

// 5. AI Ticket Summarizer (/api/ai/summarize-ticket)
app.post('/api/ai/summarize-ticket', async (req, res) => {
  try {
    const { messages } = req.body;
    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: 'قائمة الرسائل مطلوبة' });
    }

    const conversationText = messages.map((m: any) => `${m.author}: ${m.text}`).join('\n');
    const summary = await askGemini(
      `قم بتلخيص هذه المحادثة الخاصة بتذكرة دعم ديسكورد، واستخرج المشكلة الأساسية والحل المقترح في 3 أسطر باللغة العربية:\n\n${conversationText}`,
      'أنت محلل تذاكر دعم فني محترف في ديسكورد.'
    );

    res.json({ summary });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'فشل في تلخيص التذكرة' });
  }
});

// 6. Auto-Responders Endpoints
app.get('/api/auto-responders', (req, res) => {
  res.json(autoResponders);
});

app.post('/api/auto-responders', (req, res) => {
  const newList = req.body;
  if (Array.isArray(newList)) {
    autoResponders = newList;
    saveAutoResponders();
    res.json({ success: true, count: autoResponders.length });
  } else {
    res.status(400).json({ error: 'يجب إرسال مصفوفة من الردود' });
  }
});

// 7. Complete Standalone Bot Code Generator for Download / Copy
app.get('/api/bot/source-code', (req, res) => {
  const indexJs = `// Discord Bot Engine with Tickets, Moderation, Invites, and Gemini AI
require('dotenv').config();
const {
  Client,
  GatewayIntentBits,
  Partials,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  PermissionsBitField,
  REST,
  Routes,
  SlashCommandBuilder
} = require('discord.js');
const { GoogleGenAI } = require('@google/genai');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildInvites
  ],
  partials: [Partials.Channel, Partials.Message]
});

// Initialize Gemini AI
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: { headers: { 'User-Agent': 'aistudio-build' } }
});

const aiChannels = new Set();

client.once('ready', async () => {
  console.log(\`✅ Bot is online as \${client.user.tag}\`);
  client.user.setActivity('Hitrex SMP | /help', { type: 3 });
});

// Message listener for "ip", "-i", "i", and Dedicated AI Channels
client.on('messageCreate', async (message) => {
  if (message.author.bot) return;
  const content = message.content.trim().toLowerCase();

  // 1. Minecraft Server IP
  if (content === 'ip' || content === '-ip' || content === '!ip' || content === 'سيرفر') {
    const embed = new EmbedBuilder()
      .setTitle('⛏️ معلومات سيرفر Hitrex SMP')
      .setDescription('سيرفر سرفايفل ماين كرافت ممتع يدعم الجافا والجوال!')
      .setColor(0x57f287)
      .addFields(
        { name: '🌐 عنوان السيرفر (IP)', value: 'hitrexsmp.halix.gg', inline: true },
        { name: '🔌 منفذ الجافا', value: '25565', inline: true },
        { name: '📱 منفذ الجوال (Bedrock)', value: '19132', inline: true }
      );
    return message.reply({ embeds: [embed] });
  }

  // 2. Invites (-i or i)
  if (content === '-i' || content === 'i' || content.startsWith('-i ')) {
    const embed = new EmbedBuilder()
      .setTitle(\`📨 إحصائيات دعوات \${message.author.username}\`)
      .setColor(0x5865f2)
      .addFields(
        { name: '✨ إجمالي الدعوات', value: '15 دعوة', inline: true },
        { name: '✅ دعوات حقيقية', value: '12', inline: true },
        { name: '🚪 غادروا', value: '3', inline: true }
      );
    return message.reply({ embeds: [embed] });
  }

  // 3. AI Dedicated Channel or Mentions
  if (aiChannels.has(message.channel.id) || message.mentions.has(client.user)) {
    try {
      message.channel.sendTyping();
      const res = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: message.content
      });
      message.reply(res.text.slice(0, 1950));
    } catch (e) {
      console.error(e);
    }
  }
});

client.login(process.env.DISCORD_BOT_TOKEN);
`;

  const packageJson = JSON.stringify(
    {
      name: 'discord-bot-pro',
      version: '1.0.0',
      description: 'Complete Discord Bot with Tickets, Invites, and Gemini AI',
      main: 'index.js',
      scripts: {
        start: 'node index.js',
      },
      dependencies: {
        'discord.js': '^14.16.3',
        '@google/genai': '^2.4.0',
        dotenv: '^16.4.5',
      },
    },
    null,
    2
  );

  const envExample = `# Discord Bot Token from Discord Developer Portal
DISCORD_BOT_TOKEN=YOUR_DISCORD_BOT_TOKEN_HERE

# Gemini API Key for AI features
GEMINI_API_KEY=YOUR_GEMINI_API_KEY_HERE
`;

  res.json({
    'index.js': indexJs,
    'package.json': packageJson,
    '.env.example': envExample,
  });
});

// Start dev server with Vite integration
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';
  const httpServer = http.createServer(app);

  if (!isProd) {
    const isHmrDisabled = process.env.DISABLE_HMR === 'true';
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: isHmrDisabled ? false : { server: httpServer },
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  // Auto-connect with user token if present
  if (process.env.DISCORD_BOT_TOKEN) {
    console.log('[Discord Bot] Found DISCORD_BOT_TOKEN in env, connecting...');
    connectDiscordBot(process.env.DISCORD_BOT_TOKEN);
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
