import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { DiscordSimulator } from './components/DiscordSimulator';
import { BotConnection } from './components/BotConnection';
import { TicketsManager } from './components/TicketsManager';
import { ModerationManager } from './components/ModerationManager';
import { AiManager } from './components/AiManager';
import { InvitesManager } from './components/InvitesManager';
import { AutoRespondersManager } from './components/AutoRespondersManager';
import { CommandsReference } from './components/CommandsReference';
import {
  ActiveTab,
  BotStatusResponse,
  SimulatedTicket,
  ModerationLog,
} from './types';
import { Key, X, CheckCircle2 } from 'lucide-react';

const INITIAL_STATUS: BotStatusResponse = {
  status: 'offline',
  tag: null,
  id: null,
  ping: 0,
  uptime: 0,
  uptimeHuman: 0,
  guildsCount: 0,
  tokenConfigured: false,
  errorMessage: null,
};

const INITIAL_TICKETS: SimulatedTicket[] = [
  {
    id: 'ticket-001',
    channelName: 'ticket-دعم-فني-1',
    creator: 'خالد (عضو)',
    category: 'support',
    status: 'open',
    createdAt: 'اليوم في 12:00 م',
    messages: [
      {
        author: 'DiscordBot Pro',
        text: 'أهلاً بك في تذكرة الدعم الفني! يرجى توضيح مشكلتك بالتفصيل.',
        time: '12:00 م',
      },
      {
        author: 'خالد (عضو)',
        text: 'السلام عليكم، عندي استفسار عن كيفية الدخول لسيرفر hitrexsmp.halix.gg بالجوال، هل المنفذ 19132 شغال؟',
        time: '12:02 م',
      },
    ],
    aiSummary:
      'المشكلة: استفسار العضو خالد عن كيفية الدخول لسيرفر Hitrex SMP من الجوال (Bedrock).\nالحل المقترح: تأكيد أن الآي بي hitrexsmp.halix.gg ومنفذ الجوال 19132 متاحان لجميع إصدارات البيدروك.',
  },
];

const INITIAL_LOGS: ModerationLog[] = [
  {
    id: 'log-1',
    action: 'warn',
    targetUser: '@عضو_مخالف',
    moderator: 'Auto-Mod (AI)',
    reason: 'إرسال روابط دعوة لسيرفرات أخرى دون إذن',
    timestamp: 'اليوم في 11:30 ص',
  },
  {
    id: 'log-2',
    action: 'timeout',
    targetUser: '@سبامر_123',
    moderator: 'المشرف عبد الله',
    reason: 'تكرار المنشن المزعج في الشات العام (10 دقائق)',
    timestamp: 'اليوم في 10:15 ص',
  },
];

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('simulator');
  const [botStatus, setBotStatus] = useState<BotStatusResponse>(INITIAL_STATUS);
  const [tickets, setTickets] = useState<SimulatedTicket[]>(INITIAL_TICKETS);
  const [logs, setLogs] = useState<ModerationLog[]>(INITIAL_LOGS);
  const [isConnectModalOpen, setIsConnectModalOpen] = useState(false);
  const [modalToken, setModalToken] = useState('');
  const [modalLoading, setModalLoading] = useState(false);
  const [modalError, setModalError] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Fetch Bot Status from backend
  const fetchStatus = async () => {
    try {
      const res = await fetch('/api/bot/status');
      if (res.ok) {
        const data = await res.json();
        setBotStatus(data);
      }
    } catch {
      // offline or simulated mode
    }
  };

  useEffect(() => {
    fetchStatus();
    const interval = setInterval(fetchStatus, 10000);
    return () => clearInterval(interval);
  }, []);

  const handleConnectToken = async (token: string) => {
    try {
      const res = await fetch('/api/bot/connect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        await fetchStatus();
        showToast('تم الاتصال ببوت ديسكورد بنجاح وبدء تشغيل الأنظمة!');
        return { success: true };
      } else {
        return { success: false, error: data.error || 'فشل الاتصال بدسكورد' };
      }
    } catch (err: any) {
      return { success: false, error: err.message || 'خطأ في الشبكة' };
    }
  };

  const handleDisconnectBot = async () => {
    try {
      await fetch('/api/bot/disconnect', { method: 'POST' });
      await fetchStatus();
      showToast('تم فصل الاتصال بالبوت.');
    } catch {}
  };

  const handleModalSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!modalToken.trim()) return;
    setModalLoading(true);
    setModalError(null);

    const result = await handleConnectToken(modalToken.trim());
    setModalLoading(false);

    if (result.success) {
      setIsConnectModalOpen(false);
      setModalToken('');
    } else {
      setModalError(result.error || 'فشل الاتصال، تحقق من صحة التوكين');
    }
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Ticket actions
  const handleAddTicket = (newTicket: SimulatedTicket) => {
    setTickets((prev) => [newTicket, ...prev]);
  };

  const handleClaimTicket = (ticketId: string) => {
    setTickets((prev) =>
      prev.map((t) => (t.id === ticketId ? { ...t, status: 'claimed' } : t))
    );
    showToast('تم استلام التذكرة من قبل طاقم الإدارة.');
  };

  const handleCloseTicket = (ticketId: string) => {
    setTickets((prev) =>
      prev.map((t) => (t.id === ticketId ? { ...t, status: 'closed' } : t))
    );
    showToast('تم إغلاق التذكرة بنجاح.');
  };

  // Moderation action
  const handleAddLog = (newLog: ModerationLog) => {
    setLogs((prev) => [newLog, ...prev]);
  };

  return (
    <div className="min-h-screen flex flex-col bg-stone-50 dark:bg-stone-950 text-stone-900 dark:text-stone-100 antialiased transition-colors">
      {/* Top Bar Header */}
      <Header
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        botStatus={botStatus}
        onOpenConnectModal={() => setIsConnectModalOpen(true)}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 w-full">
        {/* Mobile Navigation Tabs */}
        <div className="flex md:hidden items-center gap-1 p-1 bg-stone-200/60 dark:bg-stone-800 rounded-xl mb-6 overflow-x-auto text-xs">
          <button
            onClick={() => setActiveTab('simulator')}
            className={`px-3 py-1.5 font-semibold rounded-lg whitespace-nowrap transition-colors flex-1 text-center ${
              activeTab === 'simulator'
                ? 'bg-white dark:bg-stone-700 text-stone-900 dark:text-white shadow-xs'
                : 'text-stone-600 dark:text-stone-300'
            }`}
          >
            المحاكي
          </button>
          <button
            onClick={() => setActiveTab('invites')}
            className={`px-3 py-1.5 font-semibold rounded-lg whitespace-nowrap transition-colors flex-1 text-center ${
              activeTab === 'invites'
                ? 'bg-white dark:bg-stone-700 text-stone-900 dark:text-white shadow-xs'
                : 'text-stone-600 dark:text-stone-300'
            }`}
          >
            الدعوات (-i)
          </button>
          <button
            onClick={() => setActiveTab('auto-replies')}
            className={`px-3 py-1.5 font-semibold rounded-lg whitespace-nowrap transition-colors flex-1 text-center ${
              activeTab === 'auto-replies'
                ? 'bg-white dark:bg-stone-700 text-stone-900 dark:text-white shadow-xs'
                : 'text-stone-600 dark:text-stone-300'
            }`}
          >
            الردود التلقائية
          </button>
          <button
            onClick={() => setActiveTab('tickets')}
            className={`px-3 py-1.5 font-semibold rounded-lg whitespace-nowrap transition-colors flex-1 text-center ${
              activeTab === 'tickets'
                ? 'bg-white dark:bg-stone-700 text-stone-900 dark:text-white shadow-xs'
                : 'text-stone-600 dark:text-stone-300'
            }`}
          >
            التذاكر
          </button>
          <button
            onClick={() => setActiveTab('moderation')}
            className={`px-3 py-1.5 font-semibold rounded-lg whitespace-nowrap transition-colors flex-1 text-center ${
              activeTab === 'moderation'
                ? 'bg-white dark:bg-stone-700 text-stone-900 dark:text-white shadow-xs'
                : 'text-stone-600 dark:text-stone-300'
            }`}
          >
            الإشراف
          </button>
          <button
            onClick={() => setActiveTab('ai')}
            className={`px-3 py-1.5 font-semibold rounded-lg whitespace-nowrap transition-colors flex-1 text-center ${
              activeTab === 'ai'
                ? 'bg-white dark:bg-stone-700 text-stone-900 dark:text-white shadow-xs'
                : 'text-stone-600 dark:text-stone-300'
            }`}
          >
            الذكاء الاصطناعي
          </button>
          <button
            onClick={() => setActiveTab('commands')}
            className={`px-3 py-1.5 font-semibold rounded-lg whitespace-nowrap transition-colors flex-1 text-center ${
              activeTab === 'commands'
                ? 'bg-white dark:bg-stone-700 text-stone-900 dark:text-white shadow-xs'
                : 'text-stone-600 dark:text-stone-300'
            }`}
          >
            الأوامر
          </button>
        </div>

        {/* Tab Content */}
        {activeTab === 'simulator' && (
          <div className="space-y-4">
            <DiscordSimulator
              onAddTicket={handleAddTicket}
              onAddModerationLog={handleAddLog}
            />
          </div>
        )}

        {activeTab === 'invites' && <InvitesManager />}

        {activeTab === 'auto-replies' && (
          <AutoRespondersManager onShowToast={showToast} />
        )}

        {activeTab === 'tickets' && (
          <TicketsManager
            tickets={tickets}
            onClaimTicket={handleClaimTicket}
            onCloseTicket={handleCloseTicket}
          />
        )}

        {activeTab === 'moderation' && (
          <ModerationManager logs={logs} onAddLog={handleAddLog} />
        )}

        {activeTab === 'ai' && <AiManager />}

        {activeTab === 'commands' && (
          <CommandsReference
            onTryCommand={(cmd) => {
              setActiveTab('simulator');
              showToast(`تم فتح المحاكي لتجربة أمر ${cmd}`);
            }}
          />
        )}

        {activeTab === 'connection' && (
          <BotConnection
            botStatus={botStatus}
            onRefreshStatus={fetchStatus}
            onConnectToken={handleConnectToken}
            onDisconnectBot={handleDisconnectBot}
          />
        )}
      </main>

      {/* Connect Modal */}
      {isConnectModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-6 w-full max-w-md shadow-2xl transition-all text-start">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-bold text-stone-900 dark:text-stone-100 flex items-center gap-2">
                <Key className="w-4 h-4 text-indigo-500" />
                <span>ربط توكين ديسكورد بوت (Discord Bot Token)</span>
              </h3>
              <button
                onClick={() => setIsConnectModalOpen(false)}
                className="p-1 text-stone-400 hover:text-stone-600 dark:hover:text-stone-200 rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {modalError && (
              <div className="mb-4 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-xs text-rose-700 dark:text-rose-400">
                {modalError}
              </div>
            )}

            <form onSubmit={handleModalSubmit} className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-stone-700 dark:text-stone-300 block mb-1.5">
                  ألصق توكين البوت هنا:
                </label>
                <input
                  type="password"
                  autoFocus
                  value={modalToken}
                  onChange={(e) => setModalToken(e.target.value)}
                  placeholder="MTU0ODY0NjE0..."
                  className="w-full px-3.5 py-2.5 text-xs font-mono bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-xl text-stone-900 dark:text-stone-100 placeholder-stone-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
                <span className="text-[11px] text-stone-400 mt-1.5 block">
                  يمكنك الحصول عليه من قسم Bot في Discord Developer Portal.
                </span>
              </div>

              <div className="flex items-center justify-between pt-2">
                <button
                  type="button"
                  onClick={() => setIsConnectModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-white"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={modalLoading || !modalToken.trim()}
                  className="px-5 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 rounded-xl shadow-sm transition-colors"
                >
                  {modalLoading ? 'جارِ التحقق...' : 'اتصال وتشغيل البوت'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 left-6 z-50 bg-stone-900 dark:bg-stone-100 text-white dark:text-stone-900 px-4 py-3 rounded-xl shadow-xl flex items-center gap-2 text-xs font-bold animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 dark:text-emerald-600" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
