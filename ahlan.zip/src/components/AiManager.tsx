import React, { useState } from 'react';
import { Sparkles, Bot, Settings, Send, RefreshCw, CheckCircle, MessageSquare } from 'lucide-react';

interface AiManagerProps {
  // Callback or settings
}

export const AiManager: React.FC<AiManagerProps> = () => {
  const [persona, setPersona] = useState(
    'أنت مساعد ذكاء اصطناعي ذكي ومرح وودود مدمج في بوت ديسكورد. أجب باختصار واحترافية وباللغة العربية مع إيموجيز مناسبة واستخدم تنسيق ديسكورد Markdown.'
  );

  const [aiChannels, setAiChannels] = useState<string>('شات-الذكاء-الاصطناعي, استفسارات, عام');
  const [ticketAutoReply, setTicketAutoReply] = useState<boolean>(true);
  const [mentionReply, setMentionReply] = useState<boolean>(true);

  // Playground test
  const [testPrompt, setTestPrompt] = useState('');
  const [testReply, setTestReply] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [savedToast, setSavedToast] = useState(false);

  const presets = [
    {
      name: '🛠️ خبير الدعم الفني',
      prompt:
        'أنت خبير الدعم الفني لسيرفر ديسكورد. وظيفتك الإجابة عن المشاكل التقنية والبرمجية وتقديم خطوات عملية مرقمة وموجزة.',
    },
    {
      name: '🎉 المساعد المرح والودود',
      prompt:
        'أنت روح السيرفر ومساعد الأعضاء المرح! استخدم إيموجيز لطيفة، أجب بذكاء وروح فكاهية دافئة وتفاعل مع تساؤلات الأعضاء.',
    },
    {
      name: '🛡️ المشرف الإداري الحازم',
      prompt:
        'أنت مساعد إدارة السيرفر. أجب بحيادية ورسمية، وضّح القوانين عند السؤال عنها، ووجه الأعضاء للأقسام والتذاكر الصحيحة.',
    },
  ];

  const handleTestAsk = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!testPrompt.trim()) return;

    setIsLoading(true);
    setTestReply(null);

    try {
      const res = await fetch('/api/ai/ask', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: testPrompt.trim(), persona }),
      });
      const data = await res.json();
      setTestReply(data.text || 'تم استلام الإجابة بنجاح.');
    } catch {
      setTestReply('حدث خطأ أثناء الاتصال بنموذج Gemini 3.8 Flash.');
    }
    setIsLoading(false);
  };

  const handleSaveSettings = () => {
    setSavedToast(true);
    setTimeout(() => setSavedToast(false), 2500);
  };

  return (
    <div className="space-y-8">
      {/* Top Split: Persona Configuration & Playground */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Persona Customizer - 6 cols */}
        <div className="lg:col-span-6 bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl p-6 transition-colors space-y-5">
          <div>
            <h3 className="text-base font-bold text-stone-900 dark:text-stone-100 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-500" />
              <span>شخصية الذكاء الاصطناعي (Bot AI Persona)</span>
            </h3>
            <p className="text-xs text-stone-500 dark:text-stone-400 mt-1">
              التعليمات الأساسية (System Instruction) التي تحكم أسلوب إجابات البوت في أمر <span className="font-mono text-indigo-500">/ask</span> والمنشن.
            </p>
          </div>

          {/* Persona Presets */}
          <div>
            <span className="text-xs font-medium text-stone-700 dark:text-stone-300 block mb-2">
              نماذج شخصيات جاهزة:
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              {presets.map((p, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setPersona(p.prompt)}
                  className="px-2.5 py-1.5 text-xs rounded-lg border border-stone-200 dark:border-stone-800 hover:border-indigo-500 bg-stone-50/50 dark:bg-stone-800/40 text-stone-700 dark:text-stone-300 text-start transition-colors"
                >
                  <span className="font-semibold block">{p.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* System Prompt Textarea */}
          <div>
            <label className="text-xs font-medium text-stone-700 dark:text-stone-300 block mb-1">
              نص التعليمات (System Instruction)
            </label>
            <textarea
              rows={4}
              value={persona}
              onChange={(e) => setPersona(e.target.value)}
              className="w-full px-3.5 py-2.5 text-xs bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-lg text-stone-900 dark:text-stone-100 placeholder-stone-400 focus:outline-none focus:border-indigo-500 leading-relaxed"
            />
          </div>

          {/* AI Settings Toggles */}
          <div className="space-y-3 pt-3 border-t border-stone-100 dark:border-stone-800">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs font-semibold text-stone-900 dark:text-stone-100 block">
                  الرد التلقائي عند المنشن (@Bot)
                </span>
                <span className="text-[11px] text-stone-500 dark:text-stone-400">
                  يرد البوت بالذكاء الاصطناعي مباشرة عند ذكره في أي روم مسموح
                </span>
              </div>
              <input
                type="checkbox"
                checked={mentionReply}
                onChange={(e) => setMentionReply(e.target.checked)}
                className="w-4 h-4 accent-indigo-600 rounded"
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs font-semibold text-stone-900 dark:text-stone-100 block">
                  مساعد التذاكر الذكي (Ticket AI Auto-Triage)
                </span>
                <span className="text-[11px] text-stone-500 dark:text-stone-400">
                  اقتراح حلول تلقائية سريعة فور فتح أي تذكرة جديدة قبل وصول الطاقم
                </span>
              </div>
              <input
                type="checkbox"
                checked={ticketAutoReply}
                onChange={(e) => setTicketAutoReply(e.target.checked)}
                className="w-4 h-4 accent-indigo-600 rounded"
              />
            </div>
          </div>

          <button
            onClick={handleSaveSettings}
            className="w-full py-2.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 rounded-lg transition-colors flex items-center justify-center gap-1.5"
          >
            {savedToast ? (
              <>
                <CheckCircle className="w-4 h-4 text-emerald-400" />
                <span>تم حفظ إعدادات الذكاء الاصطناعي!</span>
              </>
            ) : (
              <span>حفظ وتطبيق الإعدادات</span>
            )}
          </button>
        </div>

        {/* AI Playground / Test Sandbox - 6 cols */}
        <div className="lg:col-span-6 bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl p-6 transition-colors space-y-5">
          <div>
            <h3 className="text-base font-bold text-stone-900 dark:text-stone-100 flex items-center gap-2">
              <Bot className="w-4 h-4 text-indigo-500" />
              <span>مختبر تجربة الذكاء الاصطناعي المباشر (Playground)</span>
            </h3>
            <p className="text-xs text-stone-500 dark:text-stone-400 mt-1">
              اختبر ردود وسرعة نموذج <span className="font-mono text-indigo-500">Gemini 3.8 Flash</span> بنفس الشخصية قبل استخدامه في الديسكورد.
            </p>
          </div>

          <form onSubmit={handleTestAsk} className="space-y-3">
            <div>
              <label className="text-xs font-medium text-stone-700 dark:text-stone-300 block mb-1">
                سؤال تجريبي
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={testPrompt}
                  onChange={(e) => setTestPrompt(e.target.value)}
                  placeholder="مثال: كيف أمنع السبام في السيرفر؟ أو اشرح أمر /warn"
                  className="w-full px-3.5 py-2 text-xs bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-lg text-stone-900 dark:text-stone-100 placeholder-stone-400 focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading || !testPrompt.trim()}
              className="px-4 py-2 text-xs font-semibold text-white bg-stone-900 hover:bg-stone-800 dark:bg-indigo-600 dark:hover:bg-indigo-700 disabled:opacity-50 rounded-lg transition-colors flex items-center gap-1.5"
            >
              {isLoading ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>جاري توليد الإجابة...</span>
                </>
              ) : (
                <>
                  <Send className="w-3.5 h-3.5" />
                  <span>إرسال وتجربة الرد</span>
                </>
              )}
            </button>
          </form>

          {/* AI Response Output Box (Discord Style) */}
          <div className="pt-2">
            <span className="text-xs font-medium text-stone-500 dark:text-stone-400 block mb-1.5">
              معاينة الرد كما يظهر داخل الديسكورد:
            </span>

            {testReply ? (
              <div className="rounded-lg bg-[#2b2d31] border-s-4 border-[#FEE75C] p-4 text-xs text-[#dbdee1] space-y-2 leading-relaxed">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-white text-sm">DiscordBot Pro</span>
                  <span className="bg-[#5865F2] text-white text-[10px] font-bold px-1.5 py-0.2 rounded">
                    BOT
                  </span>
                </div>
                <div className="whitespace-pre-wrap">{testReply}</div>
              </div>
            ) : (
              <div className="p-8 text-center text-xs text-stone-400 border border-dashed border-stone-200 dark:border-stone-800 rounded-lg">
                اكتب سؤالاً واضغط &quot;إرسال&quot; لرؤية إجابة الذكاء الاصطناعي هنا فوراً.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
