import React, { useState, useEffect } from 'react';
import { AutoResponder } from '../types';
import { MessageSquare, Plus, Trash2, CheckCircle2, ToggleLeft, ToggleRight, Sparkles, Send } from 'lucide-react';

interface AutoRespondersManagerProps {
  onShowToast?: (msg: string) => void;
}

const DEFAULT_RESPONDERS: AutoResponder[] = [
  {
    id: 'ar-1',
    trigger: 'سلام',
    reply: 'وعليكم السلام ورحمة الله وبركاته! نورت السيرفر يا غالي 🌟',
    matchType: 'contains',
    enabled: true,
  },
  {
    id: 'ar-2',
    trigger: 'السلام عليكم',
    reply: 'وعليكم السلام ورحمة الله وبركاته! أهلاً وسهلاً بك في مجتمعنا 🤍',
    matchType: 'exact',
    enabled: true,
  },
  {
    id: 'ar-3',
    trigger: 'قوانين',
    reply: '📜 يرجى مراجعة روم القوانين الرسمية لتفادي أي مخالفة أو حظر. نتمنى لك وقتاً ممتعاً!',
    matchType: 'contains',
    enabled: true,
  },
  {
    id: 'ar-4',
    trigger: 'ip',
    reply: '⛏️ سيرفر Hitrex SMP ماين كرافت:\nالآي بي: `hitrexsmp.halix.gg`\nالمنفذ: `25565` (جافا) / `19132` (بيدروك الجوال)',
    matchType: 'exact',
    enabled: true,
  },
  {
    id: 'ar-5',
    trigger: 'تكت',
    reply: '🎫 إذا كنت بحاجة لدعم فني أو شراء، تفضل بزيارة روم التذاكر واضغط على زر القسم المناسب!',
    matchType: 'contains',
    enabled: true,
  },
];

export const AutoRespondersManager: React.FC<AutoRespondersManagerProps> = ({ onShowToast }) => {
  const [responders, setResponders] = useState<AutoResponder[]>(DEFAULT_RESPONDERS);
  const [trigger, setTrigger] = useState('');
  const [reply, setReply] = useState('');
  const [matchType, setMatchType] = useState<'exact' | 'contains' | 'startsWith'>('contains');
  const [testInput, setTestInput] = useState('');
  const [testResult, setTestResult] = useState<string | null>(null);

  // Load from backend if available
  useEffect(() => {
    fetch('/api/auto-responders')
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data) && data.length > 0) {
          setResponders(data);
        }
      })
      .catch(() => {});
  }, []);

  const saveToBackend = async (list: AutoResponder[]) => {
    try {
      await fetch('/api/auto-responders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(list),
      });
    } catch {}
  };

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!trigger.trim() || !reply.trim()) return;

    const newRes: AutoResponder = {
      id: `ar-${Date.now()}`,
      trigger: trigger.trim().toLowerCase(),
      reply: reply.trim(),
      matchType,
      enabled: true,
    };

    const updated = [newRes, ...responders];
    setResponders(updated);
    saveToBackend(updated);
    setTrigger('');
    setReply('');
    if (onShowToast) onShowToast('✅ تم إضافة الرد التلقائي بنجاح!');
  };

  const handleDelete = (id: string) => {
    const updated = responders.filter((r) => r.id !== id);
    setResponders(updated);
    saveToBackend(updated);
    if (onShowToast) onShowToast('🗑️ تم حذف الرد التلقائي');
  };

  const handleToggle = (id: string) => {
    const updated = responders.map((r) => (r.id === id ? { ...r, enabled: !r.enabled } : r));
    setResponders(updated);
    saveToBackend(updated);
  };

  const handleTest = (e: React.FormEvent) => {
    e.preventDefault();
    const query = testInput.trim().toLowerCase();
    if (!query) {
      setTestResult(null);
      return;
    }

    const matched = responders.find((r) => {
      if (!r.enabled) return false;
      const t = r.trigger.toLowerCase();
      if (r.matchType === 'exact') return query === t;
      if (r.matchType === 'contains') return query.includes(t);
      if (r.matchType === 'startsWith') return query.startsWith(t);
      return false;
    });

    if (matched) {
      setTestResult(`🤖 مطابقة مع [${matched.trigger}]:\n${matched.reply}`);
    } else {
      setTestResult('❌ لم يتم العثور على أي رد تلقائي يطابق هذه العبارة.');
    }
  };

  return (
    <div className="space-y-8 animate-fadeIn text-start">
      {/* Overview Banner */}
      <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-6 shadow-sm">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center shrink-0">
              <MessageSquare className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-stone-900 dark:text-white">نظام الردود التلقائية (Auto-Responders)</h2>
              <p className="text-sm text-stone-500 dark:text-stone-400 mt-1">
                قم ببرمجة البوت ليرد فورياً عند كتابة الأعضاء لكلمات أو عبارات محددة في أي روم بديسكورد
              </p>
            </div>
          </div>
          <div className="px-3 py-1.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400 text-xs font-semibold flex items-center gap-2 border border-emerald-200 dark:border-emerald-800">
            <CheckCircle2 className="w-4 h-4" />
            <span>{responders.filter((r) => r.enabled).length} رد نشط ومفعل</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Form: Add New Auto-Responder */}
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-6 shadow-sm">
            <h3 className="text-base font-bold text-stone-900 dark:text-white mb-4 flex items-center gap-2">
              <Plus className="w-4 h-4 text-indigo-600" />
              إضافة رد تلقائي جديد
            </h3>

            <form onSubmit={handleAdd} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1.5">
                  الكلمة أو العبارة المشغلة (Trigger)
                </label>
                <input
                  type="text"
                  value={trigger}
                  onChange={(e) => setTrigger(e.target.value)}
                  placeholder="مثال: متى السيرفر يفتح، متجر، رتبة..."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 dark:border-stone-700 bg-stone-50 dark:bg-stone-800/60 text-stone-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-shadow"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1.5">
                  نوع التطابق (Match Type)
                </label>
                <select
                  value={matchType}
                  onChange={(e: any) => setMatchType(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 dark:border-stone-700 bg-stone-50 dark:bg-stone-800/60 text-stone-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="contains">تحتوي على الكلمة (Contains)</option>
                  <option value="exact">تطابق تام للرسالة (Exact Match)</option>
                  <option value="startsWith">تبدأ بالكلمة (Starts With)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1.5">
                  رد البوت (Bot Response)
                </label>
                <textarea
                  value={reply}
                  onChange={(e) => setReply(e.target.value)}
                  placeholder="اكتب رد البوت الذي سيتم إرساله للأعضاء مع إمكانية استخدام الإيموجيز وروابط السيرفر..."
                  rows={4}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 dark:border-stone-700 bg-stone-50 dark:bg-stone-800/60 text-stone-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-shadow resize-none"
                  required
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-medium text-sm transition-colors shadow-sm flex items-center justify-center gap-2"
              >
                <Plus className="w-4 h-4" />
                حفظ وتفعيل الرد التلقائي
              </button>
            </form>
          </div>

          {/* Test Playground */}
          <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-6 shadow-sm">
            <h3 className="text-base font-bold text-stone-900 dark:text-white mb-2 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-500" />
              اختبار الردود التلقائية
            </h3>
            <p className="text-xs text-stone-500 dark:text-stone-400 mb-4">
              اكتب أي رسالة هنا لتجربة ما إذا كان البوت سيرد عليها وفق قواعدك:
            </p>

            <form onSubmit={handleTest} className="space-y-3">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={testInput}
                  onChange={(e) => setTestInput(e.target.value)}
                  placeholder="اكتب رسالة تجريبية، مثلاً: سلام عليكم"
                  className="flex-1 px-3 py-2 rounded-xl border border-stone-300 dark:border-stone-700 bg-stone-50 dark:bg-stone-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
                <button
                  type="submit"
                  className="px-3.5 py-2 rounded-xl bg-stone-800 text-white dark:bg-stone-700 hover:bg-stone-900 text-sm font-medium transition-colors"
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>

              {testResult && (
                <div className="p-3.5 rounded-xl bg-stone-100 dark:bg-stone-800/70 border border-stone-200 dark:border-stone-700 text-xs font-mono whitespace-pre-line text-stone-800 dark:text-stone-200">
                  {testResult}
                </div>
              )}
            </form>
          </div>
        </div>

        {/* List of Responders */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-stone-900 dark:text-white">
              قائمة الردود المسجلة ({responders.length})
            </h3>
          </div>

          <div className="space-y-3">
            {responders.map((item) => (
              <div
                key={item.id}
                className={`p-4 rounded-2xl border transition-all ${
                  item.enabled
                    ? 'bg-white dark:bg-stone-900 border-stone-200 dark:border-stone-800 shadow-sm'
                    : 'bg-stone-50/60 dark:bg-stone-900/40 border-stone-200 dark:border-stone-800 opacity-60'
                }`}
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="space-y-2 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="px-2.5 py-1 rounded-md bg-indigo-100 dark:bg-indigo-950/80 text-indigo-700 dark:text-indigo-300 font-mono text-xs font-bold">
                        {item.trigger}
                      </span>
                      <span className="text-[11px] px-2 py-0.5 rounded bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-400">
                        {item.matchType === 'exact'
                          ? 'تطابق تام'
                          : item.matchType === 'contains'
                          ? 'تحتوي الكلمة'
                          : 'تبدأ بالكلمة'}
                      </span>
                      {item.trigger.toLowerCase() === 'ip' && (
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-100 dark:bg-emerald-950 text-emerald-600 font-semibold">
                          Minecraft Hitrex SMP
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-stone-800 dark:text-stone-200 whitespace-pre-line font-sans leading-relaxed">
                      {item.reply}
                    </p>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => handleToggle(item.id)}
                      className="text-stone-400 hover:text-stone-600 dark:hover:text-stone-200 transition-colors p-1"
                      title={item.enabled ? 'تعطيل' : 'تفعيل'}
                    >
                      {item.enabled ? (
                        <ToggleRight className="w-6 h-6 text-emerald-500" />
                      ) : (
                        <ToggleLeft className="w-6 h-6 text-stone-400" />
                      )}
                    </button>
                    <button
                      onClick={() => handleDelete(item.id)}
                      className="p-1.5 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors"
                      title="حذف"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
