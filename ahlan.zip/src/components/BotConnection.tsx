import React, { useState } from 'react';
import { BotStatusResponse } from '../types';
import {
  Key,
  ExternalLink,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Copy,
  Check,
  RefreshCw,
  PowerOff,
  Radio,
  BookOpen,
  Sliders,
} from 'lucide-react';

interface BotConnectionProps {
  botStatus: BotStatusResponse;
  onRefreshStatus: () => void;
  onConnectToken: (token: string) => Promise<{ success: boolean; error?: string }>;
  onDisconnectBot: () => Promise<void>;
}

export const BotConnection: React.FC<BotConnectionProps> = ({
  botStatus,
  onRefreshStatus,
  onConnectToken,
  onDisconnectBot,
}) => {
  const [token, setToken] = useState('MTU0ODY0NjE0NDk0MTQ5NDM3Mg.GLGV5z.aJrDmWfpETXQUSTyY3e1aQ8PmxNcSCIIhSLrhA');
  const [showToken, setShowToken] = useState(false);
  const [clientId, setClientId] = useState('1548646144941494372');
  const [isConnecting, setIsConnecting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [copiedInvite, setCopiedInvite] = useState(false);

  // Auto-extract Client ID when token is entered
  const handleTokenChange = (val: string) => {
    setToken(val);
    try {
      const part = val.split('.')[0];
      if (part) {
        const decoded = atob(part);
        if (/^\d+$/.test(decoded)) {
          setClientId(decoded);
        }
      }
    } catch {}
  };

  // Permission bitflags
  const [perms, setPerms] = useState({
    administrator: true,
    manageChannels: true,
    manageRoles: true,
    sendMessages: true,
    embedLinks: true,
    manageMessages: true,
  });

  const isOnline = botStatus.status === 'online';

  const handleConnect = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token.trim()) {
      setErrorMsg('يرجى لصق توكين البوت (Bot Token) أولاً.');
      return;
    }

    setIsConnecting(true);
    setErrorMsg(null);
    setSuccessMsg(null);

    const res = await onConnectToken(token.trim());
    setIsConnecting(false);

    if (res.success) {
      setSuccessMsg('تم الاتصال ببوت ديسكورد بنجاح وتسجيل الأوامر!');
      setToken('');
    } else {
      setErrorMsg(res.error || 'فشل الاتصال، تحقق من صحة التوكين');
    }
  };

  const handleDisconnect = async () => {
    await onDisconnectBot();
    setSuccessMsg('تم فصل البوت بنجاح.');
    setErrorMsg(null);
  };

  // Generate Invite URL
  // Default administrator = 8
  const permissionInteger = perms.administrator ? '8' : '534723950672';
  const inviteUrl = clientId.trim()
    ? `https://discord.com/api/oauth2/authorize?client_id=${clientId.trim()}&permissions=${permissionInteger}&scope=bot%20applications.commands`
    : `https://discord.com/api/oauth2/authorize?client_id=YOUR_CLIENT_ID&permissions=${permissionInteger}&scope=bot%20applications.commands`;

  const copyInviteUrl = () => {
    if (!clientId.trim()) {
      setErrorMsg('يرجى إدخال Client ID أولاً لإنشاء رابط الدعوة المباشر.');
      return;
    }
    navigator.clipboard.writeText(inviteUrl);
    setCopiedInvite(true);
    setTimeout(() => setCopiedInvite(false), 2000);
  };

  return (
    <div className="space-y-8">
      {/* Top Banner Status */}
      <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl p-6 transition-colors">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span
                className={`w-3 h-3 rounded-full ${
                  isOnline
                    ? 'bg-emerald-500 animate-pulse'
                    : botStatus.status === 'connecting'
                    ? 'bg-amber-500 animate-spin'
                    : 'bg-stone-400'
                }`}
              />
              <h2 className="text-lg font-bold text-stone-900 dark:text-stone-100">
                حالة البوت والاتصال (Gateway Status)
              </h2>
            </div>
            <p className="text-xs text-stone-500 dark:text-stone-400">
              {isOnline
                ? `متصل بالبوابة كـ ${botStatus.tag} في ${botStatus.guildsCount} سيرفر`
                : 'يمكنك استخدام المحاكي التفاعلي المباشر الآن، أو ربط توكين ديسكورد لتشغيل البوت في سيرفرك الحقيقي.'}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onRefreshStatus}
              className="p-2 text-stone-600 dark:text-stone-300 hover:text-stone-900 dark:hover:text-white hover:bg-stone-100 dark:hover:bg-stone-800 rounded-lg transition-colors text-xs flex items-center gap-1.5"
              title="تحديث الحالة"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>تحديث</span>
            </button>

            {isOnline && (
              <button
                onClick={handleDisconnect}
                className="px-3.5 py-1.5 text-xs font-semibold text-rose-600 hover:text-white hover:bg-rose-600 border border-rose-200 dark:border-rose-900/50 rounded-lg transition-colors flex items-center gap-1.5"
              >
                <PowerOff className="w-3.5 h-3.5" />
                <span>فصل البوت</span>
              </button>
            )}
          </div>
        </div>

        {/* Status Metrics Strip - Tabular numerals */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6 pt-5 border-t border-stone-100 dark:border-stone-800">
          <div>
            <span className="text-xs text-stone-400 block mb-1">حالة البوابة</span>
            <span
              className={`text-sm font-bold font-mono ${
                isOnline ? 'text-emerald-600 dark:text-emerald-400' : 'text-stone-500'
              }`}
            >
              {isOnline ? 'ONLINE' : 'SIMULATOR ACTIVE'}
            </span>
          </div>

          <div>
            <span className="text-xs text-stone-400 block mb-1">سرعة الاستجابة (Ping)</span>
            <span className="text-sm font-bold font-mono tabular-nums text-stone-900 dark:text-stone-100">
              {isOnline ? `${botStatus.ping}ms` : '~15ms (Local)'}
            </span>
          </div>

          <div>
            <span className="text-xs text-stone-400 block mb-1">السيرفرات المرتبطة</span>
            <span className="text-sm font-bold font-mono tabular-nums text-stone-900 dark:text-stone-100">
              {isOnline ? botStatus.guildsCount : '1 (محاكي)'}
            </span>
          </div>

          <div>
            <span className="text-xs text-stone-400 block mb-1">محرك الذكاء الاصطناعي</span>
            <span className="text-sm font-bold font-mono text-indigo-600 dark:text-indigo-400">
              Gemini 3.8 Flash
            </span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Token Input Form - 7 Cols */}
        <div className="lg:col-span-7 bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl p-6 transition-colors space-y-6">
          <div>
            <h3 className="text-base font-bold text-stone-900 dark:text-stone-100 flex items-center gap-2">
              <Key className="w-4 h-4 text-indigo-500" />
              <span>إدخال توكين البوت (Discord Bot Token)</span>
            </h3>
            <p className="text-xs text-stone-500 dark:text-stone-400 mt-1">
              ألصق توكين البوت لتشغيل البوت فورياً وتسجيل أوامر السلاش (Slash Commands) تلقائياً في حساب البوت.
            </p>
          </div>

          {errorMsg && (
            <div className="p-3.5 rounded-lg bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-xs text-rose-700 dark:text-rose-400 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          {successMsg && (
            <div className="p-3.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900 text-xs text-emerald-700 dark:text-emerald-400 flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{successMsg}</span>
            </div>
          )}

          <form onSubmit={handleConnect} className="space-y-4">
            <div>
              <label className="text-xs font-medium text-stone-700 dark:text-stone-300 block mb-1.5">
                توكين البوت (Bot Token)
              </label>
              <div className="relative">
                <input
                  type={showToken ? 'text' : 'password'}
                  value={token}
                  onChange={(e) => handleTokenChange(e.target.value)}
                  placeholder="MTE1N..."
                  className="w-full px-3.5 py-2.5 text-xs font-mono bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-lg text-stone-900 dark:text-stone-100 placeholder-stone-400 focus:outline-none focus:border-indigo-500"
                />
                <button
                  type="button"
                  onClick={() => setShowToken(!showToken)}
                  className="absolute end-2.5 top-1/2 -translate-y-1/2 text-xs text-stone-400 hover:text-stone-600 dark:hover:text-stone-200 px-1 py-0.5"
                >
                  {showToken ? 'إخفاء' : 'إظهار'}
                </button>
              </div>
              <span className="text-[11px] text-stone-400 mt-1 block">
                * التوكين يبقى آمناً على السيرفر لتشغيل عميل ديسكورد ولا يتم مشاركته خارج التطبيق.
              </span>
            </div>

            <button
              type="submit"
              disabled={isConnecting}
              className="w-full py-2.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 disabled:opacity-50 rounded-lg shadow-sm transition-colors flex items-center justify-center gap-2"
            >
              {isConnecting ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>جاري تسجيل الدخول إلى ديسكورد...</span>
                </>
              ) : (
                <>
                  <Key className="w-3.5 h-3.5" />
                  <span>تأكيد والاتصال بالبوابة (Connect Bot)</span>
                </>
              )}
            </button>
          </form>

          {/* Invite URL Generator */}
          <div className="pt-6 border-t border-stone-200 dark:border-stone-800 space-y-4">
            <h4 className="text-xs font-bold text-stone-900 dark:text-stone-100 flex items-center gap-1.5">
              <ExternalLink className="w-3.5 h-3.5 text-indigo-500" />
              <span>إنشاء رابط دعوة البوت لسيرفرك (Bot Invite Link)</span>
            </h4>

            <div>
              <label className="text-xs font-medium text-stone-700 dark:text-stone-300 block mb-1">
                معرف البوت (Client ID / Application ID)
              </label>
              <input
                type="text"
                value={clientId}
                onChange={(e) => setClientId(e.target.value)}
                placeholder="مثال: 123456789012345678"
                className="w-full px-3.5 py-2 text-xs font-mono bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-lg text-stone-900 dark:text-stone-100 placeholder-stone-400 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="flex items-center gap-2">
              <input
                type="text"
                readOnly
                value={inviteUrl}
                className="flex-1 px-3 py-2 text-xs font-mono bg-stone-100 dark:bg-stone-800/60 border border-stone-200 dark:border-stone-700 rounded-lg text-stone-600 dark:text-stone-300 truncate"
              />
              <button
                onClick={copyInviteUrl}
                className="px-3 py-2 text-xs font-semibold bg-stone-900 hover:bg-stone-800 dark:bg-stone-700 dark:hover:bg-stone-600 text-white rounded-lg transition-colors flex items-center gap-1.5 shrink-0"
              >
                {copiedInvite ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span>تم النسخ!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>نسخ الرابط</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Step-by-Step Tutorial - 5 Cols */}
        <div className="lg:col-span-5 bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl p-6 transition-colors space-y-5">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-stone-900 dark:text-stone-100 flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-indigo-500" />
              <span>خطوات استخراج التوكين (دقيقة واحدة)</span>
            </h3>
            <a
              href="https://discord.com/developers/applications"
              target="_blank"
              rel="noreferrer"
              className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1 font-medium"
            >
              <span>موقع المطورين</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>

          <ol className="space-y-4 text-xs text-stone-600 dark:text-stone-300 leading-relaxed list-decimal list-inside">
            <li className="ps-1">
              <strong className="text-stone-900 dark:text-stone-100">إنشاء تطبيق جديد:</strong>
              <p className="mt-1 ps-4 text-stone-500 dark:text-stone-400">
                افتح <span className="font-mono text-indigo-500">Discord Developer Portal</span> واضغط على <strong>New Application</strong> وسمّه بالاسم الذي تريده.
              </p>
            </li>

            <li className="ps-1">
              <strong className="text-stone-900 dark:text-stone-100">الحصول على التوكين:</strong>
              <p className="mt-1 ps-4 text-stone-500 dark:text-stone-400">
                ادخل لقسم <strong>Bot</strong> من القائمة الجانبية، ثم اضغط <strong>Reset Token</strong> ثم <strong>Copy</strong> والصقه هنا في الحقل.
              </p>
            </li>

            <li className="ps-1">
              <strong className="text-stone-900 dark:text-stone-100">تفعيل خيارات الصلاحيات (مهم جداً):</strong>
              <p className="mt-1 ps-4 text-stone-500 dark:text-stone-400">
                في نفس صفحة <strong>Bot</strong>، انزل لأسفل وفعّل خيارات <strong>Privileged Gateway Intents</strong> الثلاثة:
                <br />
                - <span className="font-mono">Message Content Intent</span> (لقراءة الرسائل والذكاء الاصطناعي).
                <br />
                - <span className="font-mono">Server Members Intent</span> (لإدارة الأعضاء والتذاكر).
              </p>
            </li>

            <li className="ps-1">
              <strong className="text-stone-900 dark:text-stone-100">إضافة البوت لسيرفرك:</strong>
              <p className="mt-1 ps-4 text-stone-500 dark:text-stone-400">
                انسخ <strong>Application ID</strong> من قسم General Information والصقه في خانة Client ID ثم افتح رابط الدعوة وأضفه لسيرفرك!
              </p>
            </li>
          </ol>

          <div className="p-3.5 rounded-lg bg-indigo-50/60 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900/40 text-xs text-indigo-900 dark:text-indigo-300">
            💡 <strong>ملاحظة:</strong> إذا لم يتوفر لديك التوكين الآن، لا تقلق! يمكنك تجربة كافة الأوامر والتذاكر والذكاء الاصطناعي من تبويب <strong>المحاكي المباشر</strong> فوراً.
          </div>
        </div>
      </div>
    </div>
  );
};
