import React, { useState, useEffect } from 'react';
import { BOT_COMMANDS } from '../data/commandsList';
import { BotCommand } from '../types';
import {
  Terminal,
  Code,
  Copy,
  Check,
  Download,
  Play,
  Crown,
  Users,
} from 'lucide-react';

interface CommandsReferenceProps {
  onTryCommand: (cmdSyntax: string) => void;
}

export const CommandsReference: React.FC<CommandsReferenceProps> = ({ onTryCommand }) => {
  const [filter, setFilter] = useState<string>('all');
  const [sourceCodeFiles, setSourceCodeFiles] = useState<Record<string, string>>({});
  const [activeFile, setActiveFile] = useState<string>('index.js');
  const [copiedFile, setCopiedFile] = useState<string | null>(null);

  useEffect(() => {
    fetch('/api/bot/source-code')
      .then((res) => res.json())
      .then((data) => setSourceCodeFiles(data))
      .catch((err) => console.error('Failed to load bot source code:', err));
  }, []);

  const filteredCommands = BOT_COMMANDS.filter((cmd) => {
    if (filter === 'all') return true;
    if (filter === 'admin') return cmd.isAdminOnly;
    if (filter === 'players') return !cmd.isAdminOnly;
    return cmd.category === filter;
  });

  const handleCopyCode = (filename: string) => {
    const content = sourceCodeFiles[filename] || '';
    navigator.clipboard.writeText(content);
    setCopiedFile(filename);
    setTimeout(() => setCopiedFile(null), 2000);
  };

  const handleDownloadFile = (filename: string) => {
    const content = sourceCodeFiles[filename] || '';
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-8 text-start">
      {/* Top Section: Complete Commands Reference */}
      <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-6 transition-colors space-y-6 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-bold text-stone-900 dark:text-stone-100 flex items-center gap-2">
              <Terminal className="w-5 h-5 text-indigo-500" />
              <span>دليل أوامر البوت ونظام الصلاحيات الشامل</span>
            </h3>
            <p className="text-xs text-stone-500 dark:text-stone-400 mt-1">
              قائمة تفصيلية بجميع أوامر السلاش والأوامر النصية مع نظام الحماية الصارم للأوامر الإدارية.
            </p>
          </div>

          {/* Category Filter Tabs */}
          <div className="flex items-center gap-1 p-1 bg-stone-100 dark:bg-stone-800 rounded-xl overflow-x-auto text-xs">
            <button
              onClick={() => setFilter('all')}
              className={`px-3 py-1.5 font-semibold rounded-lg transition-colors whitespace-nowrap ${
                filter === 'all'
                  ? 'bg-white dark:bg-stone-700 text-stone-900 dark:text-white shadow-xs'
                  : 'text-stone-600 dark:text-stone-300'
              }`}
            >
              الكل ({BOT_COMMANDS.length})
            </button>
            <button
              onClick={() => setFilter('admin')}
              className={`px-3 py-1.5 font-semibold rounded-lg transition-colors whitespace-nowrap flex items-center gap-1 ${
                filter === 'admin'
                  ? 'bg-amber-500 text-white shadow-xs'
                  : 'text-amber-600 dark:text-amber-400'
              }`}
            >
              <Crown className="w-3.5 h-3.5" />
              <span>للإدارة فقط</span>
            </button>
            <button
              onClick={() => setFilter('players')}
              className={`px-3 py-1.5 font-semibold rounded-lg transition-colors whitespace-nowrap flex items-center gap-1 ${
                filter === 'players'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-stone-600 dark:text-stone-300'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>لجميع اللاعبين</span>
            </button>
            <button
              onClick={() => setFilter('invites')}
              className={`px-3 py-1.5 font-semibold rounded-lg transition-colors whitespace-nowrap ${
                filter === 'invites'
                  ? 'bg-white dark:bg-stone-700 text-stone-900 dark:text-white shadow-xs'
                  : 'text-stone-600 dark:text-stone-300'
              }`}
            >
              الدعوات (-i)
            </button>
            <button
              onClick={() => setFilter('tickets')}
              className={`px-3 py-1.5 font-semibold rounded-lg transition-colors whitespace-nowrap ${
                filter === 'tickets'
                  ? 'bg-white dark:bg-stone-700 text-stone-900 dark:text-white shadow-xs'
                  : 'text-stone-600 dark:text-stone-300'
              }`}
            >
              التذاكر
            </button>
            <button
              onClick={() => setFilter('ai')}
              className={`px-3 py-1.5 font-semibold rounded-lg transition-colors whitespace-nowrap ${
                filter === 'ai'
                  ? 'bg-white dark:bg-stone-700 text-stone-900 dark:text-white shadow-xs'
                  : 'text-stone-600 dark:text-stone-300'
              }`}
            >
              الذكاء الاصطناعي
            </button>
          </div>
        </div>

        {/* Commands Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredCommands.map((cmd) => (
            <div
              key={cmd.name}
              className="p-4 rounded-2xl border border-stone-200 dark:border-stone-800 bg-stone-50/50 dark:bg-stone-800/40 hover:border-indigo-500/50 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="font-mono font-bold text-sm text-indigo-600 dark:text-indigo-400">
                    {cmd.syntax}
                  </span>
                  {cmd.isAdminOnly ? (
                    <span className="text-[11px] px-2 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950/80 text-amber-700 dark:text-amber-300 font-semibold flex items-center gap-1">
                      <Crown className="w-3 h-3" />
                      <span>👑 للإدارة فقط</span>
                    </span>
                  ) : (
                    <span className="text-[11px] px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 font-semibold flex items-center gap-1">
                      <Users className="w-3 h-3" />
                      <span>🧑 متاح للجميع</span>
                    </span>
                  )}
                </div>

                <p className="text-xs text-stone-600 dark:text-stone-300 leading-relaxed mb-3">
                  {cmd.descriptionAr}
                </p>

                <div className="p-2.5 rounded-xl bg-stone-100 dark:bg-stone-900/60 font-mono text-[11px] text-stone-700 dark:text-stone-300 break-all mb-3 border border-stone-200 dark:border-stone-800">
                  <span className="text-stone-400 select-none">مثال الاستخدام: </span>
                  <span className="text-indigo-600 dark:text-indigo-400 font-bold">{cmd.example}</span>
                </div>
              </div>

              <div className="pt-2.5 border-t border-stone-200/60 dark:border-stone-700/60 flex items-center justify-between">
                <span className="text-[11px] text-stone-500 dark:text-stone-400 font-mono">
                  {cmd.permissionsAr}
                </span>

                <button
                  onClick={() => onTryCommand(cmd.example)}
                  className="px-2.5 py-1 text-xs font-semibold bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/40 dark:hover:bg-indigo-900 text-indigo-700 dark:text-indigo-300 rounded-lg transition-colors flex items-center gap-1"
                >
                  <Play className="w-3 h-3 fill-current" />
                  <span>تجربة في المحاكي</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom Section: Standalone Bot Source Code Exporter */}
      <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-6 transition-colors space-y-5 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-bold text-stone-900 dark:text-stone-100 flex items-center gap-2">
              <Code className="w-5 h-5 text-indigo-500" />
              <span>تصدير كود البوت الكامل للاستضافة الذاتية (Self-Hosting Ready)</span>
            </h3>
            <p className="text-xs text-stone-500 dark:text-stone-400 mt-1">
              البوت يعمل مباشرة من هذا السيرفر، ويمكنك أيضاً تصدير ملفات البوت لتشغيلها على أي استضافة خارجية أو VPS.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => handleCopyCode(activeFile)}
              className="px-3.5 py-2 rounded-xl bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 text-stone-700 dark:text-stone-300 text-xs font-semibold flex items-center gap-1.5 transition-colors"
            >
              {copiedFile === activeFile ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-500" />
                  <span>تم النسخ!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>نسخ الكود</span>
                </>
              )}
            </button>
            <button
              onClick={() => handleDownloadFile(activeFile)}
              className="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-sm"
            >
              <Download className="w-3.5 h-3.5" />
              <span>تحميل الملف</span>
            </button>
          </div>
        </div>

        {/* File Tabs */}
        <div className="flex items-center gap-2 border-b border-stone-200 dark:border-stone-800 pb-2">
          {['index.js', 'package.json', '.env.example'].map((fname) => (
            <button
              key={fname}
              onClick={() => setActiveFile(fname)}
              className={`px-3 py-1.5 text-xs font-mono rounded-lg transition-colors ${
                activeFile === fname
                  ? 'bg-stone-800 text-white dark:bg-stone-700 font-bold'
                  : 'text-stone-500 hover:text-stone-900 dark:hover:text-white'
              }`}
            >
              {fname}
            </button>
          ))}
        </div>

        {/* Code Viewport */}
        <div className="relative rounded-xl bg-stone-950 p-4 overflow-x-auto text-xs font-mono text-emerald-400 max-h-96 text-left dir-ltr">
          <pre>{sourceCodeFiles[activeFile] || '// جارِ تحميل ملفات المصدر...'}</pre>
        </div>
      </div>
    </div>
  );
};
