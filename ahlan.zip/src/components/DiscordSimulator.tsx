import React, { useState, useRef, useEffect } from 'react';
import { SimulatedMessage, SimulatedTicket, ModerationLog } from '../types';
import {
  Hash,
  Send,
  Sparkles,
  Shield,
  Copy,
  Check,
  Award,
  Crown,
  User as UserIcon,
  Server,
  Zap,
} from 'lucide-react';

interface DiscordSimulatorProps {
  onAddTicket: (ticket: SimulatedTicket) => void;
  onAddModerationLog: (log: ModerationLog) => void;
}

export const DiscordSimulator: React.FC<DiscordSimulatorProps> = ({
  onAddTicket,
  onAddModerationLog,
}) => {
  // Current active channel
  const [activeChannel, setActiveChannel] = useState<string>('general');
  const [inputVal, setInputVal] = useState<string>('');
  const [isAiLoading, setIsAiLoading] = useState<boolean>(false);
  const [ticketCounter, setTicketCounter] = useState<number>(1);
  const [dynamicChannels, setDynamicChannels] = useState<{ id: string; name: string }[]>([]);
  
  // User Role Switcher in Simulator (Admin vs Regular Player)
  const [simulatedRole, setSimulatedRole] = useState<'admin' | 'member'>('admin');
  
  // Dedicated AI Channels Set
  const [aiChannels, setAiChannels] = useState<Set<string>>(new Set(['ai-chat']));
  
  // Copied IP state
  const [copiedIp, setCopiedIp] = useState(false);

  // Messages per channel
  const [channelMessages, setChannelMessages] = useState<Record<string, SimulatedMessage[]>>({
    general: [
      {
        id: 'msg-g1',
        author: { name: 'DiscordBot Pro', avatar: '🤖', isBot: true, roleColor: '#5865F2' },
        content: 'أهلاً بالجميع في سيرفر المحاكاة! البوت محدث بأحدث أنظمة التذاكر، الرقابة، تتبع الدعوات (-i أو i)، ومعلومات السيرفر (ip)، والذكاء الاصطناعي.',
        timestamp: 'اليوم في 12:00 م',
      },
      {
        id: 'msg-g2',
        author: { name: 'خالد (عضو)', avatar: '🧑', roleColor: '#99AAB5' },
        content: 'السلام عليكم، شباب ما هو آي بي سيرفر ماين كرافت؟',
        timestamp: 'اليوم في 12:05 م',
      },
    ],
    'ai-chat': [
      {
        id: 'msg-ai-1',
        author: { name: 'DiscordBot Pro', avatar: '🤖', isBot: true, roleColor: '#5865F2' },
        content: '',
        timestamp: 'اليوم في 12:00 م',
        embed: {
          title: '✨ قناة الذكاء الاصطناعي التفاعلية (AI Setup Active)',
          description: 'هذا الروم مخصص للتحدث مباشرة مع Gemini 3.8 Flash! أي رسالة تكتبها هنا بدون أوامر وبدون منشن سيرد عليها الذكاء الاصطناعي فورياً.',
          color: '#5865F2',
          footer: 'مفعل عبر أمر /ai setup',
        },
      },
    ],
    commands: [
      {
        id: 'msg-c1',
        author: { name: 'DiscordBot Pro', avatar: '🤖', isBot: true, roleColor: '#5865F2' },
        content: 'جرب الأوامر التالية:\n• اكتب `ip` أو `-ip` لعرض معلومات سيرفر hitrexsmp.halix.gg\n• اكتب `-i` أو `i` لعرض إحصائيات دعواتك\n• اكتب `/ai setup` لجعل الروم مخصص للذكاء الاصطناعي\n• جرب التبديل بين رتبة المشرف ورتبة العضو بالأعلى لتجربة صلاحيات الإدارة!',
        timestamp: 'اليوم في 12:00 م',
      },
    ],
    tickets: [
      {
        id: 'msg-t1',
        author: { name: 'DiscordBot Pro', avatar: '🤖', isBot: true, roleColor: '#5865F2' },
        content: '',
        timestamp: 'اليوم في 12:00 م',
        embed: {
          title: '🎫 مركز الدعم الفني والتذاكر',
          description:
            'مرحباً بك في مركز خدمة الأعضاء! إذا كنت بحاجة للمساعدة، اختر القسم المناسب من الأزرار أدناه لفتح تذكرة خاصة بك وفورية.',
          color: '#00B0F4',
          fields: [
            { name: '🛠️ الدعم الفني', value: 'لحل المشاكل التقنية والاستفسارات', inline: true },
            { name: '💳 المبيعات', value: 'لشراء الرتب والاشتراكات', inline: true },
            { name: '📩 الشكاوى', value: 'لرفع بلاغ أو مقترح لإدارة السيرفر', inline: true },
          ],
          footer: 'نظام التذاكر الآلي · انقر على الزر لفتح تذكرتك',
        },
        components: [
          {
            type: 'buttons',
            buttons: [
              { id: 'btn_support', label: 'دعم فني', style: 'primary', emoji: '🛠️' },
              { id: 'btn_billing', label: 'مبيعات', style: 'success', emoji: '💳' },
              { id: 'btn_report', label: 'شكوى / بلاغ', style: 'danger', emoji: '📩' },
            ],
          },
        ],
      },
    ],
    modlogs: [
      {
        id: 'msg-m1',
        author: { name: 'DiscordBot Pro', avatar: '🤖', isBot: true, roleColor: '#5865F2' },
        content: '',
        timestamp: 'اليوم في 12:00 م',
        embed: {
          title: '🛡️ سجل الرقابة والحماية (Audit Log)',
          description: 'يتم تسجيل كافة إجراءات الحظر والطرد والتحذيرات والوضع البطيء هنا تلقائياً.',
          color: '#ED4245',
        },
      },
    ],
  });

  const chatBottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [channelMessages, activeChannel]);

  const addMessageToChannel = (channelId: string, msg: SimulatedMessage) => {
    setChannelMessages((prev) => ({
      ...prev,
      [channelId]: [...(prev[channelId] || []), msg],
    }));
  };

  const [simModal, setSimModal] = useState<{ open: boolean; dept: string; deptName: string } | null>(null);
  const [modalTopic, setModalTopic] = useState('');
  const [modalDesc, setModalDesc] = useState('');

  // Handle Button Clicks
  const handleButtonClick = async (buttonId: string) => {
    const timeNow = new Date().toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' });

    if (buttonId === 'btn_support') {
      setSimModal({ open: true, dept: 'support', deptName: 'الدعم الفني' });
    } else if (buttonId === 'btn_billing') {
      setSimModal({ open: true, dept: 'billing', deptName: 'المبيعات' });
    } else if (buttonId === 'btn_report') {
      setSimModal({ open: true, dept: 'report', deptName: 'الشكاوى والبلاغات' });
    } else if (buttonId.startsWith('action_close_')) {
      const channelId = buttonId.replace('action_close_', '');
      addMessageToChannel(channelId, {
        id: `msg-${Date.now()}`,
        author: { name: 'DiscordBot Pro', avatar: '🤖', isBot: true, roleColor: '#ED4245' },
        content: '🔒 **سيتم أرشفة وحذف هذه التذكرة خلال 3 ثوانٍ...**',
        timestamp: timeNow,
      });

      setTimeout(() => {
        setDynamicChannels((prev) => prev.filter((c) => c.id !== channelId));
        setActiveChannel('tickets');
      }, 3000);
    } else if (buttonId.startsWith('action_claim_')) {
      const channelId = buttonId.replace('action_claim_', '');
      addMessageToChannel(channelId, {
        id: `msg-${Date.now()}`,
        author: { name: 'DiscordBot Pro', avatar: '🤖', isBot: true, roleColor: '#5865F2' },
        content: '🙋‍♂️ **تم استلام التذكرة من قبل المشرف [عبد الله]! هو يتابع طلبك الآن وسيرد عليك.**',
        timestamp: timeNow,
      });
    } else if (buttonId.startsWith('action_transcript_')) {
      const channelId = buttonId.replace('action_transcript_', '');
      const msgs = channelMessages[channelId] || [];
      const lines = [
        `===========================================`,
        `تفريغ محادثة تذكرة ديسكورد: #${channelId}`,
        `التاريخ: ${new Date().toLocaleDateString('ar-SA')}`,
        `===========================================`,
        '',
        ...msgs.map((m) => `[${m.timestamp}] ${m.author.name}: ${m.content || (m.embed?.title ? `[Embed: ${m.embed.title}]` : '')}`),
      ].join('\n');

      const blob = new Blob([lines], { type: 'text/plain;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `transcript-${channelId}.txt`;
      link.click();
      URL.revokeObjectURL(url);

      addMessageToChannel(channelId, {
        id: `msg-${Date.now()}`,
        author: { name: 'DiscordBot Pro', avatar: '🤖', isBot: true, roleColor: '#57F287' },
        content: '📄 **تم استخراج تفريغ المحادثة (Transcript) وتحميل الملف بنجاح!**',
        timestamp: timeNow,
      });
    } else if (buttonId.startsWith('action_ai_help_')) {
      const channelId = buttonId.replace('action_ai_help_', '');
      setIsAiLoading(true);
      try {
        const res = await fetch('/api/ai/ask', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            prompt: 'قدم 2 إلى 3 نصائح عملية وذكية لمساعدة العضو في حل مشكلته قبل وصول طاقم الدعم.',
          }),
        });
        const data = await res.json();
        addMessageToChannel(channelId, {
          id: `msg-${Date.now()}`,
          author: { name: 'Gemini AI Assistant', avatar: '✨', isBot: true, roleColor: '#FEE75C' },
          content: '',
          timestamp: timeNow,
          embed: {
            title: '🤖 نصائح فورية من الذكاء الاصطناعي (Gemini 3.8 Flash)',
            description: data.text || 'يرجى تزويدنا بتفاصيل إضافية لمساعدتك بشكل أسرع.',
            color: '#FEE75C',
          },
        });
      } catch {
        addMessageToChannel(channelId, {
          id: `msg-${Date.now()}`,
          author: { name: 'Gemini AI Assistant', avatar: '✨', isBot: true, roleColor: '#FEE75C' },
          content: 'أهلاً بك! لتسريع تقديم الحل، يرجى كتابة المشكلة بالتفصيل وإرفاق أي لقطات شاشة.',
          timestamp: timeNow,
        });
      }
      setIsAiLoading(false);
    }
  };

  // Submit Modal & Create Ticket Channel
  const handleModalSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!simModal || !modalTopic.trim()) return;

    const timeNow = new Date().toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' });
    const selected = {
      name: simModal.deptName,
      category: (simModal.dept as SimulatedTicket['category']) || 'support',
    };
    const newChannelId = `ticket-${String(ticketCounter).padStart(3, '0')}`;
    const channelDisplayName = `ticket-${simModal.dept}-${ticketCounter}`;

    setTicketCounter((c) => c + 1);
    setDynamicChannels((prev) => [...prev, { id: newChannelId, name: channelDisplayName }]);

    const newTicket: SimulatedTicket = {
      id: newChannelId,
      channelName: channelDisplayName,
      creator: 'أنت (المستخدم)',
      category: selected.category,
      status: 'open',
      createdAt: timeNow,
      messages: [
        {
          author: 'DiscordBot Pro',
          text: `موضوع التذكرة: ${modalTopic}\nالتفاصيل: ${modalDesc || 'لا توجد تفاصيل إضافية'}`,
          time: timeNow,
        },
      ],
    };
    onAddTicket(newTicket);

    const initialTicketMsg: SimulatedMessage = {
      id: `msg-${Date.now()}`,
      author: { name: 'DiscordBot Pro', avatar: '🤖', isBot: true, roleColor: '#5865F2' },
      content: 'مرحباً بك! تم إنشاء تذكرتك بنجاح وسيقوم المشرف المسؤول بمتابعتها معك.',
      timestamp: timeNow,
      embed: {
        title: `🎫 تذكرة ${selected.name} | #${channelDisplayName}`,
        description: `العضو: **أنت**\nالحالة: **مفتوحة**\nالقسم: **${selected.name}**\n\n📌 **الموضوع:** ${modalTopic}\n📝 **التفاصيل:** ${modalDesc || 'لا توجد تفاصيل إضافية'}`,
        color: '#57F287',
        footer: 'استخدم الأزرار أدناه للتحكم في التذكرة',
      },
      components: [
        {
          type: 'buttons',
          buttons: [
            { id: `action_close_${newChannelId}`, label: 'إغلاق وأرشفة', style: 'danger', emoji: '🔒' },
            { id: `action_claim_${newChannelId}`, label: 'استلام التذكرة', style: 'secondary', emoji: '🙋‍♂️' },
            { id: `action_transcript_${newChannelId}`, label: 'تفريغ المحادثة', style: 'primary', emoji: '📄' },
            { id: `action_ai_help_${newChannelId}`, label: 'اقتراح ذكي (AI)', style: 'success', emoji: '✨' },
          ],
        },
      ],
    };

    setChannelMessages((prev) => ({
      ...prev,
      [newChannelId]: [initialTicketMsg],
    }));

    setSimModal(null);
    setModalTopic('');
    setModalDesc('');
    setActiveChannel(newChannelId);
  };

  // Helper to output Minecraft IP Embed
  const sendMinecraftIpEmbed = (channelId: string, timeNow: string) => {
    addMessageToChannel(channelId, {
      id: `msg-${Date.now()}`,
      author: { name: 'DiscordBot Pro', avatar: '🤖', isBot: true, roleColor: '#57F287' },
      content: '',
      timestamp: timeNow,
      embed: {
        title: '⛏️ معلومات سيرفر Hitrex SMP ماين كرافت',
        description:
          'أهلاً بك في سيرفر **Hitrex SMP** الرسمي! سيرفر سرفايفل متطور، كستم إينشانتس، ورتب، ونظام اقتصادي فريد.',
        color: '#57F287',
        fields: [
          { name: '🌐 عنوان السيرفر (Java IP)', value: '`hitrexsmp.halix.gg`', inline: true },
          { name: '🔌 منفذ الجافا (Java Port)', value: '`25565` (الافتراضي)', inline: true },
          { name: '📱 منفذ الجوال (Bedrock Port)', value: '`19132`', inline: true },
          { name: '🎮 الإصدارات المدعومة', value: '`1.16.x - 1.21.x` (يدعم جميع التحديثات)', inline: true },
          { name: '⚡ حالة السيرفر', value: '🟢 **متصل ومتاح للجميع (Online)**', inline: true },
          { name: '🌟 نوع السيرفر', value: 'Survival SMP · Crossplay (PC + Mobile)', inline: true },
        ],
        footer: 'Hitrex SMP · انسخ الآي بي والعب معنا الآن!',
      },
    });
  };

  // Helper to output Invites Embed
  const sendInvitesEmbed = (channelId: string, timeNow: string) => {
    addMessageToChannel(channelId, {
      id: `msg-${Date.now()}`,
      author: { name: 'DiscordBot Pro', avatar: '🤖', isBot: true, roleColor: '#5865F2' },
      content: '',
      timestamp: timeNow,
      embed: {
        title: '📨 إحصائيات دعوات العضو | أنت',
        description: 'إليك تقرير مفصل بجميع الدعوات التي قمت بجلبها للسيرفر:',
        color: '#5865F2',
        fields: [
          { name: '✨ إجمالي الدعوات', value: '**18** دعوة', inline: true },
          { name: '✅ دعوات حقيقية مؤكدة', value: '**15** عضو نشط', inline: true },
          { name: '🚪 أعضاء غادروا', value: '**3** أعضاء', inline: true },
          { name: '⚠️ حسابات وهمية', value: '**0** حساب', inline: true },
          { name: '🔗 كود الدعوة الخاص بك', value: '`discord.gg/hitrex-you`', inline: false },
        ],
        footer: 'نظام تتبع الدعوات الآلي · تحديث لحظي فور دخول الأعضاء',
      },
    });
  };

  // Submit chat input or slash command
  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const text = inputVal.trim();
    if (!text) return;
    setInputVal('');

    const timeNow = new Date().toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' });
    const cleanLower = text.toLowerCase();

    // 1. Post User message
    const userMsg: SimulatedMessage = {
      id: `msg-${Date.now()}`,
      author: {
        name: simulatedRole === 'admin' ? 'أنت (👑 مشرف)' : 'أنت (🧑 لاعب)',
        avatar: simulatedRole === 'admin' ? '👑' : '🧑',
        roleColor: simulatedRole === 'admin' ? '#E67E22' : '#FFFFFF',
      },
      content: text,
      timestamp: timeNow,
    };
    addMessageToChannel(activeChannel, userMsg);

    // 2. Direct Triggers for Minecraft IP: "ip", "-ip", "!ip", "/ip", "اي بي", "سيرفر"
    if (
      cleanLower === 'ip' ||
      cleanLower === '-ip' ||
      cleanLower === '!ip' ||
      cleanLower === '/ip' ||
      cleanLower === 'اي بي' ||
      cleanLower === 'سيرفر'
    ) {
      setTimeout(() => {
        sendMinecraftIpEmbed(activeChannel, timeNow);
      }, 300);
      return;
    }

    // 3. Direct Triggers for Invites: "-i", "i", "/invites", "-i @user"
    if (
      cleanLower === '-i' ||
      cleanLower === 'i' ||
      cleanLower.startsWith('-i ') ||
      cleanLower.startsWith('i ') ||
      cleanLower === '/invites'
    ) {
      setTimeout(() => {
        sendInvitesEmbed(activeChannel, timeNow);
      }, 300);
      return;
    }

    // 4. Auto-Responders Check
    if (cleanLower === 'سلام' || cleanLower === 'السلام عليكم') {
      setTimeout(() => {
        addMessageToChannel(activeChannel, {
          id: `msg-${Date.now()}`,
          author: { name: 'DiscordBot Pro', avatar: '🤖', isBot: true, roleColor: '#5865F2' },
          content: 'وعليكم السلام ورحمة الله وبركاته! أهلاً وسهلاً بك في السيرفر 🌟',
          timestamp: timeNow,
        });
      }, 300);
      return;
    }

    if (cleanLower.includes('قوانين')) {
      setTimeout(() => {
        addMessageToChannel(activeChannel, {
          id: `msg-${Date.now()}`,
          author: { name: 'DiscordBot Pro', avatar: '🤖', isBot: true, roleColor: '#5865F2' },
          content: '📜 يرجى مراجعة روم القوانين الرسمية لتجنب أي عقوبات أو كتم. نتمنى لك تجربة ممتعة!',
          timestamp: timeNow,
        });
      }, 300);
      return;
    }

    // 5. Check if in Dedicated AI Channel (where ANY message gets an AI reply!)
    const isAiChannel = aiChannels.has(activeChannel);

    // If it's a Slash Command
    if (text.startsWith('/')) {
      const parts = text.slice(1).split(' ');
      const cmd = parts[0].toLowerCase();
      const sub = parts[1]?.toLowerCase();
      const args = parts.slice(1);

      // List of Admin-Only Commands
      const adminOnlyCmds = ['ban', 'kick', 'warn', 'clear', 'setup-tickets', 'slowmode'];

      // If user is regular member and tries an admin command -> PERMISSION BLOCKED!
      if (
        (adminOnlyCmds.includes(cmd) || (cmd === 'ai' && (sub === 'setup' || sub === 'disable'))) &&
        simulatedRole !== 'admin'
      ) {
        setTimeout(() => {
          addMessageToChannel(activeChannel, {
            id: `msg-${Date.now()}`,
            author: { name: 'DiscordBot Pro', avatar: '🤖', isBot: true, roleColor: '#ED4245' },
            content:
              '⛔ **عفواً! هذا الأمر مخصص للإدارة وأعضاء الطاقم الإداري فقط ولا يمكنك استخدامه كلاعب أو عضو عادي.**',
            timestamp: timeNow,
          });
        }, 300);
        return;
      }

      // Execute Commands
      if (cmd === 'help') {
        setTimeout(() => {
          addMessageToChannel(activeChannel, {
            id: `msg-${Date.now()}`,
            author: { name: 'DiscordBot Pro', avatar: '🤖', isBot: true, roleColor: '#5865F2' },
            content: '',
            timestamp: timeNow,
            embed: {
              title: '🛡️ دليل أوامر البوت المحدث والشامل',
              description: 'إليك قائمة الأوامر المصنفة حسب الصلاحيات:',
              color: '#5865F2',
              fields: [
                {
                  name: '🎮 أوامر اللاعبين العامة (متاحة للجميع)',
                  value:
                    '`ip` أو `/ip` - عرض معلومات سيرفر Hitrex SMP\n`-i` أو `i` أو `/invites` - عرض إحصائيات دعواتك\n`/ask [سؤال]` - سؤال الذكاء الاصطناعي\n`/ping` - سرعة استجابة البوت',
                },
                {
                  name: '🎫 التذاكر (Tickets)',
                  value:
                    '`/setup-tickets` - إنشاء لوحة التذاكر (👑 للإدارة فقط)\n`/ticket close` - إغلاق وأرشفة التذكرة\n`/ticket claim` - استلام التذكرة من الطاقم',
                },
                {
                  name: '🤖 الذكاء الاصطناعي (Gemini AI)',
                  value:
                    '`/ai setup` - جعل القناة الحالية تتفاعل تلقائياً مع أي رسالة (👑 للإدارة)\n`/ai disable` - إلغاء تفعيل قناة الذكاء الاصطناعي',
                },
                {
                  name: '🔨 الإشراف والرقابة (👑 للإدارة فقط)',
                  value:
                    '`/warn @user [سبب]` - إنذار رسمي\n`/ban @user [سبب]` - حظر نهائي\n`/kick @user` - طرد\n`/clear [عدد]` - مسح الرسائل',
                },
              ],
              footer: 'ديسكورد بوت برو · الأوامر الإدارية محمية بالكامل ضد اللاعبين العاديين',
            },
          });
        }, 300);
      } else if (cmd === 'ai') {
        if (sub === 'setup') {
          setAiChannels((prev) => new Set([...prev, activeChannel]));
          setTimeout(() => {
            addMessageToChannel(activeChannel, {
              id: `msg-${Date.now()}`,
              author: { name: 'DiscordBot Pro', avatar: '🤖', isBot: true, roleColor: '#57F287' },
              content: '',
              timestamp: timeNow,
              embed: {
                title: '✨ تم تفعيل قناة الذكاء الاصطناعي بنجاح!',
                description: `الآن أي رسالة تكتب في هذا الروم (<#${activeChannel}>) سيقوم الذكاء الاصطناعي (Gemini 3.8 Flash) بالرد عليها فورياً وبشكل تلقائي دون الحاجة لمنشن أو أوامر!`,
                color: '#57F287',
                footer: 'تم التفعيل بنجاح بواسطة المشرف · اكتب أي شيء في الشات للتجربة',
              },
            });
          }, 300);
        } else if (sub === 'disable') {
          setAiChannels((prev) => {
            const next = new Set(prev);
            next.delete(activeChannel);
            return next;
          });
          setTimeout(() => {
            addMessageToChannel(activeChannel, {
              id: `msg-${Date.now()}`,
              author: { name: 'DiscordBot Pro', avatar: '🤖', isBot: true, roleColor: '#FEE75C' },
              content: `ℹ️ تم إيقاف وضع الرد التلقائي للذكاء الاصطناعي في هذه القناة.`,
              timestamp: timeNow,
            });
          }, 300);
        } else {
          // Ask directly
          const prompt = args.slice(1).join(' ') || sub || 'مرحباً';
          setIsAiLoading(true);
          try {
            const res = await fetch('/api/ai/ask', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ prompt }),
            });
            const data = await res.json();
            setIsAiLoading(false);
            addMessageToChannel(activeChannel, {
              id: `msg-${Date.now()}`,
              author: { name: 'Gemini AI Assistant', avatar: '✨', isBot: true, roleColor: '#5865F2' },
              content: data.text || 'أهلاً بك! كيف أساعدك اليوم؟',
              timestamp: timeNow,
            });
          } catch {
            setIsAiLoading(false);
          }
        }
      } else if (cmd === 'setup-tickets') {
        setTimeout(() => {
          addMessageToChannel(activeChannel, {
            id: `msg-${Date.now()}`,
            author: { name: 'DiscordBot Pro', avatar: '🤖', isBot: true, roleColor: '#5865F2' },
            content: '',
            timestamp: timeNow,
            embed: {
              title: '🎫 مركز الدعم الفني والتذاكر',
              description:
                'مرحباً بك! اختر القسم المناسب من الأزرار أدناه لفتح تذكرة خاصة بك مع فريق الدعم الفني.',
              color: '#00B0F4',
              fields: [
                { name: '🛠️ الدعم الفني', value: 'لحل المشاكل التقنية والاستفسارات', inline: true },
                { name: '💳 المبيعات', value: 'لشراء الرتب والخدمات', inline: true },
                { name: '📩 الشكاوى', value: 'لرفع بلاغ أو مقترح', inline: true },
              ],
            },
            components: [
              {
                type: 'buttons',
                buttons: [
                  { id: 'btn_support', label: 'دعم فني', style: 'primary', emoji: '🛠️' },
                  { id: 'btn_billing', label: 'مبيعات', style: 'success', emoji: '💳' },
                  { id: 'btn_report', label: 'شكوى / بلاغ', style: 'danger', emoji: '📩' },
                ],
              },
            ],
          });
        }, 300);
      } else if (cmd === 'ask') {
        const prompt = args.join(' ');
        if (!prompt) {
          addMessageToChannel(activeChannel, {
            id: `msg-${Date.now()}`,
            author: { name: 'DiscordBot Pro', avatar: '🤖', isBot: true, roleColor: '#ED4245' },
            content: '⚠️ يرجى كتابة السؤال بعد الأمر، مثال: `/ask ما هي أفضل طريقة لتنظيم السيرفر؟`',
            timestamp: timeNow,
          });
          return;
        }

        setIsAiLoading(true);
        try {
          const res = await fetch('/api/ai/ask', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ prompt }),
          });
          const data = await res.json();
          setIsAiLoading(false);

          addMessageToChannel(activeChannel, {
            id: `msg-${Date.now()}`,
            author: { name: 'DiscordBot Pro', avatar: '🤖', isBot: true, roleColor: '#5865F2' },
            content: '',
            timestamp: timeNow,
            embed: {
              title: '🤖 إجابة الذكاء الاصطناعي (Gemini 3.8 Flash)',
              description: data.text || 'تمت الإجابة بنجاح.',
              color: '#FEE75C',
              footer: `السؤال: ${prompt}`,
            },
          });
        } catch {
          setIsAiLoading(false);
          addMessageToChannel(activeChannel, {
            id: `msg-${Date.now()}`,
            author: { name: 'DiscordBot Pro', avatar: '🤖', isBot: true, roleColor: '#5865F2' },
            content: `🤖 إجابة الذكاء الاصطناعي على: "${prompt}":\n\nأهلاً بك! تم الاتصال بالمساعد الذكي بنجاح.`,
            timestamp: timeNow,
          });
        }
      } else if (cmd === 'warn') {
        const target = args[0] || '@عضو_مخالف';
        const reason = args.slice(1).join(' ') || 'مخالفة قوانين المحادثة';

        onAddModerationLog({
          id: `log-${Date.now()}`,
          action: 'warn',
          targetUser: target,
          moderator: 'أنت (👑 مشرف)',
          reason,
          timestamp: timeNow,
        });

        setTimeout(() => {
          addMessageToChannel(activeChannel, {
            id: `msg-${Date.now()}`,
            author: { name: 'DiscordBot Pro', avatar: '🤖', isBot: true, roleColor: '#FEE75C' },
            content: '',
            timestamp: timeNow,
            embed: {
              title: '⚠️ تحذير رسمي مسجل',
              description: `تم توجيه إنذار رسمي للعضو **${target}**.\n**السبب:** ${reason}\n**المشرف:** أنت (إدارة السيرفر)`,
              color: '#FEE75C',
            },
          });
        }, 300);
      } else if (cmd === 'ban') {
        const target = args[0] || '@مخالف';
        const reason = args.slice(1).join(' ') || 'مخالفة الشروط والسبام المتكرر';

        onAddModerationLog({
          id: `log-${Date.now()}`,
          action: 'ban',
          targetUser: target,
          moderator: 'أنت (👑 مشرف)',
          reason,
          timestamp: timeNow,
        });

        setTimeout(() => {
          addMessageToChannel(activeChannel, {
            id: `msg-${Date.now()}`,
            author: { name: 'DiscordBot Pro', avatar: '🤖', isBot: true, roleColor: '#ED4245' },
            content: '',
            timestamp: timeNow,
            embed: {
              title: '🔨 تم حظر العضو نهائياً (BAN)',
              description: `تم حظر العضو **${target}** من السيرفر.\n**السبب:** ${reason}`,
              color: '#ED4245',
            },
          });
        }, 300);
      } else if (cmd === 'clear') {
        const amount = parseInt(args[0], 10) || 5;
        setChannelMessages((prev) => ({
          ...prev,
          [activeChannel]: (prev[activeChannel] || []).slice(-2),
        }));

        setTimeout(() => {
          addMessageToChannel(activeChannel, {
            id: `msg-${Date.now()}`,
            author: { name: 'DiscordBot Pro', avatar: '🤖', isBot: true, roleColor: '#57F287' },
            content: `🧹 **تم مسح ${amount} رسائل من هذا الروم بنجاح!**`,
            timestamp: timeNow,
          });
        }, 200);
      } else {
        setTimeout(() => {
          addMessageToChannel(activeChannel, {
            id: `msg-${Date.now()}`,
            author: { name: 'DiscordBot Pro', avatar: '🤖', isBot: true, roleColor: '#ED4245' },
            content: `⚠️ أمر غير معروف: \`/${cmd}\`. اكتب \`/help\` لعرض قائمة الأوامر المتاحة.`,
            timestamp: timeNow,
          });
        }, 200);
      }
      return;
    }

    // 6. Mention Bot OR In Dedicated AI Channel
    if (isAiChannel || text.includes('@DiscordBot') || text.includes('@bot') || text.includes('بوت')) {
      setIsAiLoading(true);
      try {
        const res = await fetch('/api/ai/ask', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ prompt: text }),
        });
        const data = await res.json();
        setIsAiLoading(false);
        addMessageToChannel(activeChannel, {
          id: `msg-${Date.now()}`,
          author: { name: 'Gemini AI (بوت)', avatar: '✨', isBot: true, roleColor: '#5865F2' },
          content: data.text || 'أهلاً بك! كيف أستطيع مساعدتك اليوم؟',
          timestamp: timeNow,
        });
      } catch {
        setIsAiLoading(false);
        addMessageToChannel(activeChannel, {
          id: `msg-${Date.now()}`,
          author: { name: 'Gemini AI (بوت)', avatar: '✨', isBot: true, roleColor: '#5865F2' },
          content: 'أهلاً بك! أنا في خدمتك، يمكنك سؤالي عن أي شيء وسأجيبك فوراً.',
          timestamp: timeNow,
        });
      }
    }
  };

  const handleCopyIp = () => {
    navigator.clipboard.writeText('hitrexsmp.halix.gg');
    setCopiedIp(true);
    setTimeout(() => setCopiedIp(false), 2000);
  };

  const currentMessages = channelMessages[activeChannel] || [];

  return (
    <div className="space-y-4">
      {/* Simulator Control Ribbon: Role Switcher & Quick Commands */}
      <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-4 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        {/* Role Switcher */}
        <div className="flex items-center gap-3">
          <span className="text-xs font-semibold text-stone-500 dark:text-stone-400">
            صلاحيتك في المحاكي:
          </span>
          <div className="inline-flex rounded-xl bg-stone-100 dark:bg-stone-800 p-1">
            <button
              onClick={() => setSimulatedRole('admin')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                simulatedRole === 'admin'
                  ? 'bg-amber-500 text-white shadow-xs'
                  : 'text-stone-600 dark:text-stone-300 hover:text-stone-900'
              }`}
            >
              <Crown className="w-3.5 h-3.5" />
              <span>👑 مشرف (Admin)</span>
            </button>
            <button
              onClick={() => setSimulatedRole('member')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                simulatedRole === 'member'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-stone-600 dark:text-stone-300 hover:text-stone-900'
              }`}
            >
              <UserIcon className="w-3.5 h-3.5" />
              <span>🧑 لاعب عادي (Member)</span>
            </button>
          </div>
          {simulatedRole === 'member' && (
            <span className="text-[11px] text-amber-600 dark:text-amber-400 font-medium">
              (جرب تنفيذ /ban أو /ai setup لرؤية منع الصلاحيات!)
            </span>
          )}
        </div>

        {/* Quick Click Prompts */}
        <div className="flex items-center gap-2 flex-wrap text-xs">
          <span className="text-stone-400 text-[11px]">أوامر سريعة:</span>
          <button
            onClick={() => {
              setInputVal('ip');
            }}
            className="px-2.5 py-1 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100 font-mono font-bold"
          >
            ip
          </button>
          <button
            onClick={() => {
              setInputVal('-i');
            }}
            className="px-2.5 py-1 rounded-lg bg-purple-50 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800 hover:bg-purple-100 font-mono font-bold"
          >
            -i
          </button>
          <button
            onClick={() => {
              setInputVal('/ai setup');
            }}
            className="px-2.5 py-1 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 hover:bg-indigo-100 font-mono font-bold"
          >
            /ai setup
          </button>
          <button
            onClick={handleCopyIp}
            className="px-2.5 py-1 rounded-lg bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 hover:bg-stone-200 flex items-center gap-1 font-mono text-[11px]"
          >
            {copiedIp ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
            <span>نسخ الآي بي</span>
          </button>
        </div>
      </div>

      {/* Main Discord Box */}
      <div className="rounded-2xl border border-[#202225] bg-[#313338] text-[#dbdee1] overflow-hidden shadow-2xl flex flex-col h-[650px] font-sans">
        {/* Discord Top App Bar */}
        <div className="h-12 bg-[#2b2d31] border-b border-[#1f2023] px-4 flex items-center justify-between select-none">
          <div className="flex items-center gap-2 font-bold text-white text-sm">
            <Hash className="w-5 h-5 text-[#80848e]" />
            <span>{activeChannel}</span>
            {aiChannels.has(activeChannel) && (
              <span className="text-[10px] bg-indigo-600 text-white px-2 py-0.5 rounded-full font-bold flex items-center gap-1">
                <Sparkles className="w-3 h-3" />
                <span>AI Channel Active</span>
              </span>
            )}
            <span className="text-xs text-[#949ba4] font-normal hidden sm:inline">
              · محاكي سيرفر ديسكورد التفاعلي المباشر
            </span>
          </div>

          <div className="flex items-center gap-2 text-xs">
            <span className="bg-[#232428] text-[#949ba4] px-2.5 py-1 rounded font-mono text-[11px]">
              Hitrex SMP Edition
            </span>
          </div>
        </div>

        {/* Main Body */}
        <div className="flex-1 flex overflow-hidden">
          {/* Channels Sidebar */}
          <div className="w-56 bg-[#2b2d31] p-3 flex flex-col justify-between border-e border-[#1f2023] select-none shrink-0 overflow-y-auto">
            <div className="space-y-4">
              <div className="font-bold text-white text-sm px-2 pb-2 border-b border-[#35373c] flex items-center justify-between">
                <span>Hitrex SMP Server</span>
                <Shield className="w-4 h-4 text-[#5865F2]" />
              </div>

              <div>
                <div className="text-[11px] font-bold text-[#949ba4] uppercase px-2 mb-1">
                  قنوات عامة
                </div>
                <div className="space-y-0.5">
                  <button
                    onClick={() => setActiveChannel('general')}
                    className={`w-full flex items-center gap-1.5 px-2 py-1.5 rounded text-xs transition-colors text-start ${
                      activeChannel === 'general'
                        ? 'bg-[#35373c] text-white font-medium'
                        : 'text-[#949ba4] hover:bg-[#35373c]/50 hover:text-[#dbdee1]'
                    }`}
                  >
                    <Hash className="w-4 h-4 shrink-0" />
                    <span className="truncate">شات-عام</span>
                  </button>

                  <button
                    onClick={() => setActiveChannel('ai-chat')}
                    className={`w-full flex items-center gap-1.5 px-2 py-1.5 rounded text-xs transition-colors text-start ${
                      activeChannel === 'ai-chat'
                        ? 'bg-[#35373c] text-indigo-400 font-medium'
                        : 'text-indigo-400/80 hover:bg-[#35373c]/50'
                    }`}
                  >
                    <Sparkles className="w-4 h-4 shrink-0 text-indigo-400" />
                    <span className="truncate">🤖-الذكاء-الاصطناعي</span>
                  </button>

                  <button
                    onClick={() => setActiveChannel('commands')}
                    className={`w-full flex items-center gap-1.5 px-2 py-1.5 rounded text-xs transition-colors text-start ${
                      activeChannel === 'commands'
                        ? 'bg-[#35373c] text-white font-medium'
                        : 'text-[#949ba4] hover:bg-[#35373c]/50 hover:text-[#dbdee1]'
                    }`}
                  >
                    <Hash className="w-4 h-4 shrink-0" />
                    <span className="truncate">أوامر-البوت</span>
                  </button>

                  <button
                    onClick={() => setActiveChannel('tickets')}
                    className={`w-full flex items-center gap-1.5 px-2 py-1.5 rounded text-xs transition-colors text-start ${
                      activeChannel === 'tickets'
                        ? 'bg-[#35373c] text-white font-medium'
                        : 'text-[#949ba4] hover:bg-[#35373c]/50 hover:text-[#dbdee1]'
                    }`}
                  >
                    <Hash className="w-4 h-4 shrink-0" />
                    <span className="truncate">🎫-فتح-تذكرة</span>
                  </button>

                  <button
                    onClick={() => setActiveChannel('modlogs')}
                    className={`w-full flex items-center gap-1.5 px-2 py-1.5 rounded text-xs transition-colors text-start ${
                      activeChannel === 'modlogs'
                        ? 'bg-[#35373c] text-white font-medium'
                        : 'text-[#949ba4] hover:bg-[#35373c]/50 hover:text-[#dbdee1]'
                    }`}
                  >
                    <Hash className="w-4 h-4 shrink-0" />
                    <span className="truncate">🛡️-سجل-الرقابة</span>
                  </button>
                </div>
              </div>

              {/* Dynamic Ticket Channels */}
              {dynamicChannels.length > 0 && (
                <div>
                  <div className="text-[11px] font-bold text-[#57F287] uppercase px-2 mb-1 flex items-center justify-between">
                    <span>تذاكر مفتوحة ({dynamicChannels.length})</span>
                  </div>
                  <div className="space-y-0.5">
                    {dynamicChannels.map((c) => (
                      <button
                        key={c.id}
                        onClick={() => setActiveChannel(c.id)}
                        className={`w-full flex items-center gap-1.5 px-2 py-1.5 rounded text-xs transition-colors text-start ${
                          activeChannel === c.id
                            ? 'bg-[#35373c] text-[#57F287] font-medium'
                            : 'text-[#57F287]/80 hover:bg-[#35373c]/50'
                        }`}
                      >
                        <Hash className="w-4 h-4 shrink-0" />
                        <span className="truncate">{c.name}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Current User Role Bar */}
            <div className="bg-[#232428] -mx-3 -mb-3 p-2.5 flex items-center justify-between border-t border-[#1f2023]">
              <div className="flex items-center gap-2">
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-sm ${
                    simulatedRole === 'admin' ? 'bg-amber-500' : 'bg-indigo-600'
                  }`}
                >
                  {simulatedRole === 'admin' ? '👑' : '🧑'}
                </div>
                <div className="text-xs">
                  <div className="font-bold text-white flex items-center gap-1">
                    <span>أنت</span>
                    <span className="text-[10px] text-amber-400 font-mono">
                      [{simulatedRole === 'admin' ? 'ADMIN' : 'PLAYER'}]
                    </span>
                  </div>
                  <div className="text-[10px] text-[#949ba4]">متصل الآن</div>
                </div>
              </div>
            </div>
          </div>

          {/* Chat Messages Viewport */}
          <div className="flex-1 flex flex-col justify-between bg-[#313338] overflow-hidden">
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {currentMessages.map((msg) => (
                <div
                  key={msg.id}
                  className="flex items-start gap-3 group hover:bg-[#2e3035]/40 p-1.5 rounded transition-colors text-start"
                >
                  <div className="w-9 h-9 rounded-full bg-[#5865F2] text-white flex items-center justify-center text-base shrink-0 mt-0.5 shadow-xs">
                    {msg.author.avatar}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-baseline gap-2 mb-1">
                      <span
                        className="font-semibold text-xs sm:text-sm"
                        style={{ color: msg.author.roleColor || '#FFFFFF' }}
                      >
                        {msg.author.name}
                      </span>
                      {msg.author.isBot && (
                        <span className="bg-[#5865F2] text-white text-[10px] font-bold px-1.5 py-0.2 rounded uppercase">
                          BOT
                        </span>
                      )}
                      <span className="text-[10px] text-[#949ba4]">{msg.timestamp}</span>
                    </div>

                    {msg.content && (
                      <div className="text-sm text-[#dbdee1] leading-relaxed whitespace-pre-wrap font-sans">
                        {msg.content}
                      </div>
                    )}

                    {/* Embed Box */}
                    {msg.embed && (
                      <div
                        className="mt-2.5 rounded-lg bg-[#2b2d31] p-4 border-r-4 max-w-xl text-xs sm:text-sm shadow-md"
                        style={{ borderColor: msg.embed.color || '#5865F2' }}
                      >
                        {msg.embed.title && (
                          <div className="font-bold text-white text-sm mb-1.5 flex items-center gap-2">
                            {msg.embed.title}
                          </div>
                        )}
                        {msg.embed.description && (
                          <div className="text-[#dbdee1] text-xs leading-relaxed mb-3 whitespace-pre-line font-sans">
                            {msg.embed.description}
                          </div>
                        )}
                        {msg.embed.fields && msg.embed.fields.length > 0 && (
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2 pt-2 border-t border-[#35373c]">
                            {msg.embed.fields.map((field, fIdx) => (
                              <div
                                key={fIdx}
                                className={`bg-[#1e1f22]/70 p-2 rounded-md ${
                                  field.inline ? '' : 'sm:col-span-2'
                                }`}
                              >
                                <span className="text-[#949ba4] font-semibold text-[11px] block mb-0.5">
                                  {field.name}
                                </span>
                                <span className="text-white text-xs font-mono">{field.value}</span>
                              </div>
                            ))}
                          </div>
                        )}
                        {msg.embed.footer && (
                          <div className="text-[10px] text-[#949ba4] mt-2 pt-2 border-t border-[#35373c] flex items-center justify-between">
                            <span>{msg.embed.footer}</span>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Action Buttons */}
                    {msg.components && msg.components.length > 0 && (
                      <div className="flex flex-wrap gap-2 mt-3">
                        {msg.components.flatMap((comp, cIdx) =>
                          comp.buttons.map((btn) => {
                            const styleClasses =
                              btn.style === 'primary'
                                ? 'bg-[#5865F2] hover:bg-[#4752C4] text-white'
                                : btn.style === 'success'
                                ? 'bg-[#248046] hover:bg-[#1a6334] text-white'
                                : btn.style === 'danger'
                                ? 'bg-[#DA373C] hover:bg-[#a1282c] text-white'
                                : 'bg-[#4e5058] hover:bg-[#6d6f78] text-white';

                            return (
                              <button
                                key={`${cIdx}-${btn.id}`}
                                onClick={() => handleButtonClick(btn.id)}
                                className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all shadow-sm flex items-center gap-1.5 active:scale-95 ${styleClasses}`}
                              >
                                {btn.emoji && <span>{btn.emoji}</span>}
                                <span>{btn.label}</span>
                              </button>
                            );
                          })
                        )}
                      </div>
                    )}
                  </div>
                </div>
              ))}
              <div ref={chatBottomRef} />
            </div>

            {/* Input Bar */}
            <div className="p-4 bg-[#313338]">
              {aiChannels.has(activeChannel) && (
                <div className="mb-2 px-3 py-1 rounded-lg bg-indigo-950/40 border border-indigo-800/50 text-[11px] text-indigo-300 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                  <span>
                    وضع الذكاء الاصطناعي مفعل! أي رسالة تكتبها هنا سيرد عليها Gemini 3.8 Flash تلقائياً.
                  </span>
                </div>
              )}

              <form onSubmit={handleSendMessage} className="relative flex items-center">
                <input
                  type="text"
                  value={inputVal}
                  onChange={(e) => setInputVal(e.target.value)}
                  placeholder={
                    aiChannels.has(activeChannel)
                      ? `اكتب أي سؤال للذكاء الاصطناعي في #${activeChannel}...`
                      : `أرسل رسالة في #${activeChannel} (جرب: ip أو -i أو /help)...`
                  }
                  className="w-full bg-[#383a40] text-[#dbdee1] placeholder-[#80848e] text-sm rounded-lg px-4 py-3 pr-12 focus:outline-none focus:ring-1 focus:ring-indigo-500 font-sans"
                />

                <button
                  type="submit"
                  disabled={!inputVal.trim() || isAiLoading}
                  className="absolute left-2.5 p-2 text-[#b5bac1] hover:text-white disabled:opacity-40 disabled:hover:text-[#b5bac1] transition-colors"
                >
                  {isAiLoading ? (
                    <Sparkles className="w-4 h-4 animate-spin text-indigo-400" />
                  ) : (
                    <Send className="w-4 h-4" />
                  )}
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>

      {/* Ticket Modal Simulator */}
      {simModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-[#313338] border border-[#202225] rounded-xl max-w-md w-full p-6 text-white space-y-4 shadow-2xl font-sans text-start">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <span>🎫 فتح تذكرة: {simModal.deptName}</span>
            </h3>

            <form onSubmit={handleModalSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-[#b5bac1] mb-1.5">
                  عنوان أو موضوع المشكلة
                </label>
                <input
                  type="text"
                  value={modalTopic}
                  onChange={(e) => setModalTopic(e.target.value)}
                  placeholder="مثال: استفسار عن رتبة VIP في سيرفر Hitrex..."
                  className="w-full bg-[#1e1f22] border border-[#2b2d31] rounded-lg px-3.5 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#b5bac1] mb-1.5">
                  التفاصيل المسجلة
                </label>
                <textarea
                  value={modalDesc}
                  onChange={(e) => setModalDesc(e.target.value)}
                  placeholder="اشرح المشكلة بالتفصيل لمساعدتك بشكل أسرع..."
                  rows={3}
                  className="w-full bg-[#1e1f22] border border-[#2b2d31] rounded-lg px-3.5 py-2 text-sm text-white focus:outline-none focus:border-indigo-500 resize-none"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setSimModal(null)}
                  className="px-4 py-2 rounded-lg text-xs font-semibold text-[#dbdee1] hover:underline"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg text-xs font-bold bg-[#5865F2] hover:bg-[#4752C4] text-white transition-colors"
                >
                  إرسال وفتح التذكرة
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
