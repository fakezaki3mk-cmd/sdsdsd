import React from 'react';
import { ActiveTab, BotStatusResponse } from '../types';
import { Bot, Key } from 'lucide-react';

interface HeaderProps {
  activeTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
  botStatus: BotStatusResponse;
  onOpenConnectModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onSelectTab,
  botStatus,
  onOpenConnectModal,
}) => {
  const isOnline = botStatus.status === 'online';

  return (
    <header className="sticky top-0 z-40 w-full border-b border-stone-200 dark:border-stone-800 bg-white/95 dark:bg-stone-900/95 backdrop-blur-md transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Wordmark */}
        <button
          onClick={() => onSelectTab('simulator')}
          className="text-lg sm:text-xl font-bold tracking-tight text-stone-900 dark:text-stone-100 whitespace-nowrap shrink-0 hover:opacity-85 transition-opacity flex items-center gap-2.5 text-start"
        >
          <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center shrink-0 shadow-sm">
            <Bot className="w-4 h-4" />
          </div>
          <span>ديسكورد بوت برو</span>
          <span className="text-stone-400 dark:text-stone-500 font-normal text-xs hidden lg:inline">
            · Hitrex SMP Edition
          </span>
        </button>

        {/* Nav Links */}
        <nav className="hidden md:flex items-center gap-4 lg:gap-6 text-xs lg:text-sm font-medium text-stone-600 dark:text-stone-300 overflow-x-auto py-1">
          <button
            onClick={() => onSelectTab('simulator')}
            className={`whitespace-nowrap shrink-0 transition-colors py-1 ${
              activeTab === 'simulator'
                ? 'text-indigo-600 dark:text-indigo-400 font-semibold border-b-2 border-indigo-500'
                : 'hover:text-stone-900 dark:hover:text-white'
            }`}
          >
            المحاكي المباشر
          </button>
          <button
            onClick={() => onSelectTab('invites')}
            className={`whitespace-nowrap shrink-0 transition-colors py-1 ${
              activeTab === 'invites'
                ? 'text-indigo-600 dark:text-indigo-400 font-semibold border-b-2 border-indigo-500'
                : 'hover:text-stone-900 dark:hover:text-white'
            }`}
          >
            الدعوات (-i)
          </button>
          <button
            onClick={() => onSelectTab('auto-replies')}
            className={`whitespace-nowrap shrink-0 transition-colors py-1 ${
              activeTab === 'auto-replies'
                ? 'text-indigo-600 dark:text-indigo-400 font-semibold border-b-2 border-indigo-500'
                : 'hover:text-stone-900 dark:hover:text-white'
            }`}
          >
            الردود التلقائية
          </button>
          <button
            onClick={() => onSelectTab('tickets')}
            className={`whitespace-nowrap shrink-0 transition-colors py-1 ${
              activeTab === 'tickets'
                ? 'text-indigo-600 dark:text-indigo-400 font-semibold border-b-2 border-indigo-500'
                : 'hover:text-stone-900 dark:hover:text-white'
            }`}
          >
            التذاكر
          </button>
          <button
            onClick={() => onSelectTab('moderation')}
            className={`whitespace-nowrap shrink-0 transition-colors py-1 ${
              activeTab === 'moderation'
                ? 'text-indigo-600 dark:text-indigo-400 font-semibold border-b-2 border-indigo-500'
                : 'hover:text-stone-900 dark:hover:text-white'
            }`}
          >
            الإشراف
          </button>
          <button
            onClick={() => onSelectTab('ai')}
            className={`whitespace-nowrap shrink-0 transition-colors py-1 ${
              activeTab === 'ai'
                ? 'text-indigo-600 dark:text-indigo-400 font-semibold border-b-2 border-indigo-500'
                : 'hover:text-stone-900 dark:hover:text-white'
            }`}
          >
            الذكاء الاصطناعي
          </button>
          <button
            onClick={() => onSelectTab('commands')}
            className={`whitespace-nowrap shrink-0 transition-colors py-1 ${
              activeTab === 'commands'
                ? 'text-indigo-600 dark:text-indigo-400 font-semibold border-b-2 border-indigo-500'
                : 'hover:text-stone-900 dark:hover:text-white'
            }`}
          >
            الأوامر
          </button>
        </nav>

        {/* Action Button & Status */}
        <div className="flex items-center gap-3 shrink-0">
          <div
            onClick={onOpenConnectModal}
            className="cursor-pointer hidden sm:flex items-center gap-2 text-xs font-medium text-stone-600 dark:text-stone-300 hover:text-stone-900 dark:hover:text-white transition-colors"
          >
            <span
              className={`w-2 h-2 rounded-full ${
                isOnline ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'
              }`}
            />
            <span className="font-mono tabular-nums text-xs">
              {isOnline ? `${botStatus.tag || 'متصل'}` : 'وضع المحاكاة'}
            </span>
          </div>

          <button
            onClick={onOpenConnectModal}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 rounded-xl shadow-sm transition-colors whitespace-nowrap shrink-0"
          >
            <Key className="w-3.5 h-3.5" />
            <span>{isOnline ? 'إعدادات الاتصال' : 'ربط التوكين'}</span>
          </button>
        </div>
      </div>
    </header>
  );
};
