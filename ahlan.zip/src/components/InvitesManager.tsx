import React, { useState } from 'react';
import { InviteRecord } from '../types';
import { Users, UserPlus, Award, ShieldCheck, UserMinus, AlertCircle, Search, ExternalLink } from 'lucide-react';

const SAMPLE_INVITERS: InviteRecord[] = [
  {
    userId: '101',
    userTag: 'خالد_المؤسس',
    total: 38,
    regular: 32,
    left: 4,
    fake: 2,
    inviteCode: 'hitrex-smp',
  },
  {
    userId: '102',
    userTag: 'عبد_الله_VIP',
    total: 24,
    regular: 20,
    left: 3,
    fake: 1,
    inviteCode: 'vip-abdullah',
  },
  {
    userId: '103',
    userTag: 'سارة_gamer',
    total: 19,
    regular: 17,
    left: 2,
    fake: 0,
    inviteCode: 'sara-pro',
  },
  {
    userId: '104',
    userTag: 'أحمد_كرافت',
    total: 12,
    regular: 9,
    left: 3,
    fake: 0,
    inviteCode: 'ahmed-craft',
  },
  {
    userId: '105',
    userTag: 'فيصل_99',
    total: 8,
    regular: 7,
    left: 1,
    fake: 0,
    inviteCode: 'faisal-invite',
  },
];

export const InvitesManager: React.FC = () => {
  const [inviters] = useState<InviteRecord[]>(SAMPLE_INVITERS);
  const [searchQuery, setSearchQuery] = useState('');
  const [previewUser, setPreviewUser] = useState<InviteRecord>(SAMPLE_INVITERS[0]);

  const filtered = inviters.filter((inv) =>
    inv.userTag.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-8 animate-fadeIn text-start">
      {/* Header Banner */}
      <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-6 shadow-sm">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 flex items-center justify-center shrink-0">
              <UserPlus className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-stone-900 dark:text-white">نظام تتبع الدعوات (Invite Tracker)</h2>
              <p className="text-sm text-stone-500 dark:text-stone-400 mt-1">
                تتبع دعوات الأعضاء بدقة: الدعوات الحقيقية، الأعضاء المغادرين، والحسابات الوهمية عبر كتابة <code className="bg-stone-100 dark:bg-stone-800 px-1.5 py-0.5 rounded text-purple-600 font-mono font-bold">-i</code> أو <code className="bg-stone-100 dark:bg-stone-800 px-1.5 py-0.5 rounded text-purple-600 font-mono font-bold">i</code>
              </p>
            </div>
          </div>
          <div className="px-3.5 py-1.5 rounded-xl bg-purple-50 dark:bg-purple-950/40 text-purple-700 dark:text-purple-300 text-xs font-bold border border-purple-200 dark:border-purple-800 flex items-center gap-2">
            <span>الأمر المباشر:</span>
            <span className="font-mono bg-purple-200 dark:bg-purple-900/60 px-2 py-0.5 rounded">-i</span>
            <span>أو</span>
            <span className="font-mono bg-purple-200 dark:bg-purple-900/60 px-2 py-0.5 rounded">i</span>
          </div>
        </div>
      </div>

      {/* Grid: Preview Card & Leaderboard */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Discord Embed Preview */}
        <div className="lg:col-span-1 space-y-4">
          <h3 className="text-base font-bold text-stone-900 dark:text-white flex items-center gap-2">
            <Award className="w-4 h-4 text-purple-600" />
            معاينة بطاقة الدعوات في ديسكورد
          </h3>

          <div className="bg-[#2b2d31] rounded-2xl p-5 border border-stone-700/60 text-white shadow-lg space-y-4 font-sans">
            <div className="border-r-4 border-indigo-500 pr-3 space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-indigo-600 flex items-center justify-center font-bold text-sm">
                  {previewUser.userTag.slice(0, 2)}
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">📨 إحصائيات دعوات العضو</h4>
                  <p className="text-xs text-stone-300">@{previewUser.userTag}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs pt-2">
                <div className="bg-[#1e1f22] p-2.5 rounded-lg border border-stone-800">
                  <span className="text-stone-400 block mb-1">✨ إجمالي الدعوات:</span>
                  <span className="text-lg font-bold text-indigo-400">{previewUser.total}</span>
                </div>
                <div className="bg-[#1e1f22] p-2.5 rounded-lg border border-stone-800">
                  <span className="text-stone-400 block mb-1">✅ دعوات حقيقية:</span>
                  <span className="text-lg font-bold text-emerald-400">{previewUser.regular}</span>
                </div>
                <div className="bg-[#1e1f22] p-2.5 rounded-lg border border-stone-800">
                  <span className="text-stone-400 block mb-1">🚪 أعضاء غادروا:</span>
                  <span className="text-lg font-bold text-rose-400">{previewUser.left}</span>
                </div>
                <div className="bg-[#1e1f22] p-2.5 rounded-lg border border-stone-800">
                  <span className="text-stone-400 block mb-1">⚠️ حسابات وهمية:</span>
                  <span className="text-lg font-bold text-amber-400">{previewUser.fake}</span>
                </div>
              </div>

              <div className="bg-[#1e1f22] p-2.5 rounded-lg border border-stone-800 text-xs">
                <span className="text-stone-400 block mb-0.5">🔗 كود الدعوة المعتمد:</span>
                <span className="text-indigo-300 font-mono">discord.gg/{previewUser.inviteCode || 'hitrex'}</span>
              </div>

              <div className="text-[11px] text-stone-400 border-t border-stone-700/50 pt-2 flex items-center justify-between">
                <span>نظام التتبع التلقائي</span>
                <span>اليوم في 12:00 م</span>
              </div>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-purple-50 dark:bg-purple-950/30 border border-purple-200 dark:border-purple-800/60 text-xs text-purple-900 dark:text-purple-300 space-y-1.5">
            <div className="font-bold flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-purple-600" />
              كيف يعمل الكاش الذكي للدعوات؟
            </div>
            <p className="leading-relaxed">
              يقوم البوت بتخزين جميع أكواد الدعوة في الذاكرة ومراقبة عدد الاستخدامات فور دخول أي عضو، مع احتساب الحسابات التي يقل عمرها عن 3 أيام كـ "حسابات وهمية" تلقائياً.
            </p>
          </div>
        </div>

        {/* Leaderboard */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <h3 className="text-base font-bold text-stone-900 dark:text-white flex items-center gap-2">
              <Users className="w-4 h-4 text-purple-600" />
              قائمة متصدري الدعوات (Leaderboard)
            </h3>

            <div className="relative w-full sm:w-64">
              <Search className="w-4 h-4 text-stone-400 absolute right-3 top-2.5" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="بحث عن عضو..."
                className="w-full pr-9 pl-3 py-1.5 text-xs rounded-xl border border-stone-200 dark:border-stone-800 bg-white dark:bg-stone-900 text-stone-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>
          </div>

          <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl overflow-hidden shadow-sm">
            <table className="w-full text-start text-xs">
              <thead className="bg-stone-50 dark:bg-stone-800/60 text-stone-600 dark:text-stone-400 font-semibold border-b border-stone-200 dark:border-stone-800">
                <tr>
                  <th className="py-3 px-4 text-start">#</th>
                  <th className="py-3 px-4 text-start">العضو</th>
                  <th className="py-3 px-3 text-center">الإجمالي</th>
                  <th className="py-3 px-3 text-center">حقيقية</th>
                  <th className="py-3 px-3 text-center">غادروا</th>
                  <th className="py-3 px-3 text-center">وهمية</th>
                  <th className="py-3 px-4 text-end">إجراء</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100 dark:divide-stone-800">
                {filtered.map((user, idx) => (
                  <tr
                    key={user.userId}
                    className="hover:bg-stone-50 dark:hover:bg-stone-800/40 transition-colors"
                  >
                    <td className="py-3.5 px-4 font-bold text-stone-400">
                      {idx === 0 ? '🥇' : idx === 1 ? '🥈' : idx === 2 ? '🥉' : idx + 1}
                    </td>
                    <td className="py-3.5 px-4 font-semibold text-stone-900 dark:text-white">
                      {user.userTag}
                    </td>
                    <td className="py-3.5 px-3 text-center font-bold text-indigo-600 dark:text-indigo-400">
                      {user.total}
                    </td>
                    <td className="py-3.5 px-3 text-center font-semibold text-emerald-600 dark:text-emerald-400">
                      {user.regular}
                    </td>
                    <td className="py-3.5 px-3 text-center text-rose-500">
                      {user.left}
                    </td>
                    <td className="py-3.5 px-3 text-center text-amber-500">
                      {user.fake}
                    </td>
                    <td className="py-3.5 px-4 text-end">
                      <button
                        onClick={() => setPreviewUser(user)}
                        className="px-2.5 py-1 rounded-lg bg-stone-100 dark:bg-stone-800 hover:bg-purple-100 dark:hover:bg-purple-950/60 text-stone-700 dark:text-stone-300 hover:text-purple-600 transition-colors"
                      >
                        معاينة البطاقة
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
