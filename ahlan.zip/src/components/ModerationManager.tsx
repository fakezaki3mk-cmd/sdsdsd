import React, { useState } from 'react';
import { ModerationLog, AutoModConfig } from '../types';
import {
  ShieldAlert,
  ShieldCheck,
  UserX,
  AlertTriangle,
  Trash2,
  Lock,
  Plus,
  X,
  Sliders,
  CheckCircle,
} from 'lucide-react';

interface ModerationManagerProps {
  logs: ModerationLog[];
  onAddLog: (log: ModerationLog) => void;
}

export const ModerationManager: React.FC<ModerationManagerProps> = ({ logs, onAddLog }) => {
  // Auto-mod configuration state
  const [autoMod, setAutoMod] = useState<AutoModConfig>({
    antiSpam: true,
    antiLinks: true,
    aiToxicityFilter: true,
    badWords: ['سبام', 'نصاب', 'discord.gg/scam'],
  });

  const [newBadWord, setNewBadWord] = useState('');

  // Quick Action State
  const [targetUser, setTargetUser] = useState('');
  const [actionType, setActionType] = useState<ModerationLog['action']>('warn');
  const [actionReason, setActionReason] = useState('');
  const [feedbackMsg, setFeedbackMsg] = useState<string | null>(null);

  const handleAddBadWord = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBadWord.trim()) return;
    setAutoMod((prev) => ({
      ...prev,
      badWords: [...prev.badWords, newBadWord.trim()],
    }));
    setNewBadWord('');
  };

  const handleRemoveBadWord = (word: string) => {
    setAutoMod((prev) => ({
      ...prev,
      badWords: prev.badWords.filter((w) => w !== word),
    }));
  };

  const handleExecuteAction = (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetUser.trim()) return;

    const timeNow = new Date().toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' });
    const logItem: ModerationLog = {
      id: `mod-${Date.now()}`,
      action: actionType,
      targetUser: targetUser.startsWith('@') ? targetUser : `@${targetUser}`,
      moderator: 'المشرف (لوحة التحكم)',
      reason: actionReason.trim() || 'إجراء إداري رسمي',
      timestamp: timeNow,
    };

    onAddLog(logItem);
    setFeedbackMsg(`تم تنفيذ إجراء [${actionType.toUpperCase()}] على العضو بنجاح!`);
    setTargetUser('');
    setActionReason('');
    setTimeout(() => setFeedbackMsg(null), 3000);
  };

  return (
    <div className="space-y-8">
      {/* Top Split: Auto-Mod Rules & Quick Action */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Auto-Mod Security Rules - 6 cols */}
        <div className="lg:col-span-6 bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl p-6 transition-colors space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-stone-900 dark:text-stone-100 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-indigo-500" />
                <span>نظام الحماية الآلي (Auto-Moderation)</span>
              </h3>
              <p className="text-xs text-stone-500 dark:text-stone-400 mt-1">
                حماية فورية على مدار 24 ساعة تمنع التخريب والروابط العشوائية وتراقب الشات.
              </p>
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 rounded-lg border border-stone-200/80 dark:border-stone-800">
              <div>
                <span className="text-xs font-bold text-stone-900 dark:text-stone-100 block">
                  مكافحة السبام السريع (Anti-Spam)
                </span>
                <span className="text-[11px] text-stone-500 dark:text-stone-400">
                  كتم العضو تلقائياً عند إرسال أكثر من 5 رسائل في 3 ثوانٍ
                </span>
              </div>
              <input
                type="checkbox"
                checked={autoMod.antiSpam}
                onChange={(e) => setAutoMod((p) => ({ ...p, antiSpam: e.target.checked }))}
                className="w-4 h-4 accent-indigo-600 rounded"
              />
            </div>

            <div className="flex items-center justify-between p-3 rounded-lg border border-stone-200/80 dark:border-stone-800">
              <div>
                <span className="text-xs font-bold text-stone-900 dark:text-stone-100 block">
                  فلترة روابط السيرفرات (Anti-Invite Links)
                </span>
                <span className="text-[11px] text-stone-500 dark:text-stone-400">
                  حذف أي رابط دعوة لسيرفر آخر (discord.gg) وتوجيه إنذار فوري
                </span>
              </div>
              <input
                type="checkbox"
                checked={autoMod.antiLinks}
                onChange={(e) => setAutoMod((p) => ({ ...p, antiLinks: e.target.checked }))}
                className="w-4 h-4 accent-indigo-600 rounded"
              />
            </div>

            <div className="flex items-center justify-between p-3 rounded-lg border border-stone-200/80 dark:border-stone-800">
              <div>
                <span className="text-xs font-bold text-stone-900 dark:text-stone-100 block">
                  الفاحص الذكي للألفاظ (AI Toxicity Scanner)
                </span>
                <span className="text-[11px] text-stone-500 dark:text-stone-400">
                  استخدام Gemini AI لاكتشاف رسائل الاحتيال والسب والكراهية بدقة
                </span>
              </div>
              <input
                type="checkbox"
                checked={autoMod.aiToxicityFilter}
                onChange={(e) => setAutoMod((p) => ({ ...p, aiToxicityFilter: e.target.checked }))}
                className="w-4 h-4 accent-indigo-600 rounded"
              />
            </div>

            {/* Blocked Words Editor */}
            <div className="pt-3 border-t border-stone-100 dark:border-stone-800">
              <label className="text-xs font-medium text-stone-700 dark:text-stone-300 block mb-2">
                قائمة الكلمات المحظورة (Word Blacklist):
              </label>

              <div className="flex flex-wrap gap-1.5 mb-3">
                {autoMod.badWords.map((word) => (
                  <span
                    key={word}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-stone-100 dark:bg-stone-800 text-xs text-stone-700 dark:text-stone-300"
                  >
                    <span>{word}</span>
                    <button
                      onClick={() => handleRemoveBadWord(word)}
                      className="hover:text-rose-500 text-stone-400"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                ))}
              </div>

              <form onSubmit={handleAddBadWord} className="flex gap-2">
                <input
                  type="text"
                  value={newBadWord}
                  onChange={(e) => setNewBadWord(e.target.value)}
                  placeholder="أضف كلمة جديدة..."
                  className="flex-1 px-3 py-1.5 text-xs bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-lg text-stone-900 dark:text-stone-100 placeholder-stone-400 focus:outline-none focus:border-indigo-500"
                />
                <button
                  type="submit"
                  disabled={!newBadWord.trim()}
                  className="px-3 py-1.5 text-xs font-medium bg-stone-900 hover:bg-stone-800 dark:bg-indigo-600 dark:hover:bg-indigo-700 text-white rounded-lg transition-colors flex items-center gap-1 disabled:opacity-40"
                >
                  <Plus className="w-3 h-3" />
                  <span>إضافة</span>
                </button>
              </form>
            </div>
          </div>
        </div>

        {/* Quick Member Action Box - 6 cols */}
        <div className="lg:col-span-6 bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl p-6 transition-colors space-y-5">
          <div>
            <h3 className="text-base font-bold text-stone-900 dark:text-stone-100 flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-indigo-500" />
              <span>إجراء إداري سريع على عضو</span>
            </h3>
            <p className="text-xs text-stone-500 dark:text-stone-400 mt-1">
              تنفيذ قرارات الحظر، الطرد، العزل، أو الإنذارات مباشرة وتسجيلها في السجل الرسمي.
            </p>
          </div>

          {feedbackMsg && (
            <div className="p-3 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900 text-xs text-emerald-700 dark:text-emerald-400 flex items-center gap-2">
              <CheckCircle className="w-4 h-4 shrink-0" />
              <span>{feedbackMsg}</span>
            </div>
          )}

          <form onSubmit={handleExecuteAction} className="space-y-4">
            <div>
              <label className="text-xs font-medium text-stone-700 dark:text-stone-300 block mb-1">
                اسم العضو أو المعرف (@User / ID)
              </label>
              <input
                type="text"
                value={targetUser}
                onChange={(e) => setTargetUser(e.target.value)}
                placeholder="@اسم_العضو أو معرفه الرقمي"
                className="w-full px-3.5 py-2 text-xs bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-lg text-stone-900 dark:text-stone-100 placeholder-stone-400 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-medium text-stone-700 dark:text-stone-300 block mb-1">
                  نوع الإجراء
                </label>
                <select
                  value={actionType}
                  onChange={(e) => setActionType(e.target.value as ModerationLog['action'])}
                  className="w-full px-3 py-2 text-xs bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-lg text-stone-700 dark:text-stone-300 focus:outline-none focus:border-indigo-500"
                >
                  <option value="warn">⚠️ تحذير رسمي (Warn)</option>
                  <option value="timeout">⏳ عزل مؤقت (Timeout/Mute)</option>
                  <option value="kick">🚪 طرد من السيرفر (Kick)</option>
                  <option value="ban">🔨 حظر نهائي (Ban)</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-medium text-stone-700 dark:text-stone-300 block mb-1">
                  السبب المسجل
                </label>
                <input
                  type="text"
                  value={actionReason}
                  onChange={(e) => setActionReason(e.target.value)}
                  placeholder="مثال: سبام متكرر / مخالفة الشروط"
                  className="w-full px-3 py-2 text-xs bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-lg text-stone-900 dark:text-stone-100 placeholder-stone-400 focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={!targetUser.trim()}
              className="w-full py-2.5 text-xs font-semibold text-white bg-stone-900 hover:bg-stone-800 dark:bg-indigo-600 dark:hover:bg-indigo-700 disabled:opacity-50 rounded-lg transition-colors flex items-center justify-center gap-1.5"
            >
              <ShieldAlert className="w-3.5 h-3.5" />
              <span>تنفيذ الإجراء وتسجيله</span>
            </button>
          </form>
        </div>
      </div>

      {/* Audit Log Table - High density, clean alignment, Tabular numerals */}
      <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl p-6 transition-colors">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-base font-bold text-stone-900 dark:text-stone-100">
              سجل الرقابة والإشراف (Moderation Audit Logs)
            </h3>
            <p className="text-xs text-stone-500 dark:text-stone-400 mt-0.5">
              كافة الإجراءات المسجلة من قِبل المشرفين أو أنظمة الحماية الآلية.
            </p>
          </div>
          <span className="text-xs text-stone-400 font-mono tabular-nums">
            إجمالي السجلات: {logs.length}
          </span>
        </div>

        {logs.length === 0 ? (
          <div className="py-10 text-center text-xs text-stone-400 border border-dashed border-stone-200 dark:border-stone-800 rounded-lg">
            لا توجد مخالفات مسجلة حتى الآن. سيرفرك نظيف وآمن!
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-start">
              <thead>
                <tr className="border-b border-stone-200 dark:border-stone-800 text-stone-400">
                  <th className="py-2.5 px-3 font-semibold text-start">الإجراء</th>
                  <th className="py-2.5 px-3 font-semibold text-start">العضو المستهدف</th>
                  <th className="py-2.5 px-3 font-semibold text-start">المشرف المسؤول</th>
                  <th className="py-2.5 px-3 font-semibold text-start">السبب</th>
                  <th className="py-2.5 px-3 font-semibold text-end">التوقيت</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100 dark:divide-stone-800/80">
                {logs.map((log) => (
                  <tr key={log.id} className="hover:bg-stone-50/50 dark:hover:bg-stone-800/30">
                    <td className="py-3 px-3">
                      <span
                        className={`font-semibold ${
                          log.action === 'ban'
                            ? 'text-rose-600 dark:text-rose-400'
                            : log.action === 'kick'
                            ? 'text-orange-600 dark:text-orange-400'
                            : log.action === 'warn'
                            ? 'text-amber-600 dark:text-amber-400'
                            : 'text-stone-600 dark:text-stone-300'
                        }`}
                      >
                        {log.action.toUpperCase()}
                      </span>
                    </td>
                    <td className="py-3 px-3 font-medium text-stone-800 dark:text-stone-200">
                      {log.targetUser}
                    </td>
                    <td className="py-3 px-3 text-stone-500 dark:text-stone-400">
                      {log.moderator}
                    </td>
                    <td className="py-3 px-3 text-stone-600 dark:text-stone-300">
                      {log.reason}
                    </td>
                    <td className="py-3 px-3 text-end font-mono tabular-nums text-stone-400">
                      {log.timestamp}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
