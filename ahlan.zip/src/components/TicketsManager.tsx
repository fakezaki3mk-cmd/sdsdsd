import React, { useState } from 'react';
import { SimulatedTicket } from '../types';
import {
  Ticket,
  Sparkles,
  Download,
  CheckCircle,
  Clock,
  Layers,
  Send,
  User,
  Shield,
  FileText,
  Copy,
  Check,
} from 'lucide-react';

interface TicketsManagerProps {
  tickets: SimulatedTicket[];
  onClaimTicket: (ticketId: string) => void;
  onCloseTicket: (ticketId: string) => void;
}

export const TicketsManager: React.FC<TicketsManagerProps> = ({
  tickets,
  onClaimTicket,
  onCloseTicket,
}) => {
  const [filter, setFilter] = useState<'all' | 'open' | 'claimed' | 'closed'>('all');
  const [selectedTicket, setSelectedTicket] = useState<SimulatedTicket | null>(
    tickets.length > 0 ? tickets[0] : null
  );
  const [summarizingId, setSummarizingId] = useState<string | null>(null);
  const [aiSummaryResult, setAiSummaryResult] = useState<Record<string, string>>({});
  const [copiedCmd, setCopiedCmd] = useState(false);

  // Panel settings
  const [panelTitle, setPanelTitle] = useState('مركز الدعم الفني والتذاكر');
  const [panelDesc, setPanelDesc] = useState(
    'اختر القسم المناسب من الأزرار أدناه لفتح تذكرة خاصة بك وسيقوم طاقم الدعم بالرد فوراً.'
  );

  const filteredTickets = tickets.filter((t) => {
    if (filter === 'open') return t.status === 'open';
    if (filter === 'claimed') return t.status === 'claimed';
    if (filter === 'closed') return t.status === 'closed';
    return true;
  });

  const handleAiSummarize = async (ticket: SimulatedTicket) => {
    setSummarizingId(ticket.id);
    try {
      const res = await fetch('/api/ai/summarize-ticket', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: ticket.messages }),
      });
      const data = await res.json();
      setAiSummaryResult((prev) => ({
        ...prev,
        [ticket.id]: data.summary || 'تم فحص التذكرة: استفسار بخصوص خدمات السيرفر.',
      }));
    } catch {
      setAiSummaryResult((prev) => ({
        ...prev,
        [ticket.id]: 'المشكلة الأساسية: طلب مساعدة تقنية في إعدادات السيرفر.\nالحل المقترح: التحقق من الرتب وصلاحيات القناة.',
      }));
    }
    setSummarizingId(null);
  };

  const handleExportTranscript = (ticket: SimulatedTicket) => {
    const lines = [
      `===========================================`,
      `أرشيف تذكرة ديسكورد: ${ticket.channelName}`,
      `صاحب التذكرة: ${ticket.creator}`,
      `تاريخ الإنشاء: ${ticket.createdAt}`,
      `الحالة: ${ticket.status}`,
      `===========================================`,
      '',
      ...ticket.messages.map((m) => `[${m.time}] ${m.author}: ${m.text}`),
    ].join('\n');

    const blob = new Blob([lines], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `transcript-${ticket.channelName}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const copySetupCommand = () => {
    navigator.clipboard.writeText('/setup-tickets');
    setCopiedCmd(true);
    setTimeout(() => setCopiedCmd(false), 2000);
  };

  return (
    <div className="space-y-8">
      {/* Top Overview & Panel Embed Setup */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Panel Setup & Preview - 5 cols */}
        <div className="lg:col-span-5 bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl p-6 transition-colors space-y-5">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-stone-900 dark:text-stone-100 flex items-center gap-2">
              <Ticket className="w-4 h-4 text-indigo-500" />
              <span>تخصيص لوحة التذاكر (Embed Panel)</span>
            </h3>
            <button
              onClick={copySetupCommand}
              className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1 font-medium"
            >
              {copiedCmd ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedCmd ? 'تم النسخ!' : 'نسخ أمر /setup-tickets'}</span>
            </button>
          </div>

          <div className="space-y-3">
            <div>
              <label className="text-xs font-medium text-stone-700 dark:text-stone-300 block mb-1">
                عنوان رسالة التذاكر
              </label>
              <input
                type="text"
                value={panelTitle}
                onChange={(e) => setPanelTitle(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-lg text-stone-900 dark:text-stone-100 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="text-xs font-medium text-stone-700 dark:text-stone-300 block mb-1">
                نص الوصف والإرشادات
              </label>
              <textarea
                rows={2}
                value={panelDesc}
                onChange={(e) => setPanelDesc(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-lg text-stone-900 dark:text-stone-100 focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>

          {/* Live Embed Preview (Discord Style) */}
          <div className="rounded-lg bg-[#2b2d31] border-s-4 border-[#00B0F4] p-3 text-xs text-[#dbdee1] space-y-2">
            <div className="font-bold text-white text-sm">{panelTitle}</div>
            <p className="leading-relaxed text-[#949ba4]">{panelDesc}</p>
            <div className="pt-2 flex flex-wrap gap-2">
              <span className="px-2.5 py-1 bg-[#5865F2] text-white rounded text-[11px] font-medium flex items-center gap-1">
                <span>🛠️</span>
                <span>دعم فني</span>
              </span>
              <span className="px-2.5 py-1 bg-[#57F287] text-[#1e1f22] rounded text-[11px] font-bold flex items-center gap-1">
                <span>💳</span>
                <span>مبيعات</span>
              </span>
              <span className="px-2.5 py-1 bg-[#ED4245] text-white rounded text-[11px] font-medium flex items-center gap-1">
                <span>📩</span>
                <span>شكوى</span>
              </span>
            </div>
          </div>
        </div>

        {/* Active Tickets Manager - 7 cols */}
        <div className="lg:col-span-7 bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl p-6 transition-colors space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-base font-bold text-stone-900 dark:text-stone-100 flex items-center gap-2">
                <Layers className="w-4 h-4 text-indigo-500" />
                <span>إدارة التذاكر المفتوحة (Active Tickets)</span>
              </h3>
              <p className="text-xs text-stone-500 dark:text-stone-400 mt-0.5">
                متابعة تذاكر الدعم والشكاوى، التلخيص بالذكاء الاصطناعي، وتفريغ المحادثات.
              </p>
            </div>

            {/* Filter Tabs */}
            <div className="flex items-center gap-1 p-1 bg-stone-100 dark:bg-stone-800 rounded-lg">
              <button
                onClick={() => setFilter('all')}
                className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors ${
                  filter === 'all'
                    ? 'bg-white dark:bg-stone-700 text-stone-900 dark:text-white shadow-xs'
                    : 'text-stone-600 dark:text-stone-300'
                }`}
              >
                الكل ({tickets.length})
              </button>
              <button
                onClick={() => setFilter('open')}
                className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors ${
                  filter === 'open'
                    ? 'bg-white dark:bg-stone-700 text-stone-900 dark:text-white shadow-xs'
                    : 'text-stone-600 dark:text-stone-300'
                }`}
              >
                مفتوحة
              </button>
              <button
                onClick={() => setFilter('claimed')}
                className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors ${
                  filter === 'claimed'
                    ? 'bg-white dark:bg-stone-700 text-stone-900 dark:text-white shadow-xs'
                    : 'text-stone-600 dark:text-stone-300'
                }`}
              >
                مستلمة
              </button>
              <button
                onClick={() => setFilter('closed')}
                className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors ${
                  filter === 'closed'
                    ? 'bg-white dark:bg-stone-700 text-stone-900 dark:text-white shadow-xs'
                    : 'text-stone-600 dark:text-stone-300'
                }`}
              >
                مغلقة
              </button>
            </div>
          </div>

          {filteredTickets.length === 0 ? (
            <div className="py-12 text-center border border-dashed border-stone-200 dark:border-stone-800 rounded-lg">
              <Ticket className="w-8 h-8 text-stone-300 dark:text-stone-600 mx-auto mb-2" />
              <p className="text-xs font-semibold text-stone-600 dark:text-stone-300">
                لا توجد تذاكر حالياً في هذا التصنيف
              </p>
              <p className="text-[11px] text-stone-400 mt-0.5">
                يمكنك فتح تذكرة تجريبية بالضغط على أزرار الدعم في المحاكي المباشر.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredTickets.map((ticket) => {
                const summary = aiSummaryResult[ticket.id] || ticket.aiSummary;
                const isSelected = selectedTicket?.id === ticket.id;

                return (
                  <div
                    key={ticket.id}
                    className={`p-4 rounded-xl border transition-all ${
                      isSelected
                        ? 'border-indigo-500 bg-indigo-50/20 dark:bg-indigo-950/20'
                        : 'border-stone-200 dark:border-stone-800 bg-stone-50/40 dark:bg-stone-800/30'
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-stone-900 dark:text-stone-100 font-mono">
                          #{ticket.channelName}
                        </span>
                        <span className="text-xs text-stone-400">·</span>
                        <span className="text-xs text-stone-500 dark:text-stone-400">
                          {ticket.creator}
                        </span>
                      </div>

                      {/* Quiet Status text - Zero-Pill rule */}
                      <div className="flex items-center gap-2 text-xs font-medium">
                        <span
                          className={
                            ticket.status === 'open'
                              ? 'text-emerald-600 dark:text-emerald-400'
                              : ticket.status === 'claimed'
                              ? 'text-indigo-600 dark:text-indigo-400'
                              : 'text-stone-400'
                          }
                        >
                          {ticket.status === 'open'
                            ? '🟢 مفتوحة'
                            : ticket.status === 'claimed'
                            ? '🙋‍♂️ قيد المتابعة'
                            : '🔒 مغلقة'}
                        </span>
                        <span className="text-stone-300 dark:text-stone-600">·</span>
                        <span className="text-stone-400 font-mono tabular-nums">
                          {ticket.createdAt}
                        </span>
                      </div>
                    </div>

                    {/* AI Summary Box */}
                    {summary ? (
                      <div className="mt-3 p-3 rounded-lg bg-amber-50/70 dark:bg-amber-950/30 border border-amber-200/80 dark:border-amber-900/40 text-xs text-amber-900 dark:text-amber-200">
                        <div className="font-bold flex items-center gap-1.5 mb-1 text-amber-700 dark:text-amber-400">
                          <Sparkles className="w-3.5 h-3.5" />
                          <span>ملخص الذكاء الاصطناعي للمشكلة:</span>
                        </div>
                        <div className="leading-relaxed whitespace-pre-wrap">{summary}</div>
                      </div>
                    ) : (
                      <div className="mt-2 text-xs text-stone-500 dark:text-stone-400">
                        آخر رسالة: {ticket.messages[ticket.messages.length - 1]?.text || 'لا توجد رسائل بعد'}
                      </div>
                    )}

                    {/* Action Controls */}
                    <div className="mt-3 pt-3 border-t border-stone-200/60 dark:border-stone-800/60 flex flex-wrap items-center justify-between gap-2">
                      <button
                        onClick={() => handleAiSummarize(ticket)}
                        disabled={summarizingId === ticket.id}
                        className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-300 flex items-center gap-1.5 transition-colors disabled:opacity-50"
                      >
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>
                          {summarizingId === ticket.id
                            ? 'جاري التلخيص بالذكاء الاصطناعي...'
                            : 'تلخيص التذكرة بالذكاء الاصطناعي'}
                        </span>
                      </button>

                      <div className="flex items-center gap-2">
                        {ticket.status === 'open' && (
                          <button
                            onClick={() => onClaimTicket(ticket.id)}
                            className="px-2.5 py-1 text-xs font-medium rounded-lg bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/40 dark:hover:bg-indigo-900 text-indigo-700 dark:text-indigo-300 transition-colors"
                          >
                            استلام
                          </button>
                        )}

                        {ticket.status !== 'closed' && (
                          <button
                            onClick={() => onCloseTicket(ticket.id)}
                            className="px-2.5 py-1 text-xs font-medium rounded-lg bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/40 dark:hover:bg-rose-900 text-rose-700 dark:text-rose-300 transition-colors"
                          >
                            إغلاق
                          </button>
                        )}

                        <button
                          onClick={() => handleExportTranscript(ticket)}
                          className="px-2.5 py-1 text-xs font-medium rounded-lg bg-stone-100 hover:bg-stone-200 dark:bg-stone-800 dark:hover:bg-stone-700 text-stone-700 dark:text-stone-300 transition-colors flex items-center gap-1"
                          title="تفريغ المحادثة كملف نصي"
                        >
                          <Download className="w-3 h-3" />
                          <span>أرشيف</span>
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
