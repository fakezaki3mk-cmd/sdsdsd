import { BotCommand } from '../types';

export const BOT_COMMANDS: BotCommand[] = [
  // Minecraft & Server Info
  {
    name: 'ip',
    syntax: 'ip أو /ip أو -ip',
    category: 'general',
    descriptionAr: 'عرض معلومات سيرفر Hitrex SMP ماين كرافت (الآي بي، المنافذ للجافا والجوال، الإصدار، وحالة الاتصال)',
    permissionsAr: 'متاح لجميع اللاعبين (Everyone)',
    isAdminOnly: false,
    example: 'ip',
  },

  // Invites Tracking System
  {
    name: 'invites',
    syntax: '-i أو i أو /invites [@user]',
    category: 'invites',
    descriptionAr: 'عرض إحصائيات دعوات العضو المفصلة: إجمالي الدعوات، الدعوات الحقيقية، الأعضاء المغادرين، والحسابات الوهمية',
    permissionsAr: 'متاح لجميع اللاعبين (Everyone)',
    isAdminOnly: false,
    example: '-i',
  },

  // AI Interactive Channel & Assistant
  {
    name: 'ai setup',
    syntax: '/ai setup أو -ai setup',
    category: 'ai',
    descriptionAr: 'تخصيص القناة الحالية كـ "قناة ذكاء اصطناعي تفاعلية": أي رسالة يكتبها أي عضو هنا يرد عليها Gemini 3.8 Flash تلقائياً دون منشن أو أوامر',
    permissionsAr: 'مدير السيرفر فقط (Administrator 👑)',
    isAdminOnly: true,
    example: '/ai setup',
  },
  {
    name: 'ai disable',
    syntax: '/ai disable',
    category: 'ai',
    descriptionAr: 'إلغاء وضع الرد التلقائي للذكاء الاصطناعي في القناة الحالية',
    permissionsAr: 'مدير السيرفر فقط (Administrator 👑)',
    isAdminOnly: true,
    example: '/ai disable',
  },
  {
    name: 'ask',
    syntax: '/ask [prompt]',
    category: 'ai',
    descriptionAr: 'استشارة فورية للذكاء الاصطناعي (Gemini 3.8 Flash) في أي سؤال تقني، برمجي، أو مساعدة',
    permissionsAr: 'متاح لجميع الأعضاء (Everyone)',
    isAdminOnly: false,
    example: '/ask كيف أبني مزرعة أوتوماتيكية في ماين كرافت؟',
  },
  {
    name: 'summarize-ticket',
    syntax: '/summarize-ticket',
    category: 'ai',
    descriptionAr: 'تلخيص المحادثة واستخراج المشكلة والحل المقترح في التذكرة فورياً',
    permissionsAr: 'طاقم الدعم والإدارة فقط',
    isAdminOnly: true,
    example: '/summarize-ticket',
  },

  // Tickets System
  {
    name: 'setup-tickets',
    syntax: '/setup-tickets',
    category: 'tickets',
    descriptionAr: 'إنشاء لوحة التذاكر التفاعلية مع أزرار الأقسام (الدعم الفني، المبيعات، الشكاوى)',
    permissionsAr: 'مدير السيرفر فقط (Administrator 👑)',
    isAdminOnly: true,
    example: '/setup-tickets',
  },
  {
    name: 'ticket close',
    syntax: '/ticket close',
    category: 'tickets',
    descriptionAr: 'إغلاق وأرشفة تذكرة الدعم الحالية وتفريغ المحادثة وحذف الروم',
    permissionsAr: 'طاقم الدعم أو صاحب التذكرة',
    isAdminOnly: false,
    example: '/ticket close',
  },
  {
    name: 'ticket claim',
    syntax: '/ticket claim',
    category: 'tickets',
    descriptionAr: 'استلام التذكرة من قبل أحد مسؤولي الدعم لإبلاغ العضو بأن طلبه قيد المعالجة',
    permissionsAr: 'طاقم الدعم (Support Role)',
    isAdminOnly: true,
    example: '/ticket claim',
  },
  {
    name: 'ticket add',
    syntax: '/ticket add [user]',
    category: 'tickets',
    descriptionAr: 'إضافة عضو أو إداري آخر لروم التذكرة',
    permissionsAr: 'طاقم الدعم والإدارة فقط',
    isAdminOnly: true,
    example: '/ticket add @سالم',
  },

  // Auto Responders
  {
    name: 'autoreply',
    syntax: '/autoreply add [trigger] [reply]',
    category: 'general',
    descriptionAr: 'إضافة رد تلقائي فوري مخصص لكلمة أو جملة معينة في السيرفر',
    permissionsAr: 'مدير السيرفر فقط (Administrator 👑)',
    isAdminOnly: true,
    example: '/autoreply add متجر https://store.hitrexsmp.com',
  },

  // Moderation & Administration (Strictly Locked for Admins)
  {
    name: 'ban',
    syntax: '/ban [user] [reason]',
    category: 'moderation',
    descriptionAr: 'حظر عضو نهائياً من السيرفر وتسجيل السبب في سجل الرقابة',
    permissionsAr: 'حظر الأعضاء / إدارة (Ban Members 👑)',
    isAdminOnly: true,
    example: '/ban @مخالف سب وقذف متكرر',
  },
  {
    name: 'kick',
    syntax: '/kick [user] [reason]',
    category: 'moderation',
    descriptionAr: 'طرد عضو من السيرفر مع إمكانية عودته برابط دعوة جديد',
    permissionsAr: 'طرد الأعضاء / إدارة (Kick Members 👑)',
    isAdminOnly: true,
    example: '/kick @عضو مخالفة قوانين الشات',
  },
  {
    name: 'warn',
    syntax: '/warn [user] [reason]',
    category: 'moderation',
    descriptionAr: 'توجيه إنذار رسمي مسجل في قاعدة بيانات السيرفر للعضو وإرسال إشعار له في الخاص',
    permissionsAr: 'إدارة السيرفر (Moderate Members 👑)',
    isAdminOnly: true,
    example: '/warn @عضو نشر روابط غير مصرح بها',
  },
  {
    name: 'clear',
    syntax: '/clear [amount]',
    category: 'moderation',
    descriptionAr: 'مسح فوري لعدد معين من الرسائل الحديثة في الروم الحالي (1-100)',
    permissionsAr: 'إدارة الرسائل (Manage Messages 👑)',
    isAdminOnly: true,
    example: '/clear 25',
  },
  {
    name: 'slowmode',
    syntax: '/slowmode [seconds]',
    category: 'moderation',
    descriptionAr: 'تفعيل الوضع البطيء للروم لتهدئة المحادثات ومنع السبام السريع',
    permissionsAr: 'إدارة الرومات (Manage Channels 👑)',
    isAdminOnly: true,
    example: '/slowmode 5',
  },

  // General & Ping
  {
    name: 'help',
    syntax: '/help',
    category: 'general',
    descriptionAr: 'عرض قائمة الأوامر المتاحة والأنظمة النشطة وإرشادات الاستخدام',
    permissionsAr: 'متاح لجميع اللاعبين (Everyone)',
    isAdminOnly: false,
    example: '/help',
  },
  {
    name: 'ping',
    syntax: '/ping',
    category: 'general',
    descriptionAr: 'فحص سرعة استجابة البوت مع خوادم الديسكورد (Latency & API Ping)',
    permissionsAr: 'متاح لجميع اللاعبين (Everyone)',
    isAdminOnly: false,
    example: '/ping',
  },
];
