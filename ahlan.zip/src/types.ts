export type ActiveTab = 'simulator' | 'connection' | 'tickets' | 'moderation' | 'ai' | 'invites' | 'auto-replies' | 'commands';

export interface BotStatusResponse {
  status: 'offline' | 'connecting' | 'online' | 'error';
  tag: string | null;
  id: string | null;
  ping: number;
  uptime: number;
  uptimeHuman: number;
  guildsCount: number;
  tokenConfigured: boolean;
  errorMessage: string | null;
}

export interface SimulatedMessage {
  id: string;
  author: {
    name: string;
    avatar: string;
    isBot?: boolean;
    roleColor?: string;
  };
  content: string;
  timestamp: string;
  embed?: {
    title?: string;
    description?: string;
    color?: string;
    fields?: { name: string; value: string; inline?: boolean }[];
    footer?: string;
  };
  components?: {
    type: 'buttons';
    buttons: {
      id: string;
      label: string;
      style: 'primary' | 'secondary' | 'success' | 'danger';
      emoji?: string;
    }[];
  }[];
}

export interface SimulatedTicket {
  id: string;
  channelName: string;
  creator: string;
  category: 'support' | 'billing' | 'report';
  status: 'open' | 'claimed' | 'closed';
  claimedBy?: string;
  createdAt: string;
  messages: { author: string; text: string; time: string }[];
  aiSummary?: string;
}

export interface ModerationLog {
  id: string;
  action: 'ban' | 'kick' | 'warn' | 'timeout' | 'clear';
  targetUser: string;
  moderator: string;
  reason: string;
  timestamp: string;
}

export interface AutoModConfig {
  antiSpam: boolean;
  antiLinks: boolean;
  aiToxicityFilter: boolean;
  badWords: string[];
}

export interface BotCommand {
  name: string;
  syntax: string;
  category: 'tickets' | 'moderation' | 'ai' | 'invites' | 'general';
  descriptionAr: string;
  permissionsAr: string;
  isAdminOnly: boolean;
  example: string;
}

export interface InviteRecord {
  userId: string;
  userTag: string;
  total: number;
  regular: number;
  left: number;
  fake: number;
  inviteCode?: string;
}

export interface AutoResponder {
  id: string;
  trigger: string;
  reply: string;
  matchType: 'exact' | 'contains' | 'startsWith';
  enabled: boolean;
  isEmbed?: boolean;
}
