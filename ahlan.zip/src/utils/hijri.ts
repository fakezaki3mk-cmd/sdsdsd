/**
 * Hijri-Gregorian Date Converter
 * Uses astronomical Kuwaiti / Umm al-Qura approximation algorithm.
 */

const HIJRI_MONTHS_AR = [
  'محرم',
  'صفر',
  'ربيع الأول',
  'ربيع الآخر',
  'جمادى الأولى',
  'جمادى الآخرة',
  'رجب',
  'شعبان',
  'رمضان',
  'شوال',
  'ذو القعدة',
  'ذو الحجة',
];

const HIJRI_MONTHS_EN = [
  'Muharram',
  'Safar',
  'Rabi al-Awwal',
  'Rabi al-Thani',
  'Jumada al-Awwal',
  'Jumada al-Thani',
  'Rajab',
  'Sha\'ban',
  'Ramadan',
  'Shawwal',
  'Dhu al-Qi\'dah',
  'Dhu al-Hijjah',
];

export interface HijriDateResult {
  day: number;
  month: number;
  monthName: string;
  year: number;
  formatted: string;
}

export function gregorianToHijri(date: Date, lang: 'ar' | 'en' = 'ar'): HijriDateResult {
  // Try native Intl first if available with islamic-umalqura calendar
  try {
    const formatter = new Intl.DateTimeFormat(`${lang}-u-ca-islamic-umalqura`, {
      day: 'numeric',
      month: 'numeric',
      year: 'numeric',
    });
    const parts = formatter.formatToParts(date);
    const day = parseInt(parts.find((p) => p.type === 'day')?.value || '1', 10);
    const month = parseInt(parts.find((p) => p.type === 'month')?.value || '1', 10);
    const year = parseInt(parts.find((p) => p.type === 'year')?.value || '1448', 10);

    const monthIndex = Math.max(0, Math.min(11, month - 1));
    const monthName = lang === 'ar' ? HIJRI_MONTHS_AR[monthIndex] : HIJRI_MONTHS_EN[monthIndex];
    const formatted = lang === 'ar' 
      ? `${day} ${monthName} ${year} هـ` 
      : `${day} ${monthName} ${year} AH`;

    return { day, month, monthName, year, formatted };
  } catch {
    // Fallback astronomical calculation
    let day = date.getDate();
    let month = date.getMonth();
    let year = date.getFullYear();

    if (year < 1900) year += 1900;
    let m = month + 1;
    let y = year;

    if (m < 3) {
      y -= 1;
      m += 12;
    }

    const a = Math.floor(y / 100);
    const b = 2 - a + Math.floor(a / 4);
    const jd = Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + day + b - 1524.5;
    const l = Math.floor(jd - 1948440 + 10632);
    const n = Math.floor((l - 1) / 10631);
    const l2 = l - 10631 * n + 354;
    const j = Math.floor((10985 - l2) / 5316) * Math.floor((50 * l2) / 17719) + Math.floor(l2 / 5670) * Math.floor((43 * l2) / 15238);
    const l3 = l2 - Math.floor((30 - j) / 15) * Math.floor((17719 * j) / 50) - Math.floor(j / 16) * Math.floor((15238 * j) / 43) + 29;
    const mFinal = Math.floor((24 * l3) / 709);
    const dFinal = l3 - Math.floor((709 * mFinal) / 24);
    const yFinal = 30 * n + j - 30;

    const safeMonth = Math.max(0, Math.min(11, mFinal - 1));
    const monthName = lang === 'ar' ? HIJRI_MONTHS_AR[safeMonth] : HIJRI_MONTHS_EN[safeMonth];
    const formatted = lang === 'ar'
      ? `${dFinal} ${monthName} ${yFinal} هـ`
      : `${dFinal} ${monthName} ${yFinal} AH`;

    return {
      day: dFinal,
      month: mFinal,
      monthName,
      year: yFinal,
      formatted,
    };
  }
}
